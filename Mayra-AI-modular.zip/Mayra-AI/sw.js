/* Mayra AI service worker — offline-first app shell + Quran/Hadith/fonts runtime cache */
const V='v3';
const SHELL='mayra-shell-'+V, DATA='mayra-data-v1', FONTS='mayra-fonts-v1', LIBS='mayra-libs-v1';
const PRECACHE=["./", "index.html", "manifest.json", "icon-192.png", "icon-512.png", "css/main.css", "js/brain.js", "js/builder.js", "js/chat-delivery.js", "js/code-runner.js", "js/core.js", "js/editor.js", "js/filecards.js", "js/memory.js", "js/offline-data.js", "js/publish.js", "js/routing-quran.js", "js/skill-loader.js", "js/smart-memory.js", "assets/bg-1aa8c0a7.webp", "assets/bg-bb3df11f.webp", "assets/ic-gemini-9b3726e0.png", "assets/ic-grok-424826a2.png", "assets/ic-nvidia-2d5e6dde.png", "assets/img-cf2b0926.webp", "assets/img-e19bd0d8.webp"];
const OPTIONAL=['data/skills.json'];            // বড় ফাইল: ফেল করলেও install আটকাবে না

self.addEventListener('install',e=>{
  e.waitUntil((async()=>{
    const c=await caches.open(SHELL);
    await c.addAll(PRECACHE.map(u=>new Request(u,{cache:'reload'})));
    await Promise.all(OPTIONAL.map(u=>c.add(new Request(u,{cache:'reload'})).catch(()=>{})));
    self.skipWaiting();
  })());
});
self.addEventListener('activate',e=>{
  e.waitUntil((async()=>{
    for(const k of await caches.keys()) if(k.startsWith('mayra-shell-')&&k!==SHELL) await caches.delete(k);
    await self.clients.claim();
  })());
});

const swr=async(req,name)=>{                    // cached আগে দেখাও, পেছনে আপডেট আনো
  const c=await caches.open(name), hit=await c.match(req);
  const net=fetch(req).then(r=>{if(r&&(r.ok||r.type==='opaque'))c.put(req,r.clone());return r}).catch(()=>hit);
  return hit||net;
};
const cacheFirst=async(req,name)=>{
  const c=await caches.open(name), hit=await c.match(req); if(hit)return hit;
  const r=await fetch(req); if(r.ok)c.put(req,r.clone()); return r;
};

self.addEventListener('fetch',e=>{
  const req=e.request; if(req.method!=='GET')return;            // AI API (POST) কখনো ক্যাশ হবে না
  const u=new URL(req.url); if(!/^https?:$/.test(u.protocol))return;
  if(req.headers.has('range'))return;                            // অডিও/ভিডিও স্ট্রিম বাদ

  if(u.origin===location.origin){                                // অ্যাপ শেল
    e.respondWith((async()=>{
      try{return await swr(req,SHELL)}
      catch(err){ if(req.mode==='navigate'){const c=await caches.open(SHELL);return (await c.match('index.html'))||(await c.match('./'))} throw err }
    })());
    return;
  }
  if(u.hostname==='fonts.googleapis.com'||u.hostname==='fonts.gstatic.com'){ e.respondWith(swr(req,FONTS)); return }
  if(u.hostname==='api.alquran.cloud'||u.pathname.includes('/gh/fawazahmed0/hadith-api')){
    e.respondWith(cacheFirst(req,DATA).catch(()=>new Response('{"code":503,"status":"offline"}',{status:503,headers:{'Content-Type':'application/json'}}))); return
  }
  if((u.hostname==='cdnjs.cloudflare.com'||u.hostname==='cdn.jsdelivr.net')&&!u.pathname.includes('/pyodide/')){
    e.respondWith(cacheFirst(req,LIBS)); return                  // jszip, peerjs, codemirror ইত্যাদি (pyodide অনেক বড়, তাই বাদ)
  }
});
