/* ---------- file cards (ZIP + edited files) ---------- */
let EDCHAT=false;
const pretty=n=>n.replace(/\.[^.]+$/,'').replace(/[-_]+/g,' ').replace(/^./,c=>c.toUpperCase());
const fkb=n=>n>=1048576?(n/1048576).toFixed(1)+' MB':Math.max(1,Math.round(n/1024))+' KB';
function projZip(){let fs;
 if(EP)fs=Object.keys(EP.files).map(n=>({n,d:n==EP.main?bcode:(EP.files[n].bytes||EP.files[n].text)}));
 else{const p=bSplit(bcode);fs=[{n:'index.html',d:p.html}];if(p.css)fs.push({n:'style.css',d:p.css});if(p.js)fs.push({n:'script.js',d:p.js});fs.push({n:'README.txt',d:'Mayra AI দিয়ে বানানো প্রজেক্ট\nindex.html ব্রাউজারে খুললেই চলবে।\nফোল্ডারটি GitHub Pages বা Netlify-তে আপলোড করলে সাইট লাইভ হবে।\n'})}
 return new File([mkzip(fs)],EP?(EP.zn||'mayra-project.zip'):'mayra-'+bk+'.zip',{type:'application/zip'})}
function pvOpen(file){(async()=>{try{
 const nm=file.name,ext=(nm.split('.').pop()||'').toLowerCase();let html='';
 if(ext=='html'||ext=='htm')html=await file.text();
 else if(ext=='zip'){const z=await unzipAll(await file.arrayBuffer()),keys=Object.keys(z).filter(k=>!/(^|\/)(__MACOSX|\.)/.test(k)),dec=k=>new TextDecoder().decode(z[k]);
  const hk=keys.find(k=>/(^|\/)index\.html?$/i.test(k))||keys.find(k=>/\.html?$/i.test(k));
  if(!hk){toast('Preview korar moto HTML file nai');return}
  html=dec(hk);const base=hk.replace(/[^\/]*$/,'');
  const get=p=>{p=p.replace(/^\.\//,'').split(/[?#]/)[0];const k=keys.find(x=>x==base+p||x==p||x.endsWith('/'+p));return k?dec(k):null};
  html=html.replace(/<link[^>]+href=["']([^"']+\.css)["'][^>]*>/gi,(m,h)=>{const c=get(h);return c==null?m:'<style>'+c+'</style>'}).replace(/<script([^>]*)\ssrc=["']([^"']+\.js)["']([^>]*)><\/script>/gi,(m,a,h,b)=>{const c=get(h);return c==null?m:'<script'+a+b+'>'+c.replace(/<\/script/gi,'<\\/script')+'<'+'/script>'})}
 else{toast('Ei file-er preview nai');return}
 const o=document.createElement('div');o.style.cssText='position:fixed;inset:0;z-index:99999;background:#faf9f5;display:flex;flex-direction:column';
 const bs='border:1px solid #cfcab9;background:#fff;color:#1f1e1d;border-radius:10px;padding:7px 12px;font:600 13px Poppins,sans-serif;cursor:pointer';
 o.innerHTML='<div style="display:flex;align-items:center;gap:8px;padding:calc(10px + env(safe-area-inset-top,0px)) 12px 10px;border-bottom:1px solid #dedacb;color:#1f1e1d;font:600 15px Poppins,sans-serif"><span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(pretty(nm))+'</span><button data-d style="'+bs+'">Download</button><button data-x style="'+bs+';background:#1f1e1d;color:#fff">Close</button></div>';
 const f=document.createElement('iframe');f.setAttribute('sandbox','allow-scripts allow-forms allow-modals allow-popups');f.style.cssText='flex:1;border:0;width:100%;background:#fff';f.srcdoc=html;o.appendChild(f);
 o.querySelector('[data-x]').onclick=()=>o.remove();o.querySelector('[data-d]').onclick=()=>bSave(file);document.body.appendChild(o)
}catch(e){toast('Preview hoyni: '+(e.message||e))}})()}
function cardEl(icon,bg,title,sub,file){const d=document.createElement('div');d.style.cssText='display:flex;align-items:center;gap:12px;padding:12px;border:1px solid #dedacb;border-radius:16px;background:#faf9f5;margin:8px 0;cursor:pointer;color:#1f1e1d;text-align:left;box-shadow:0 1px 3px rgba(0,0,0,.08)';
 d.innerHTML='<div style="width:48px;height:56px;flex:none;border-radius:10px;display:grid;place-items:center;font-size:22px;color:#fff;background:'+bg+';border:1px solid rgba(0,0,0,.12)">'+icon+'</div><div style="flex:1;min-width:0"><div style="font-size:15.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(title)+'</div><div style="font-size:12.5px;color:#73726c;margin-top:2px">'+esc(sub)+'</div></div>';
 const act=document.createElement('div'),cs='width:38px;height:38px;flex:none;border-radius:50%;border:1px solid #cfcab9;background:#fff;color:#1f1e1d;display:grid;place-items:center;font-size:17px;cursor:pointer';
 if(!file){act.style.cssText=cs;act.textContent='\u2B07';d.appendChild(act);return d}
 act.style.cssText='display:flex;gap:8px;flex:none';
 const ext=((file.name||'').split('.').pop()||'').toLowerCase();
 if(ext=='html'||ext=='htm'||ext=='zip'){const p=document.createElement('div');p.style.cssText=cs+';background:#c96442;border-color:#c96442;color:#fff';p.title='Preview';p.textContent='\u25B6';p.onclick=e=>{e.stopPropagation();pvOpen(file)};act.appendChild(p)}
 const dl=document.createElement('div');dl.style.cssText=cs;dl.title='Download';dl.textContent='\u2B07';dl.onclick=e=>{e.stopPropagation();bSave(file)};act.appendChild(dl);d.appendChild(act);
 d.onclick=()=>bSave(file);return d}
function mkCards(){const w=document.createElement('div'),z=projZip();w.appendChild(cardEl('🗜','#2b1470',pretty(z.name),'ZIP · '+fkb(z.size),z));
 const mn=EP?EP.main.split('/').pop():'index.html',f=new File([bcode],mn,{type:'text/html'}),ex=(mn.split('.').pop()||'').toUpperCase();
 w.appendChild(cardEl('&lt;/&gt;','#4a3208',pretty(mn),'Code · '+ex+' · '+fkb(f.size),f));return w}
function revCard(){const d=cardEl('▶','#0b4a2a','Review','এখানেই সরাসরি চালিয়ে দেখো · HTML',null);d.style.borderColor='rgba(80,220,150,.7)';d.lastElementChild.textContent='▶';d.onclick=()=>{try{$('#bfs').onclick()}catch(e){toast('Review খুলতে সমস্যা: '+e.message)}};return d}
function bCards(){const c=$('#bfl');if(!c)return;c.innerHTML='';if(bcode&&(EP||/<html|<!doctype/i.test(bcode)))c.appendChild(mkCards())}
$('#bzp').onclick=()=>{if(bcode)bSave(projZip())};

