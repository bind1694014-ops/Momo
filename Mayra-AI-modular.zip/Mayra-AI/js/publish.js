/* ---------- splash / orb / debug / zip / publish ---------- */
(()=>{const lg=document.querySelector('.dr .lg img'),im=document.querySelector('#spl img');if(lg&&im)im.src=lg.src;setTimeout(()=>{const e=document.getElementById('spl');e&&e.remove()},2800)})();
let ML=0,LVs=0;
const LVm=d=>{let t=0,n=0;for(let i=0;i<d.length;i+=8){t+=d[i]*d[i];n++}ML=Math.sqrt(t/(n||1))};
function mkAn(ac){const a=ac.createAnalyser();a.fftSize=256;a.connect(ac.destination);return a}
setInterval(()=>{const o=$('#orb');if(!o)return;if(!CS){if(LVs){LVs=0;o.style.setProperty('--lv',0)}return}
 let v=0;if(CS.src&&CS.src.length&&CS.an){const b=new Uint8Array(CS.an.fftSize);CS.an.getByteTimeDomainData(b);let t=0;for(let i=0;i<b.length;i++){const x=(b[i]-128)/128;t+=x*x}v=Math.sqrt(t/b.length)*3.2}else v=CS.mute?0:ML*5;
 LVs=LVs*.55+Math.min(1,v)*.45;o.style.setProperty('--lv',LVs.toFixed(3))},50);
BT.push({k:'dbg',e:'🐞',n:'Debug Fixer',s:'কোড/এরর পেস্ট করো',ph:'এখানে বাগি কোড এবং এরর মেসেজ পেস্ট করো…',sys:'You are a senior debugging expert. The user pastes buggy code and/or an error message. 1) Explain the root cause in at most 4 short Bangla sentences. 2) Then give the COMPLETE corrected code in ONE fenced code block with the proper language tag (html for web pages). Never shorten or omit parts of the code.'});
const bAny=t=>{const m=t.match(/```[\w+#.-]*[ \t]*\r?\n([\s\S]*?)```/)||t.match(/```[\w+#.-]*[ \t]*\r?\n([\s\S]*)$/);return m?m[1].trim():''};
function bEx(a){const e=a.split('```')[0].trim();if(e){const st=$('#bst');st.style.whiteSpace='pre-wrap';st.textContent='✅ '+e}}
const ERRJS='<script>(function(){function s(m){try{parent.postMessage({mayraErr:String(m).slice(0,300)},"*")}catch(e){}}onerror=function(m,u,l){s(m+" (line "+l+")")};addEventListener("unhandledrejection",function(e){s("Promise: "+(e.reason&&e.reason.message||e.reason))});var ce=console.error;console.error=function(){s([].slice.call(arguments).join(" "));ce.apply(console,arguments)}})()<\/script>';
function shim(id){let seed={};if(id&&id!='tmp'){try{seed=JSON.parse(localStorage.getItem('mayra_ls_'+id)||'{}')}catch(e){}}
 return '<script>(function(){var d='+JSON.stringify(seed).replace(/</g,'\\u003c')+',id='+JSON.stringify(id||'tmp')+';function p(){try{parent.postMessage({mayraLS:{id:id,data:d}},"*")}catch(e){}}var ls={getItem:function(k){return Object.prototype.hasOwnProperty.call(d,k)?d[k]:null},setItem:function(k,v){d[k]=String(v);p()},removeItem:function(k){delete d[k];p()},clear:function(){d={};p()},key:function(i){return Object.keys(d)[i]||null}};Object.defineProperty(ls,"length",{get:function(){return Object.keys(d).length}});try{Object.defineProperty(window,"localStorage",{value:ls,configurable:true})}catch(e){}})()<\/script>'}
function pdoc(c,id){const inj=ERRJS+shim(id),m=c.match(/<head[^>]*>/i);return m?c.slice(0,m.index+m[0].length)+inj+c.slice(m.index+m[0].length):inj+c}
function bdbg(){const b=$('#bdb');if(b)b.textContent='🐞 Debug'+(berr.length?' ('+berr.length+')':'')}
addEventListener('message',e=>{const m=e.data&&e.data.mayraErr;if(!m)return;if(berr.length<10&&!berr.includes(m)){berr.push(m);bdbg();if(!bbusy)$('#bst').textContent='🐞 '+berr.length+'টি এরর পাওয়া গেছে — 🐞 Debug চাপলে AI ঠিক করে দেবে'}});
$('#bdb').onclick=()=>{const x=$('#bed').value.trim();if(!berr.length&&!x)return toast('কোনো এরর পাওয়া যায়নি। সমস্যা নিচে লিখে 🐞 চাপো');bRun(1,'Fix every problem in this app so that it works perfectly. '+(berr.length?'Runtime errors detected in the preview:\n- '+berr.join('\n- ')+'\n':'')+(x?'User report: '+x+'\n':'')+'Return the COMPLETE fixed HTML in one ```html block.')};
/* zip (store, no compression) */
function crc32(u){let t=crc32.t,c;if(!t){t=crc32.t=[];for(let n=0;n<256;n++){c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0}}c=0xFFFFFFFF;for(let i=0;i<u.length;i++)c=t[(c^u[i])&255]^(c>>>8);return(c^0xFFFFFFFF)>>>0}
function mkzip(fs){const en=new TextEncoder(),ch=[],cd=[];let off=0;const w16=(a,v)=>a.push(v&255,v>>8&255),w32=(a,v)=>a.push(v&255,v>>8&255,v>>16&255,v>>>24&255);
 fs.forEach(f=>{const nm=en.encode(f.n),d=typeof f.d=='string'?en.encode(f.d):f.d,cr=crc32(d),h=[];
  w32(h,0x04034b50);w16(h,20);w16(h,0x0800);w16(h,0);w16(h,0);w16(h,0x21);w32(h,cr);w32(h,d.length);w32(h,d.length);w16(h,nm.length);w16(h,0);ch.push(new Uint8Array(h),nm,d);
  const c=[];w32(c,0x02014b50);w16(c,20);w16(c,20);w16(c,0x0800);w16(c,0);w16(c,0);w16(c,0x21);w32(c,cr);w32(c,d.length);w32(c,d.length);w16(c,nm.length);w16(c,0);w16(c,0);w16(c,0);w16(c,0);w32(c,0);w32(c,off);cd.push(new Uint8Array(c),nm);off+=h.length+nm.length+d.length});
 const cs=cd.reduce((a,x)=>a+x.length,0),e=[];w32(e,0x06054b50);w16(e,0);w16(e,0);w16(e,fs.length);w16(e,fs.length);w32(e,cs);w32(e,off);w16(e,0);
 return new Blob([...ch,...cd,new Uint8Array(e)],{type:'application/zip'})}
function bSplit(h){const css=[],js=[];let o=h.replace(/<style[^>]*>([\s\S]*?)<\/style>/gi,(m,c)=>{css.push(c.trim());return css.length==1?'<link rel="stylesheet" href="style.css">':''});
 o=o.replace(/<script(?![^>]*\bsrc=)(?![^>]*type=["']?(?:module|application))[^>]*>([\s\S]*?)<\/script>/gi,(m,c)=>{js.push(c.trim());return '\u0001JS\u0001'});
 if(js.length){const p=o.split('\u0001JS\u0001');o=p.slice(0,-1).join('')+'<script src="script.js"><\/script>'+p[p.length-1]}
 return{html:o,css:css.join('\n\n'),js:js.join('\n\n;')}}
async function bSave(f){try{if(navigator.canShare&&navigator.canShare({files:[f]})){await navigator.share({files:[f]});return}}catch(e){if(e&&e.name=='AbortError')return}
 const a=document.createElement('a');a.href=URL.createObjectURL(f);a.download=f.name;document.body.appendChild(a);a.click();a.remove();toast('Save হচ্ছে… না হলে 📋 Copy করে ব্যবহার করো')}
$('#bdl').onclick=()=>{if(bcode)bSave(new File([bcode],'mayra-'+bk+'.html',{type:'text/html'}))};
$('#bzp').onclick=()=>{if(!bcode)return;const p=bSplit(bcode),fs=[{n:'index.html',d:p.html}];if(p.css)fs.push({n:'style.css',d:p.css});if(p.js)fs.push({n:'script.js',d:p.js});fs.push({n:'README.txt',d:'Mayra AI দিয়ে বানানো প্রজেক্ট\nindex.html ব্রাউজারে খুললেই চলবে।\nফোল্ডারটি GitHub Pages বা Netlify-তে আপলোড করলে সাইট লাইভ হবে।\n'});bSave(new File([mkzip(fs)],'mayra-'+bk+'.zip',{type:'application/zip'}))};
/* github publish */
const GHK='mayra_gh',ghGet=()=>{try{return JSON.parse(localStorage.getItem(GHK)||'{}')}catch(e){return{}}};
async function gh(path,opt){const c=ghGet(),o=opt||{};const r=await fetch('https://api.github.com'+path,Object.assign({},o,{headers:Object.assign({'Authorization':'Bearer '+c.tok,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'},o.body?{'Content-Type':'application/json'}:{})}));let j=null;try{j=await r.json()}catch(e){}return{ok:r.ok,s:r.status,j}}
const b64t=t=>{const u=new TextEncoder().encode(t);let b='';for(let i=0;i<u.length;i+=0x8000)b+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(b)};
const sl=ms=>new Promise(r=>setTimeout(r,ms));
$('#bgb').onclick=()=>{const g=$('#bgh'),c=ghGet();g.style.display=g.style.display=='none'?'block':'none';$('#ght').value=c.tok||'';$('#ghr').value=c.repo||''};
$('#ghs').onclick=async()=>{const tok=$('#ght').value.trim(),repo=($('#ghr').value.trim()||'mayra-sites').replace(/[^A-Za-z0-9._-]/g,'-');if(!tok)return;try{localStorage.setItem(GHK,JSON.stringify({tok,repo}))}catch(e){}
 $('#ghm').textContent='যাচাই হচ্ছে…';try{const u=await gh('/user');$('#ghm').textContent=u.ok?'✅ Connected: '+u.j.login+' → '+repo:'❌ টোকেন ঠিক নয় ('+u.s+')'}catch(e){$('#ghm').textContent='❌ নেট সমস্যা'}};
async function bPub(){const c=ghGet(),st=$('#bpu');if(!bcode)return;if(!c.tok){$('#bgh').style.display='block';return toast('আগে ⚙️ GitHub Connect করো')}
 const say=t=>st.textContent=t;st.innerHTML='';$('#bpb').disabled=true;
 try{say('🔐 GitHub যাচাই…');const u=await gh('/user');if(!u.ok)throw new Error('টোকেন ঠিক নয় ('+u.s+')');const lg=u.j.login,repo=c.repo||'mayra-sites';
  say('📦 Repo দেখছি…');let r=await gh('/repos/'+lg+'/'+repo);
  if(r.s==404){say('📦 নতুন repo বানাচ্ছি…');const n=await gh('/user/repos',{method:'POST',body:JSON.stringify({name:repo,description:'Sites built with Mayra AI',auto_init:true,private:false})});if(!n.ok)throw new Error('Repo বানানো যায়নি ('+n.s+') — টোকেনে repo permission আছে?');r=n;await sl(2500)}else if(!r.ok)throw new Error('Repo পাওয়া যায়নি ('+r.s+')');
  const br=r.j.default_branch||'main';if(!bpub)bpub='site-'+Date.now().toString(36);const path=bpub+'/index.html';
  say('⬆️ ফাইল আপলোড…');const ex=await gh('/repos/'+lg+'/'+repo+'/contents/'+path+'?ref='+br);
  const body={message:'Publish from Mayra AI',content:b64t(bcode),branch:br};if(ex.ok&&ex.j.sha)body.sha=ex.j.sha;
  const pu=await gh('/repos/'+lg+'/'+repo+'/contents/'+path,{method:'PUT',body:JSON.stringify(body)});if(!pu.ok)throw new Error('আপলোড হয়নি ('+pu.s+')'+(pu.j&&pu.j.message?': '+pu.j.message:''));
  say('🌐 Pages চালু করছি…');const pg=await gh('/repos/'+lg+'/'+repo+'/pages');let pgErr='';
  if(pg.s==404){const cr=await gh('/repos/'+lg+'/'+repo+'/pages',{method:'POST',body:JSON.stringify({source:{branch:br,path:'/'}})});if(!cr.ok&&cr.s!=409)pgErr=' Pages চালু হয়নি ('+cr.s+')'+(cr.j&&cr.j.message?': '+cr.j.message:'')}
  else if(pg.ok){await gh('/repos/'+lg+'/'+repo+'/pages/builds',{method:'POST'})}
  let live=false,bstt='';
  const msg=pgErr?'⚠️ ফাইল আপলোড হয়েছে, কিন্তু'+pgErr:'✅ Publish হয়েছে! লিংক ১-২ মিনিট পরে চালু হবে:';
  const url='https://'+lg+'.github.io/'+(repo.toLowerCase()==(lg+'.github.io').toLowerCase()?'':repo+'/')+bpub+'/';bsave();
  st.innerHTML=esc(msg)+'<br><a href="'+esc(url)+'" target="_blank" rel="noopener" style="color:#4fd1ff;word-break:break-all">'+esc(url)+'</a><br><button class="q-b" id="bcl" style="margin-top:8px">📋 লিংক কপি</button>'+(!pgErr?'':'<br>⚙️ <a href="https://github.com/'+esc(lg)+'/'+esc(repo)+'/settings/pages" target="_blank" rel="noopener" style="color:#4fd1ff">Pages সেটিংস খুলে দেখো</a> (Source: Deploy from a branch → '+esc(br)+' / root)');
  $('#bcl').onclick=()=>{try{navigator.clipboard.writeText(url).then(()=>toast('লিংক কপি হয়েছে ✓'))}catch(e){}}}
 catch(e){say('❌ '+e.message)}
 $('#bpb').disabled=false}
$('#bpb').onclick=bPub;

