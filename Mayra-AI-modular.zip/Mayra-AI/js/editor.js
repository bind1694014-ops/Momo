/* ---------- Code Editor (surgical, step-by-step) ---------- */
let EP=null,EV=[],emStep=true;
const TXTX=/\.(html?|css|js|mjs|json|txt|svg|webmanifest|md|xml)$/i;
const EDV=/edit|এডিট|বদল|পরিবর্তন|যোগ|যুক্ত|\badd\b|change|\bfix\b|ঠিক|remove|মুছ|update|আপডেট|improve|উন্নত|modify|replace|convert|রূপান্তর|implement|integrate/i;
/* strict edit/zip intent: প্রশ্ন বা অতীত-কাল হলে এডিট হবে না, শুধু স্পষ্ট নির্দেশ হলে */
const EDQ=/[?？]|(?:^|[\s,.])(?:ki|keno|kno|kmn|kemon|kothay|kothai|koto|kon|why|what|how|did|does|which)(?=$|[\s,.?])|কি|কী|কেন|কিভাবে|কীভাবে|কোথায়|কত|কোন|ব্যাখ্যা|বুঝিয়ে|\bexplain\b|\b(?:korla|korlo|korle|korechho|korecho|korcho|korso|korchi|korlam|korechi|hoilo|hoise|hoyeche|hoyese)\b|হলো|হইল|হইছে|হয়েছে|করলে|করলি|করেছ|করছ|করলাম|করেছি/i;
const EDC=/\b(?:edit|add|remove|delete|fix|change|replace|update|modify|convert|implement|integrate|improve)\b|\b(?:koro|kor|korun|dao|daw|dio|den|banao|banaw|lagao|bodlao|jog\s*koro)\b|করো|করুন|দাও|দিও|বানাও|লাগাও|বদলাও|মুছে\s*দাও|মুছে\s*ফেল/i;
const EDB=/bodl|jog\s*kor|muche|thik\s*kor|poriborton|lagao|\brong\b|colou?r|\bred\b|\bblue\b|\bgreen\b|sundor|sunder|shundor|beshi|\baro\b|\baaro\b|anim|motion|glow|design|\bui\b|\bstyle\b|modern|premium|polish|beautif|akorsh?on|আকর্ষণ|সুন্দর|অ্যানিমেশন|এনিমেশন|ডিজাইন|আরও|আরো|চমৎকার|ঝকঝকে/i;
const isEditCmd=t=>(EDV.test(t)||EDB.test(t))&&EDC.test(t)&&(/^\s*(?:edit|এডিট)\s*[:：]/i.test(t)||!EDQ.test(t));

const isCodeAtt=a=>a&&((/\.(html?|css|js|jsx|json)$/i.test(a.name||'')&&(((a.file&&a.file.size)||(a.text||'').length)>1500))||(/\.zip$/i.test(a.name||'')&&a.file)||(/^Pasted text/.test(a.name||'')&&(a.full||a.text||'').length>1500&&/<\/?(html|head|body|script|div|style)|\bfunction\b|\bconst\b|=>/.test(a.full||a.text||'')));
async function unzipAll(buf){const u=new Uint8Array(buf),dv=new DataView(buf);let e=-1;for(let i=u.length-22;i>=Math.max(0,u.length-65558);i--){if(dv.getUint32(i,true)==0x06054b50){e=i;break}}if(e<0)throw new Error('ZIP পড়া যায়নি');
 const n=dv.getUint16(e+10,true);let p=dv.getUint32(e+16,true);const out={},dc=new TextDecoder();
 for(let k=0;k<n;k++){if(dv.getUint32(p,true)!=0x02014b50)break;const meth=dv.getUint16(p+10,true),cs=dv.getUint32(p+20,true),nl=dv.getUint16(p+28,true),el=dv.getUint16(p+30,true),cl=dv.getUint16(p+32,true),lo=dv.getUint32(p+42,true),name=dc.decode(u.subarray(p+46,p+46+nl));p+=46+nl+el+cl;
  if(name.endsWith('/'))continue;const ln=dv.getUint16(lo+26,true),le=dv.getUint16(lo+28,true),st=lo+30+ln+le,raw=u.subarray(st,st+cs);let d;
  if(meth==0)d=raw.slice();else if(meth==8)d=new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());else continue;
  out[name]=d}return out}
function edLoadFiles(files,zn){const ks=Object.keys(files);if(!ks.length)throw new Error('ফাইল পাওয়া যায়নি');
 const hs=ks.filter(k=>/\.html?$/i.test(k)&&files[k].text!=null).sort((a,b)=>(/(^|\/)index\.html?$/i.test(b)-/(^|\/)index\.html?$/i.test(a))||a.length-b.length);
 const main=hs[0]||ks.find(k=>files[k].text!=null);if(!main)throw new Error('এডিট করার মতো টেক্সট ফাইল নেই');
 EP={files,main,zn};EV=[];bpub='';bsid='';bk='edit';bcode=files[main].text;$('#bun').style.display='none';
 bShow(bcode,/<html|<!doctype/i.test(bcode));bTools();
 const pv=$('#bpv');pv.onclick=null;pv.textContent='📁 '+main+' ('+Math.round(bcode.length/1024)+' KB, '+bcode.split('\n').length+' লাইন)'+(ks.length>1?' + আরও '+(ks.length-1)+'টি ফাইল (ZIP-এ থাকবে)':'');$('#blg').style.display='none'}
async function edLoadFile(f){if(/\.zip$/i.test(f.name)){const z=await unzipAll(await f.arrayBuffer()),files={};Object.keys(z).filter(k=>!/(^|\/)(__MACOSX|\.)/.test(k)).forEach(k=>{files[k]=TXTX.test(k)?{text:new TextDecoder().decode(z[k])}:{bytes:z[k]}});edLoadFiles(files,f.name)}else edLoadFiles({[f.name]:{text:await f.text()}})}
async function edHandoff(a,t){try{if(a.file)await edLoadFile(a.file);else{const tx=a.full||a.text||'';edLoadFiles({[/<html|<!doctype/i.test(tx)?'index.html':(a.name||'code.txt')]:{text:tx}})}
 bk='edit';bModels();bTools();$('#bpr').value=t;EDCHAT=true;edRun(t)}catch(e){EDCHAT=false;toast('এডিট শুরু করা যায়নি: '+e.message)}}
const escRe=x=>x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
function mask(t){const mp=[];const o=t.replace(/data:[a-z0-9.+\/-]+;base64,[A-Za-z0-9+\/=]{300,}/gi,m=>{mp.push(m);return '[[B64_'+(mp.length-1)+']]'});return{t:o,mp}}
const unmask=(t,mp)=>t.replace(/\[\[B64_(\d+)\]\]/g,(m,i)=>mp[+i]!==undefined?mp[+i]:m);
function parseBlocks(t){t=t.replace(/^[ \t]*```\w*[ \t]*\r?\n/gm,'');const out=[],re=/<<<<<<<[ \t]*SEARCH[ \t]*\r?\n([\s\S]*?)\r?\n=======[ \t]*\r?\n([\s\S]*?)\r?\n?>>>>>>>[ \t]*REPLACE/g;let m;while((m=re.exec(t)))out.push({s:m[1],r:m[2]});return out}
function fuzzy(t,s){const L=s.split('\n').map(x=>x.trim()).filter(x=>x);if(!L.length)return null;const ms=[...t.matchAll(new RegExp('[ \\t]*'+L.map(escRe).join('\\s*\\n\\s*'),'g'))];return ms.length==1?{i:ms[0].index,n:ms[0][0].length}:ms.length?'multi':null}
function applyBlocks(t,bl){let ok=0;const fail=[];for(const b of bl){const s=b.s;if(!s.trim()){fail.push({b,why:'empty SEARCH'});continue}
 const i=t.indexOf(s);if(i>=0){if(t.indexOf(s,i+1)>=0){fail.push({b,why:'SEARCH matches more than one place - add more surrounding lines'});continue}t=t.slice(0,i)+b.r+t.slice(i+s.length);ok++;continue}
 const f=fuzzy(t,s);if(f&&f!='multi'){t=t.slice(0,f.i)+b.r+t.slice(f.i+f.n);ok++}else fail.push({b,why:f=='multi'?'SEARCH matches more than one place':'SEARCH text not found in the current file'})}
 return{t,ok,fail}}
function excerpt(t,s){const l0=(s.split('\n').map(x=>x.trim()).find(x=>x)||'').slice(0,50),L=t.split('\n');const hit=[];if(l0)L.forEach((x,i)=>{if(hit.length<2&&x.includes(l0))hit.push(i)});
 return hit.length?hit.map(i=>L.slice(Math.max(0,i-12),i+14).join('\n')).join('\n...\n'):'(no similar line found - choose a different anchor that really exists)'}
function synErr(t){const e=[];t.replace(/<script(?![^>]*\bsrc=)(?![^>]*type=["']?(?:module|application|text\/(?!javascript)))[^>]*>([\s\S]*?)<\/script>/gi,(m,c)=>{try{new Function(c)}catch(x){e.push(x.message)}return ''});return e}
function dstat(a,b){const c=new Map();a.split('\n').forEach(l=>c.set(l,(c.get(l)||0)+1));let add=0;b.split('\n').forEach(l=>{const n=c.get(l)||0;if(n>0)c.set(l,n-1);else add++});let rem=0;c.forEach(v=>rem+=v);return{add,rem}}
const ED_SYS='You are a senior software engineer making SURGICAL edits to an existing file. Absolute rules: (1) NEVER print or rewrite the whole file. (2) Preserve the existing theme, colors, fonts, layout, features, naming and code style; change only what the request needs. But when the request is visual or vague (more beautiful, animation, premium), make a rich, clearly visible improvement by ADDING CSS (keyframes, transitions, hover and active states, entrance animations, glow, glass effects, smooth scrolling) in a motion-safe way (respect prefers-reduced-motion), and never change logic, ids, event handlers or remove any feature. Never shrink or drop existing content. (3) Keep placeholders like [[B64_3]] exactly as they are. (4) Every SEARCH block must be copied verbatim from the CURRENT FILE and must match exactly ONE place (include a neighbouring unique line if needed). To insert, SEARCH an anchor line and repeat it in REPLACE together with the new lines. To delete, leave REPLACE empty. (5) New code must be complete and working, never partial and never with TODO or placeholder comments. Output ONLY this format, no code fences, no extra talk:\nEDITS:\n<<<<<<< SEARCH\n(exact existing text)\n=======\n(new text)\n>>>>>>> REPLACE\n(repeat blocks as needed)\nSUMMARY: one short Bangla sentence about what changed.';
const PL_SYS='You are a senior software engineer planning a change to an existing file. First read the whole file and understand what the app does, how it is structured and which parts are logic versus look. Then read the request. If the request is vague or visual (more beautiful, animations, premium look), do NOT plan one tiny tweak: plan several distinct visual areas (for example background, header, chat bubbles, buttons, cards, inputs, loaders, hover and press states, entrance animations), all CSS or markup only, never touching logic. Reply with ONLY a numbered plan of at most 7 concrete implementation steps, each one short Bangla sentence naming exactly where (element id, function or CSS class) the change goes. Order the steps so each can be done independently. Do not write code. Do not add a testing step.';
function contBtn(req,rem,L,EW){const bs=[];let used=0;const mk1=()=>{const b=document.createElement('button');b.textContent='▶ Continue ('+rem.length+'টি ধাপ বাকি)';b.style.cssText='margin:8px 0;padding:10px 18px;border-radius:999px;border:1.5px solid #8dffc0;background:rgba(20,60,40,.9);color:#fff;font:inherit;font-weight:600';b.onclick=()=>{if(used||bbusy)return;used=1;bs.forEach(x=>x.remove());EDCHAT=!!EW;edRun(req,0,{plan:rem,note:'\n\nNOTE: This step was cut off earlier; part of it may already be applied in the CURRENT FILE. Check the file and do only what is still missing.'})};bs.push(b);return b};
 try{L.appendChild(mk1())}catch(e){}
 if(EW){const d=add('a','✂️ উত্তর মাঝপথে কেটে গিয়েছিল। যেখানে থেমেছে সেখান থেকে চালাতে চাপো 👇');d.appendChild(mk1())}}
function contChat(w){const b=document.createElement('button');b.textContent='▶ Continue';b.style.cssText='display:block;margin:10px 0 2px;padding:10px 18px;border-radius:999px;border:1.5px solid #8dffc0;background:rgba(20,60,40,.9);color:#fff;font:inherit;font-weight:600';b.onclick=()=>{if(busy)return;b.remove();FORCEROUTE='CHAT';$('#inp').value='তুমি মাঝপথে থেমে গিয়েছিলে। ঠিক যেখানে থেমেছো সেখান থেকে চালিয়ে যাও, আগের অংশ আবার লিখো না।';send()};w.appendChild(b)}
async function edRun(req,upd,pre){if(bbusy)return;req=(req||'').replace(/\s*Return the COMPLETE[\s\S]*$/,'').trim();
 if(!bcode)return toast('আগে 📎 দিয়ে কোড/ZIP নাও');if(!req)return toast('কী বদলাতে চাও লেখো');
 const mv=$('#bmd').value;if(!mv)return toast('আগে Settings-এ API key + model দাও');const [id,model]=mv.split('|');
 const L=$('#blg');L.style.display='block';L.innerHTML='';
 const EW=EDCHAT?add('a','✏️ কোড এডিট — ধাপে ধাপে করছি…'):null;
 const lg=(t,c)=>{const d=document.createElement('div');d.textContent=t;if(c)d.style.color=c;L.appendChild(d);try{d.scrollIntoView({block:'nearest'})}catch(e){}
  if(EW){const m=document.createElement('div');m.textContent=t;if(c)m.style.color=c;EW.appendChild(m);d._m=m;try{$('#msgs').scrollTop=1e9}catch(e){}}return d};
 bbusy=1;$('#bgo').disabled=$('#bup').disabled=true;$('#bgo').textContent='⏳ এডিট চলছে…';$('#bst').textContent='';
 let stopFn=null;const stopP=new Promise(r=>stopFn=r);const sb=document.createElement('button');sb.textContent='⏹ Stop';sb.style.cssText='position:fixed;left:50%;transform:translateX(-50%);bottom:calc(170px + env(safe-area-inset-bottom,0px));z-index:99998;padding:10px 20px;border-radius:999px;border:1.5px solid #ff8a8a;background:rgba(60,10,30,.95);color:#fff;font:inherit;font-weight:600';sb.onclick=()=>{stopFn();sb.remove()};document.body.appendChild(sb);
 const base=bcode,mk=mask(base),w0=WEB;let cur=mk.t,bl0=synErr(cur).length;
 lg('📖 কোড পড়ছি… '+base.split('\n').length+' লাইন, '+Math.round(base.length/1024)+' KB'+(mk.mp.length?' ('+mk.mp.length+'টি ইমেজ ডাটা সরিয়ে হালকা করেছি)':''));
 if(id!='gemini'&&cur.length>150000)lg('⚠️ ফাইল অনেক বড়। বড় ফাইলের জন্য Gemini মডেল সবচেয়ে ভালো।','#ffcf6e');
 const ai=async(sys,u,att)=>{BLD=true;WEB=false;try{return await Promise.race([call(id,model,[{role:'user',content:u,att:att}],sys,()=>{}),stopP.then(()=>{throw new Error('STOP')})])}finally{BLD=false;WEB=w0}};
 const cm=codeMap(cur);lg('🗺 কোড ম্যাপ বানালাম: '+cm.nf+'টি ফাংশন, '+cm.ni+'টি id');
 let plan=[],resumeAt=-1;const stepMode=emStep&&(upd?cur.length>30000:true);
 try{
  if(EDSHOT&&EDSHOT.length){const sh=EDSHOT;EDSHOT=null;lg('🖼 স্ক্রিনশট দেখছি…');try{const nt=await ai('You describe app UI screenshots precisely for a developer. Plain text only.','USER REQUEST: '+req+'\n\nLook at the attached screenshot of the app. In 3-5 short lines say which screen or section it is, the exact visible text/labels of the element(s) the user is talking about, and what looks wrong or what the user is pointing at.',sh);if(nt&&nt.trim()){req+='\n\nSCREENSHOT NOTES (what the user showed in the screenshot): '+nt.trim().slice(0,900);lg('✅ স্ক্রিনশট বুঝেছি','#8dffc0')}}catch(e){if(e.message=='STOP')throw e;lg('⚠️ স্ক্রিনশট পড়া যায়নি (এই মডেল ছবি নাও বুঝতে পারে) — লেখা দেখেই এগোচ্ছি','#ffcf6e')}}
  if(stepMode&&!pre){lg('🧭 পরিকল্পনা বানাচ্ছি…');const pa=await ai(PL_SYS,'REQUEST:\n'+req+'\n\n'+cm.text+'\n\nFILE:\n'+cur);plan=(pa.match(/^\s*\d+[.)]\s*.+$/gm)||[]).map(x=>x.replace(/^\s*\d+[.)]\s*/,'').trim()).filter(Boolean).slice(0,7)}
  if(pre)plan=pre.plan.slice();if(!plan.length)plan=[req];if(plan.length>1)plan.forEach((p,i)=>lg((i+1)+'. '+p,'#9be7ff'));
  if(EDCHAT&&plan.length>1&&!pre){const keep=await planConfirm(plan,stopP);if(!keep.length)throw new Error('STOP');plan=keep}
  const ask=(i,extra)=>ai(ED_SYS,'OVERALL REQUEST:\n'+req+((plan.length>1||pre)?'\n\nFULL PLAN:\n'+plan.map((p,k)=>(k+1)+'. '+p).join('\n')+'\n\nIMPLEMENT NOW ONLY STEP '+(i+1)+': '+plan[i]+'\n(Earlier steps are already applied in the file.)':'')+(extra||'')+(pre&&pre.note&&i==0?pre.note:'')+'\n\n'+cm.text+'\n\nCURRENT FILE:\n'+cur);
  const doStep=async i=>{const prev=cur;let extra='';
   for(let a=0;a<2;a++){cur=prev;let ok=0,msg='',tries=0,out=await ask(i,extra);
    for(;;){const r=applyBlocks(cur,parseBlocks(out));cur=r.t;ok+=r.ok;const sm=out.match(/SUMMARY:\s*(.+)/);if(sm)msg=sm[1].trim();
     if(r.fail.length&&tries<2){tries++;lg('   ⚠️ '+r.fail.length+'টি এডিট মেলেনি, ঠিক করছি… ('+tries+')','#ffcf6e');
      out=await ai(ED_SYS,'Some of your edits could not be applied. For each failed block you get the reason, your block and the real nearby text. Reply with corrected EDITS blocks for these only (SEARCH copied verbatim from the real text).\n\n'+r.fail.map((f,k)=>'--- FAILED '+(k+1)+' ('+f.why+')\nYOUR SEARCH:\n'+f.b.s+'\nYOUR REPLACE:\n'+f.b.r+'\nREAL TEXT NEAR IT:\n'+excerpt(cur,f.b.s)).join('\n\n')+'\n\nCURRENT FILE (for reference):\n'+cur);continue}
     if(r.fail.length)lg('   ⚠️ '+r.fail.length+'টি ছোট এডিট প্রয়োগ হয়নি','#ffcf6e');break}
    if(!ok){cur=prev;return{ok:0,msg:'কোনো বদল প্রয়োগ হয়নি',cut:LASTCUT}}
    if(cur.length<prev.length*0.7&&!SHRINKOK.test(req)){cur=prev;return{ok:0,msg:'ফাইল অস্বাভাবিক ছোট হয়ে যাচ্ছিল, ধাপটি বাদ দিলাম (ফাইল অক্ষত)'}}
    const er=synErr(cur);
    if(er.length>bl0){if(a==0){lg('   ⚠️ JS সিনট্যাক্স ভেঙে যাচ্ছিল ('+er[0].slice(0,70)+') — আরেকবার চেষ্টা…','#ffcf6e');extra='\n\nYOUR PREVIOUS ATTEMPT BROKE JAVASCRIPT SYNTAX ('+er[0]+'). Redo this step carefully so the file stays valid.';continue}
     cur=prev;return{ok:0,msg:'কোড ভাঙছিল, তাই ধাপটি বাদ দিয়েছি (আগের অবস্থা অক্ষত)'}}
    bl0=er.length;return{ok,msg,cut:LASTCUT}}
   cur=prev;return{ok:0,msg:'ব্যর্থ'}};
  let good=0;const stepLog=[];
  for(let i=0;i<plan.length;i++){const head=lg('✏️ ধাপ '+(i+1)+'/'+plan.length+(plan.length>1?': '+plan[i]:' — এডিট করছি…'));
   let r;try{r=await doStep(i)}catch(e){if(e.message=='STOP')throw e;r={ok:0,msg:'কেটে গেছে: '+String(e.message).slice(0,80),cut:1}}stepLog.push({s:plan[i],m:r.msg||'',ok:r.ok});if(r.ok)good++;head.textContent=(r.ok?'✅':'⚠️')+' ধাপ '+(i+1)+'/'+plan.length+(plan.length>1?': '+plan[i]:'')+(r.msg?' — '+r.msg:'');head.style.color=r.ok?'#8dffc0':'#ffcf6e';if(head._m){head._m.textContent=head.textContent;head._m.style.color=head.style.color}if(r.cut){resumeAt=i;lg('✂️ ধাপ '+(i+1)+'-এ উত্তর কেটে গেছে — নিচের ▶ Continue চাপলে এখান থেকেই চলবে।','#ffcf6e');break}}
  if(!good){lg('❌ কোনো পরিবর্তন করা যায়নি। অন্য মডেল বেছে বা নির্দেশ আরও স্পষ্ট করে আবার চেষ্টা করো।','#ff8a8a')}
  else{lg('🔍 যাচাই করছি…');let fin=unmask(cur,mk.mp);
   if(fin.length<base.length*0.7&&!SHRINKOK.test(req)){lg('⛔ ফাইল '+Math.round(base.length/1024)+' KB থেকে '+Math.round(fin.length/1024)+' KB হয়ে যাচ্ছিল — নিরাপত্তার জন্য বদল বাতিল করে আগের ফাইলই রেখেছি।','#ff8a8a');if(EDCHAT){EDCHAT=false;add('a','⛔ এডিটে ফাইল অনেক ছোট হয়ে যাচ্ছিল ('+Math.round(base.length/1024)+' KB → '+Math.round(fin.length/1024)+' KB), তাই বাতিল করে আগের ফাইল অক্ষত রেখেছি। অনুরোধ আরও নির্দিষ্ট করে আবার বলো।')}}
   else{
   lg('🧪 চালিয়ে পরীক্ষা করছি…');
   try{const rr=await Promise.race([Promise.all([runCheck(base),runCheck(fin)]),stopP.then(()=>{throw new Error('STOP')})]),eb=rr[0],ne=rr[1].filter(x=>!eb.includes(x)&&!NOISE.test(x));
    if(ne.length){lg('🐞 '+ne.length+'টি নতুন এরর পেয়েছি — নিজে ঠিক করছি…','#ffcf6e');
     const out=await ai(ED_SYS,'The edited app now throws these NEW runtime errors (they were not there before the edit):\n'+ne.join('\n')+'\n\nFix them with minimal EDITS blocks. Change nothing else.\n\n'+cm.text+'\n\nCURRENT FILE:\n'+cur);
     const r2=applyBlocks(cur,parseBlocks(out));
     if(r2.ok&&synErr(r2.t).length<=bl0){const f2=unmask(r2.t,mk.mp),e2=(await runCheck(f2)).filter(x=>!eb.includes(x)&&!NOISE.test(x));
      if(e2.length<ne.length){cur=r2.t;fin=f2;lg(e2.length?'⚠️ এরর কমেছে, কিছু বাকি আছে — Review করে 🐞 Debug দিও':'✅ এরর ঠিক হয়েছে','#8dffc0')}else lg('⚠️ অটো-ফিক্সে উন্নতি হয়নি, আগের এডিটই রাখলাম — Review দেখো','#ffcf6e')}
     else lg('⚠️ অটো-ফিক্স প্রয়োগ হয়নি, Review দেখো','#ffcf6e')}
    else lg('✅ কোনো নতুন এরর নেই','#8dffc0')}catch(e){if(e.message=='STOP')throw e;lg('⚠️ অটো-টেস্ট চালানো যায়নি','#ffcf6e')}
   EV.push({t:base,l:req.slice(0,40)});if(EV.length>8)EV.shift();
   bcode=fin;if(EP)EP.files[EP.main].text=fin;bShow(fin,true);bsave();const d=dstat(base,fin);
   lg('✅ শেষ! +'+d.add+' / −'+d.rem+' লাইন বদলেছে। থিম, ডিজাইন ও বাকি সব ফিচার যেমন ছিল তেমনই আছে।','#8dffc0');try{edLogAdd(req,stepLog,d,base.length,fin.length)}catch(e){}if(EDCHAT){EDCHAT=false;const sm=stepLog.map(x=>(x.ok?'✅ ':'⚠️ ')+x.s+(x.m?' — '+x.m:'')).join('\n');const wb=add('a','✅ এডিট শেষ — +'+d.add+' / −'+d.rem+' লাইন বদলেছে ('+Math.round(base.length/1024)+' KB → '+Math.round(fin.length/1024)+' KB)।'+(sm?'\n\n'+sm:'')+'\n\n▶ Review চাপলে সরাসরি এখানেই চলবে, ZIP/ফাইল নিচে 👇');if(/<html|<!doctype/i.test(bcode))wb.appendChild(revCard());wb.appendChild(mkCards());wb.appendChild(editChips(true))}lg('👉 ▶ Review চাপলে এখানেই চলবে। ঠিক থাকলে 🗜 ZIP নাও। পছন্দ না হলে ↩ Undo।');
   $('#bun').style.display='';if(upd)$('#bed').value=''}}
 }catch(e){if(e.message=='STOP'){lg('⏹ থামানো হয়েছে — ফাইল আগের মতোই অক্ষত আছে।','#ffcf6e');if(EDCHAT){EDCHAT=false;add('a','⏹ থামিয়ে দিয়েছি। ফাইলে কোনো বদল হয়নি।')}}else lg('❌ '+e.message,'#ff8a8a')}
 if(EDCHAT){EDCHAT=false;add('a','❌ এডিট সম্পন্ন করা যায়নি। উপরের লগ দেখো, অনুরোধ আরও স্পষ্ট করে আবার বলো। ফাইল অক্ষত আছে।')}
 try{sb.remove()}catch(e){}WEB=w0;bbusy=0;if(resumeAt>=0)contBtn(req,plan.slice(resumeAt),L,EW);$('#bgo').disabled=$('#bup').disabled=false;bTools()}
const _bT=bTools;bTools=function(){_bT();const y=$('#bty');{let ch=$('#bchips');if(!ch){ch=document.createElement('div');ch.id='bchips';const pvv=$('#bpv');if(pvv&&pvv.parentNode)pvv.parentNode.insertBefore(ch,pvv.nextSibling)}ch.innerHTML='';ch.style.display='none';if(bk=='edit'){ch.style.display='block';ch.appendChild(editChips(false))}}
 if(bk=='edit'){y.style.display='flex';y.innerHTML=['🐢 ধাপে ধাপে (ভালো)','⚡ দ্রুত (এক ধাপে)'].map((d,i)=>`<button class="${(i==0)==emStep?'on':''}" data-m="${i}">${d}</button>`).join('');y.querySelectorAll('button').forEach(b=>b.onclick=()=>{emStep=b.dataset.m=='0';bTools()})}
 if(!bbusy){$('#bgo').textContent=bk=='edit'?'✏️ Edit করো':'⚡ Build করো';$('#bat').textContent=bk=='edit'?'📎 কোড / ZIP':'📎 Screenshot'}};
$('#bat').onclick=()=>bk=='edit'?$('#bfe').click():$('#bfi').click();
$('#bfe').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;try{await edLoadFile(f);toast('✅ প্রজেক্ট নেওয়া হয়েছে — এখন কী বদলাবে লেখো')}catch(x){toast('ফাইল পড়া যায়নি: '+x.message)}};
$('#bun').onclick=()=>{const v=EV.pop();if(!v)return;bcode=v.t;if(EP)EP.files[EP.main].text=v.t;bShow(v.t,true);bsave();$('#bun').style.display=EV.length?'':'none';toast('↩ আগের ভার্সনে ফেরা হয়েছে')};
const _z=$('#bzp').onclick;$('#bzp').onclick=()=>{if(!EP||!bcode)return _z();const fs=Object.keys(EP.files).map(n=>({n,d:n==EP.main?bcode:(EP.files[n].bytes||EP.files[n].text)}));bSave(new File([mkzip(fs)],'mayra-project.zip',{type:'application/zip'}))};
BT.push({k:'edit',e:'✏️',n:'Code Editor',s:'বড় কোড ধাপে ধাপে এডিট',ph:'কী বদলাতে/যোগ করতে চাও? যেমন: মেনুতে Settings অপশন যোগ করো (থিম বদলিও না)',sys:''});

