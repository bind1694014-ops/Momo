/* ===== Mayra Smart Memory + Auto Core v3 (auto: শেখে, মেলায়, ছাঁটে, মনে করায়) ===== */
(()=>{
const MK='mayra_mem',MAX=400,CORE_MAX=18,REL_MAX=12,DAY=864e5;
const nf=s=>String(s==null?'':s).normalize('NFC');
const REL={mother:'মা|মায়ের|মাকে|আম্মু|আম্মা|ma|mayer|amma|ammu|mom|mother|mum',
father:'বাবা|বাবার|আব্বু|আব্বা|baba|babar|abbu|abba|dad|father',
wife:'বউ|বৌ|বউয়ের|বৌয়ের|স্ত্রী|স্ত্রীর|bou|bouer|stri|wife',
husband:'স্বামী|স্বামীর|shami|husband',
brother:'ভাই|ভাইয়ের|bhai|bhaier|brother|দাদা|dada',
sister:'বোন|বোনের|আপু|আপুর|apu|bon|boner|sister',
friend:'বন্ধু|বন্ধুর|bondhu|bondhur|friend',
son:'ছেলে|ছেলের|chele|cheler|son',
daughter:'মেয়ে|মেয়ের|meye|meyer|daughter',
grandparent:'দাদু|দাদি|নানা|নানি|dadu|dadi|nana|nani'};
const AL={birthday:'জন্মদিন|jonmodin|janmadin|birthday|বার্থডে',name:'নাম|nam|name',live:'থাকি|থাকে|thaki|thake|live|lives|ঠিকানা|address|location',job:'চাকরি|চাকরী|job|পেশা|profession|occupation|works|work',like:'পছন্দ|pochondo|like|likes|love|loves|ভালোবাসি|valobashi|favorite|favourite|fav'};
const CAN=new Map();
[REL,AL].forEach(g=>Object.keys(g).forEach(k=>nf(g[k]).split('|').forEach(w=>CAN.set(w.toLowerCase(),k))));
const RELW=nf(Object.values(REL).join('|'));
const RELK=Object.keys(REL);
const STOP=new Set('ami amar আমি আমার amake আমাকে the is are was a an of to in on at and or for my user users that this with has have his her their এবং ও এর এই সেই হলো হল holo'.split(' '));
const TK=/[\p{L}\p{M}\p{N}]+/gu;
function toks(s){const o=new Set();(nf(s).toLowerCase().match(TK)||[]).forEach(w=>{w=CAN.get(w)||w;if(w.length<2||STOP.has(w))return;o.add(w)});return o}
const CATS=['id','fam','pref','work','loc','date','goal','misc'];
const EM={id:'🪪',fam:'👪',pref:'❤️',work:'💼',loc:'📍',date:'📅',goal:'🎯',misc:'🧩'};
function guess(t){const s=toks(t),l=t.toLowerCase();
 if(RELK.some(r=>s.has(r)))return 'fam';
 if(s.has('birthday')||/\d{1,2}[\/\-.]\d{1,2}|january|february|march|april|june|july|august|september|october|november|december/.test(l))return 'date';
 if(s.has('live'))return 'loc';
 if(s.has('job')||/developer|student|engineer|teacher|doctor|business|project|designer|freelanc/.test(l))return 'work';
 if(s.has('like')||/prefer|dislike|hate|favorite/.test(l))return 'pref';
 if(s.has('name'))return 'id';
 if(/goal|want to|wants to|plan to|learning|dream/.test(l))return 'goal';
 return 'misc'}
function keyOf(t){const s=toks(t),l=t.toLowerCase();
 const r=['mother','father','wife','husband'].find(r=>s.has(r));
 if(r){if(s.has('name'))return 'fam:'+r+':name';if(s.has('birthday'))return 'fam:'+r+':bday';return ''}
 if(RELK.some(r=>s.has(r)))return '';
 if(s.has('birthday'))return 'bday';
 if(/(^|\W)(user'?s? name|my name)/.test(l))return 'name';
 if(/user lives|lives in|based in|user's (?:home|address|location)/.test(l))return 'loc';
 if(/user works|works (?:as|at)|occupation|profession|user's job/.test(l))return 'job';
 return ''}
function norm(x){if(!x||typeof x.t!='string'||!x.t.trim())return null;
 const t=nf(x.t).trim().slice(0,240);
 return{id:x.id||Date.now().toString(36)+Math.random().toString(36).slice(2,6),t,c:CATS.includes(x.c)?x.c:guess(t),
  imp:Math.min(5,Math.max(1,+x.imp||(x.c?3:4))),k:x.k||keyOf(t),ts:x.ts||Date.now(),last:x.last||x.ts||Date.now(),n:x.n||0,pin:!!x.pin}}
function memGet(){let a=[];try{a=JSON.parse(localStorage.getItem(MK)||'[]')}catch(e){}if(!Array.isArray(a))return[];const o=[];a.forEach(x=>{const n=norm(x);if(n)o.push(n)});return o}
function wr(l){try{localStorage.setItem(MK,JSON.stringify(l))}catch(e){try{l.sort((a,b)=>keep(b,Date.now())-keep(a,Date.now()));localStorage.setItem(MK,JSON.stringify(l.slice(0,Math.floor(l.length/2))))}catch(x){}}}
const keep=(x,now)=>x.pin?1e3:x.imp*10+Math.exp(-(now-x.last)/DAY/90)*5+Math.min(x.n,10);
function upsert(m,p){const it=norm(p);if(!it)return 0;
 if(it.k){const i=m.findIndex(x=>x.k==it.k);if(i>=0){if(m[i].t.toLowerCase()==it.t.toLowerCase()){m[i].ts=Date.now();return 0}
  it.id=m[i].id;it.imp=Math.max(it.imp,m[i].imp);it.pin=m[i].pin;it.n=m[i].n;m[i]=it;return 1}}
 const a=toks(it.t);
 for(let i=0;i<m.length;i++){const b=toks(m[i].t);let n=0;a.forEach(w=>{if(b.has(w))n++});const u=a.size+b.size-n,mn=Math.min(a.size,b.size);
  if(u&&(n/u>=.7||(mn>=3&&n/mn>=.9))){if(it.t.length>m[i].t.length)m[i].t=it.t;m[i].imp=Math.max(m[i].imp,it.imp);m[i].ts=Date.now();m[i].pin=m[i].pin||it.pin;return 0}}
 m.push(it);return 1}
function memSet(a){const o=[];(Array.isArray(a)?a:[]).map(norm).filter(Boolean).sort((x,y)=>x.ts-y.ts).forEach(x=>upsert(o,x));
 const now=Date.now();let l=o.filter(x=>x.pin||x.imp>=3||x.n>0||now-x.ts<180*DAY);
 if(l.length>MAX){l.sort((x,y)=>keep(y,now)-keep(x,now));l=l.slice(0,MAX)}wr(l)}
function sc(m,q,now){let o=0;if(q&&q.size)toks(m.t).forEach(w=>{if(q.has(w))o++});
 return{o,s:o*3+m.imp+(m.pin?10:0)+1.5*Math.exp(-(now-m.last)/DAY/60)+Math.min(m.n,5)*.2}}
function pick(qs){const m=memGet(),now=Date.now(),q=toks(qs);
 const core=m.filter(x=>x.pin||x.imp>=4||x.c=='id'||x.c=='fam').map(x=>({x,r:sc(x,q,now)})).sort((a,b)=>b.r.s-a.r.s).slice(0,CORE_MAX);
 const ids=new Set(core.map(a=>a.x.id));
 let rel=m.filter(x=>!ids.has(x.id)).map(x=>({x,r:sc(x,q,now)})).filter(a=>a.r.o>0).sort((a,b)=>b.r.s-a.r.s).slice(0,REL_MAX);
 if(rel.length<3){const ex=new Set(rel.map(a=>a.x.id));rel=rel.concat(m.filter(x=>!ids.has(x.id)&&!ex.has(x.id)).sort((a,b)=>b.ts-a.ts).slice(0,3-rel.length).map(x=>({x})))}
 return{core:core.map(a=>a.x),rel:rel.map(a=>a.x)}}
let tm=0;function touch(a){const s=new Set(a.map(x=>x.id));if(!s.size)return;clearTimeout(tm);tm=setTimeout(()=>{try{const m=memGet();m.forEach(x=>{if(s.has(x.id)){x.n++;x.last=Date.now()}});wr(m)}catch(e){}},1500)}
function parseTag(t){t=nf(t).trim();const m=t.match(/^(id|fam|pref|work|loc|date|goal|misc)\s*\|\s*([1-5])\s*\|\s*([\s\S]+)$/i);
 return m?{c:m[1].toLowerCase(),imp:+m[2],t:m[3].trim()}:(t?{t,imp:3}:null)}
function ex(u,expl){const out=[],add=(t,c,imp)=>{if(out.length<6)out.push({t,c,imp})};
 const S=nf(u).replace(/\[Attached file[\s\S]*$/,'').slice(0,1500).split(/[\n।.!?]+/).map(x=>x.trim()).filter(x=>x.length>4&&x.length<220);
 const rl=w=>CAN.get(nf(w).toLowerCase())||w;
 for(const s of S){let m;
  if(m=s.match(/(?:amar\s+nam(?:\s+holo)?|আমার\s+নাম(?:\s+হলো)?|my\s+name\s+is|call\s+me)\s+([^\s,;:]{2,20})/iu)){if(!/^(ki|কি|কী|what)$/i.test(m[1]))add("User's name is "+m[1],'id',5)}
  if(m=s.match(new RegExp('(?:amar|আমার|my)\\s+('+RELW+")(?:'s|\\s*(?:er|এর|র))?\\s+(?:nam|নাম|name)(?:\\s+(?:holo|হলো|হল|is))?\\s+([^\\s,;:]{2,20})",'iu'))){if(!/^(ki|কি|কী|what)$/i.test(m[2]))add("User's "+rl(m[1])+"'s name is "+m[2],'fam',5)}
  if(m=s.match(new RegExp('(?:amar|আমার|my)\\s+(?:('+RELW+")(?:'s|\\s*(?:er|এর|র))?\\s+)?(?:jonmodin|janmadin|জন্মদিন|birthday)\\s*(?:holo|হলো|হল|is|:)?\\s*(.{3,30})",'iu'))){if(!/^(kobe|কবে|when)/i.test(m[2]))add("User's "+(m[1]?rl(m[1])+"'s ":'')+"birthday is "+m[2],'date',5)}
  if(m=s.match(/(?:ami|আমি)\s+([^\s,;]{2,25}?)(?:\s*-?(?:te|তে|এ))?\s+(?:thaki|থাকি)/iu)||s.match(/\bi\s+live\s+in\s+([^,;]{2,30})/i))add('User lives in '+m[1],'loc',4);
  if(m=s.match(/(?:ami|আমি|i\s+am\s+an?|i'm\s+an?)\s+(?:একজন\s+|ekjon\s+)?([^\s,।]*?(?:ছাত্র|student|developer|ডেভেলপার|engineer|ইঞ্জিনিয়ার|teacher|শিক্ষক|doctor|ডাক্তার|ব্যবসায়ী|businessman|designer|ডিজাইনার|programmer|প্রোগ্রামার|freelancer|ফ্রিল্যান্সার|driver|ড্রাইভার))/iu))add('User works as / is a '+m[1],'work',4);
  if(m=s.match(/\bmy\s+fav(?:ou?rite)?\s+([\w ]{2,20}?)\s+is\s+([^,;]{2,40})/i)||s.match(/(?:amar|আমার)\s+(.{2,20}?)\s+(?:pochondo|পছন্দ)(?:er|ের)?\s+(?:holo|হলো|হল)?\s*([^,;]{2,40})/iu))add("User's favorite "+m[1]+' is '+m[2],'pref',3);
  else if(m=s.match(/(?:ami|আমি|\bi)\s+(.{2,40}?)\s+(?:pochondo\s+kori\s+na|পছন্দ\s+করি\s+না|ghrina\s+kori|ঘৃণা\s+করি|hate|dislike)/iu))add('User dislikes '+m[1],'pref',3);
  else if(m=s.match(/(?:ami|আমি|\bi)\s+(.{2,40}?)\s+(?:valobashi|ভালোবাসি|pochondo\s+kori|পছন্দ\s+করি|love|like)(?!\p{L})/iu)){if(!/^(tomake|তোমাকে|you|তুমি|tumi|your)/i.test(m[1]))add('User likes '+m[1],'pref',2)}
  if(expl){if(m=s.match(/(.{3,200}?)[\s,]*(?:mone\s+rakho|mone\s+rekho|মনে\s+রাখো|মনে\s+রেখো|মনে\s+রাখবে|remember\s+(?:this|that)|save\s+this)/iu))add('User asked to remember: '+m[1].trim(),'misc',5);
   else if(m=s.match(/^(?:mone\s+rakho|মনে\s+রাখো|remember(?:\s+that)?)\s*[:,]?\s*(.{3,200})/iu))add('User asked to remember: '+m[1].trim(),'misc',5)}}
 return out}
function lastUser(){try{for(let i=hist.length-1;i>=0;i--)if(hist[i].role=='user')return String(hist[i].show!==undefined?hist[i].show:hist[i].content)}catch(e){}return''}
function curQ(){try{let s='',c=0;for(let i=hist.length-1;i>=0&&c<3;i--)if(hist[i].role=='user'){s+=' '+String(hist[i].show!==undefined?hist[i].show:hist[i].content).slice(0,500);c++}return s}catch(e){return''}}
const RULES="\n\nMEMORY RULES (fully automatic and silent): Whenever the user reveals ANY lasting fact — name, family members and their names, birthdays/important dates, place, job, skills, projects, goals, preferences, dislikes, habits, health/diet needs, relationships — or asks you to remember something, reply normally and append at the very END, on new lines, one tag per fact: [[MEM: category|importance|short complete fact in English]]. category is one of id, fam, pref, work, loc, date, goal, misc. importance 1-5 (5 = identity/family/critical, 3 = normal, 1 = trivia). Example: [[MEM: fam|5|User's mother's name is Rahima]]. If a new fact changes an old one, just tag the new fact (it replaces the old). To delete: [[FORGET: keyword]]. Skip casual or temporary info. Never mention, show or explain these tags or that you saved anything.";
let FR='';try{const t=window.MEMS(0),i=t.indexOf('\n\nFILE RULES:');if(i>=0)FR=t.slice(i)}catch(e){}
window.MEMS=function(v){const p=pick(curQ());touch(p.core.concat(p.rel));const f=x=>'- '+x.t;
 let r='\n\n[CORE PROFILE — permanent facts about the user, auto-maintained. Always remember them and use them naturally; never say you looked them up]\n'+(p.core.length?p.core.map(f).join('\n'):'(empty)');
 if(p.rel.length)r+='\n\n[RELEVANT MEMORIES — auto-recalled for this message]\n'+p.rel.map(f).join('\n');
 if(!v)r+=RULES+FR;return r};
window.memProc=function(a){let m=memGet(),ch=0,add=0,tg=0;
 a.replace(/\[\[\s*MEM\s*:\s*([\s\S]*?)\]\]/g,(_,t)=>{tg++;const p=parseTag(t);if(p){if(upsert(m,p))add++;ch=1}return ''});
 a.replace(/\[\[\s*FORGET\s*:\s*([\s\S]*?)\]\]/g,(_,k)=>{k=nf(k).trim().toLowerCase();if(k){const kt=toks(k),n=m.length;m=m.filter(x=>{if(x.t.toLowerCase().includes(k))return false;if(kt.size){const xt=toks(x.t);let all=1;kt.forEach(w=>{if(!xt.has(w))all=0});if(all)return false}return true});if(m.length!=n)ch=1}return ''});
 try{const u=lastUser();if(u)ex(u,!tg).forEach(p=>{if(upsert(m,p)){add++;ch=1}})}catch(e){}
 if(ch){memSet(m);try{mdraw()}catch(e){}try{toast(add?'🧠 মনে রাখলাম ✓':'🧠 Memory আপডেট ✓')}catch(e){}}
 return MCm(a)};
window.memGet=memGet;window.memSet=memSet;
window.mdraw=function(){const L=document.getElementById('ml');if(!L)return;
 const m=memGet().sort((a,b)=>(b.pin-a.pin)||(b.imp-a.imp)||(b.ts-a.ts));
 const core=m.filter(x=>x.pin||x.imp>=4||x.c=='id'||x.c=='fam').length;
 L.innerHTML=m.length?'<div class="q-cap" style="margin:0 0 8px">🧠 '+m.length+' memory · ⭐ core '+Math.min(core,CORE_MAX)+' · অটো: নিজে শেখে, মেলায়, পুরনো ছাঁটে, দরকারে মনে করায়</div>'+m.map(x=>'<div class="q-y" style="display:flex;gap:8px;align-items:center;padding:10px 12px"><span>'+(EM[x.c]||'🧩')+'</span><div style="flex:1;font-size:14px;line-height:1.6">'+esc(x.t)+'</div><button class="q-t" data-p="'+x.id+'">'+(x.pin?'⭐':'☆')+'</button><button class="q-t" data-d="'+x.id+'">🗑</button></div>').join('')+'<button class="q-b" id="mclr" style="margin-top:6px">সব মুছুন</button>':'<div class="q-ld">এখনো কিছু সেভ নেই।<br>শুধু কথা বলো — Mayra নিজেই মনে রাখবে।</div>';
 L.querySelectorAll('[data-d]').forEach(b=>b.onclick=()=>{memSet(memGet().filter(x=>x.id!=b.dataset.d));window.mdraw()});
 L.querySelectorAll('[data-p]').forEach(b=>b.onclick=()=>{const a=memGet(),x=a.find(y=>y.id==b.dataset.p);if(x)x.pin=!x.pin;memSet(a);window.mdraw()});
 const c=document.getElementById('mclr');if(c)c.onclick=()=>{if(confirm('সব Memory মুছে ফেলবে?')){memSet([]);window.mdraw()}}};
window.__memTest={ex,upsert,norm,pick,toks,keyOf,parseTag};
try{memSet(memGet())}catch(e){}
})();
