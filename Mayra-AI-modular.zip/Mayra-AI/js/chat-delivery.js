/* ---------- chat file delivery (zip / file cards) ---------- */
let LASTF=null,bts=0;
const ICO={html:'&lt;/&gt;',htm:'&lt;/&gt;',css:'🎨',js:'JS',json:'{ }',py:'🐍',txt:'📄',md:'📝',zip:'🗜'};
const safeName=n=>(n.split(/[\\/]/).pop()||'file.txt').replace(/[^\w.\-() ]/g,'_').slice(0,60)||'file.txt';
function parseFiles(a){const out=[],re=/\[\[FILE:\s*([^\]\n]+?)\s*\]\]\r?\n?([\s\S]*?)\r?\n?\[\[ENDFILE\]\]/g;let m;while((m=re.exec(a)))out.push({name:safeName(m[1]),code:m[2].replace(/^\s*```[\w+-]*\r?\n/,'').replace(/\r?\n```\s*$/,'')});return out}
function parseFences(a){const out=[],re=/```([\w+-]*)[ \t]*\r?\n([\s\S]*?)```/g,ex={html:'html',css:'css',js:'js',javascript:'js',python:'py',py:'py',json:'json',md:'md'};let m,n=0;
 while((m=re.exec(a))){if(m[2].split('\n').length<40)continue;const e=ex[(m[1]||'').toLowerCase()]||'txt';n++;out.push({name:e=='html'?(n==1?'index.html':'page'+n+'.html'):e=='css'?'style.css':e=='js'?'script.js':'code'+n+'.'+e,code:m[2].replace(/\n$/,'')})}return out}
async function fileCardsFrom(el,items){const fs=[];
 for(const it of items){let d=null;if(it.code!=null)d=it.code;else if(it.file)d=new Uint8Array(await it.file.arrayBuffer());else if(it.text!=null)d=it.text;else if(it.data){const b=atob(it.data),u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);d=u}if(d!=null)fs.push({n:safeName(it.name||'file.txt'),d})}
 if(!fs.length)return;const box=document.createElement('div');
 const mkf=f=>{const e=(f.n.split('.').pop()||'').toLowerCase();return new File([f.d],f.n,{type:e=='html'?'text/html':e=='zip'?'application/zip':'application/octet-stream'})};
 if(!(fs.length==1&&/\.zip$/i.test(fs[0].n))){const zf=new File([mkzip(fs)],fs.length==1?fs[0].n.replace(/\.[^.]+$/,'')+'.zip':'mayra-files.zip',{type:'application/zip'});box.appendChild(cardEl('🗜','#2b1470',pretty(zf.name),'ZIP · '+fkb(zf.size)+(fs.length>1?' · '+fs.length+'টি ফাইল':''),zf))}
 fs.slice(0,6).forEach(f=>{const e=(f.n.split('.').pop()||'').toLowerCase(),file=mkf(f);box.appendChild(cardEl(ICO[e]||'📄',e=='html'||e=='htm'?'#4a3208':'#1f2a5a',pretty(f.n),(e=='zip'?'ZIP':'Code · '+e.toUpperCase())+' · '+fkb(file.size),file))});
 el.appendChild(box);try{$('#msgs').scrollTop=1e9}catch(x){}}
function fileCards(el,a){let fs=parseFiles(a);if(!fs.length)fs=parseFences(a);if(!fs.length)return;
 {const big=Math.max(bcode?bcode.length:0,...((LASTF&&LASTF.files)||[]).map(f=>(f.code||f.text||'').length||(f.file&&f.file.size)||0)),main=fs.filter(f=>/\.(html?|js|jsx)$/i.test(f.name)),nm=main.length?Math.max(...main.map(f=>f.code.length)):0;
  if(big>20000&&main.length&&nm<big*0.5){const d=document.createElement('div');d.style.cssText='margin-top:8px;padding:10px;border:1.5px solid rgba(255,150,150,.6);border-radius:12px;background:rgba(60,20,40,.6);font-size:14px';d.textContent='⚠️ এই ফাইলটা তোমার প্রজেক্টের ('+Math.round(big/1024)+' KB) চেয়ে অনেক ছোট ('+Math.round(nm/1024)+' KB), তাই ডাউনলোড কার্ড দেখাইনি — সেভ করলে আসল ফাইল মুছে যেত। বদল করতে চাইলে শুধু বলো কী বদলাতে হবে, আমি ধাপে ধাপে এডিট করব।';el.appendChild(d);return}}
LASTF={ts:Date.now(),files:fs.map(f=>({name:f.name,code:f.code}))};fileCardsFrom(el,LASTF.files)}
function histFiles(){for(let i=hist.length-1;i>=0;i--){const m=hist[i],c=typeof m.content=='string'?m.content:'';
 if(m.role=='assistant'){const f=parseFiles(c);if(f.length)return f.map(x=>({name:x.name,code:x.code}));const g=parseFences(c);if(g.length)return g.map(x=>({name:x.name,code:x.code}))}
 else{const r=[...c.matchAll(/\[Attached file: ([^\]\n]+)\]\n([\s\S]*?)(?=\n\n\[Attached file:|\n\[Image attached|$)/g)].map(x=>({name:x[1],code:x[2]}));if(r.length)return r}}return[]}
function chatZip(t,force){if(!force&&(t.length>90||EDQ.test(t))||/explain|ব্যাখ্যা|কিভাবে|কীভাবে|how to|কেন\b/i.test(t))return null;
 const z=/zip|জিপ/i.test(t),f=/(file|ফাইল|download|ডাউনলোড|index\.html)/i.test(t)&&/(da[ow]|dau|দাও|দে\b|dey|pathao|পাঠাও|chai|চাই|download|ডাউনলোড)/i.test(t);if(!force&&!z&&!f)return null;
 return()=>{let items=null,ep=false;const cand=[];if(bcode)cand.push({ts:bts,ep:true});if(LASTF&&LASTF.files.length)cand.push({ts:LASTF.ts,f:LASTF.files});
  cand.sort((a,b)=>b.ts-a.ts);if(cand.length){if(cand[0].ep)ep=true;else items=cand[0].f}else{const h=histFiles();if(h.length)items=h}
  if(!ep&&!items){add('a','কোন ফাইল ZIP করব? আগে 📎 দিয়ে ফাইল দাও, নয়তো আমাকে অ্যাপ/কোড বানাতে বলো — তারপর "zip করে দাও" লিখো।');return}
  const w=add('a','📦 এই নাও — ফাইল নিচে 👇');if(ep)w.appendChild(mkCards());else fileCardsFrom(w,items)}}

