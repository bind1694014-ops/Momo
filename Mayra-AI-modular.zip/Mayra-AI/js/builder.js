/* ---------- Builder Tools ---------- */
let BLD=false;
const BC='You are an elite senior front-end engineer and UI/UX designer. Deliver ONE complete, self-contained HTML file (inline CSS and JavaScript) inside a single ```html code block. Rules: modern polished mobile-first responsive design; everything must actually work (no TODOs, no placeholders); no external images or fonts - use CSS gradients, inline SVG, canvas or emoji; external libraries only from https://cdnjs.cloudflare.com; wrap any localStorage use in try/catch; write all visible text in the same language as the user request (Bangla if they wrote Bangla); clean, well-structured code. After the code block add at most ONE short sentence in Bangla.';
const BT=[
{k:'web',e:'🌐',n:'Website Builder',s:'প্রফেশনাল ওয়েবসাইট',ph:'যেমন: ঢাকার একটি রেস্টুরেন্টের প্রফেশনাল ওয়েবসাইট, মেনু ও টেবিল বুকিং সহ',sys:BC+' TASK: build a PROFESSIONAL multi-section website: sticky navbar with mobile menu, striking hero with call-to-action, features/services, about, gallery/portfolio or pricing, testimonials, FAQ, contact form with client-side validation, footer; smooth scrolling, scroll-reveal animations, light/dark toggle, SEO meta tags and Open Graph, accessible semantic HTML, realistic copy (no lorem ipsum), a cohesive color palette and typography.'},
{k:'app',e:'📱',n:'App Builder',s:'কাজ করা অ্যাপ',ph:'যেমন: দৈনিক খরচের হিসাব রাখার অ্যাপ, চার্ট ও ক্যাটাগরি সহ',sys:BC+' TASK: build a fully working app with real functionality and state: clear screens or bottom tab navigation, forms, add/edit/delete, data persistence, empty states, toasts, smooth micro-interactions, touch-friendly (min 44px targets), installable-app feel.'},
{k:'game',e:'🎮',n:'Game Builder',s:'2D / 3D গেম',ph:'যেমন: ৩D রেসিং গেম, বা Flappy-র মতো সহজ গেম',sys:BC+' TASK: build a complete playable game: start screen, game loop with requestAnimationFrame, touch controls (on-screen buttons, joystick or swipe) AND keyboard, score and high score, rising difficulty, game over with restart, pause, sound effects via WebAudio, juicy effects, canvas that resizes to the screen.'},
{k:'copy',e:'🧬',n:'Copy Builder',s:'যেকোনো app/game/site-এর মতো',ph:'কোন অ্যাপ/গেম/সাইটের মতো বানাবে লেখো (বা Screenshot দাও)। যেমন: Snake গেম / চ্যাট অ্যাপ UI',sys:BC+' TASK: recreate (clone) the app, game or website the user names or shows in the screenshot as faithfully as possible in layout, flow, features and feel. Write ORIGINAL code and original artwork; do NOT copy logos, trademarks, brand names or proprietary assets or text - use clean similar-style stand-ins. If a screenshot is provided, match its layout, spacing and colors closely.'}];
let bk='web',bdim='2D',bimg=null,bcode='',bacc='',BH=[],bbusy=0,berr=[],bpub='';
const bsave=()=>{try{localStorage.setItem('mayra_lastbuild',JSON.stringify({bk,code:bcode,pub:bpub}))}catch(e){}};
function bGet(t){const m=t.match(/```(?:html)?[ \t]*\r?\n([\s\S]*?)```/i)||t.match(/```(?:html)?[ \t]*\r?\n([\s\S]*)$/i);if(m)return m[1].trim();return /<html|<!doctype/i.test(t)?t.trim():''}
function bTools(){$('#bt').innerHTML=BT.map(x=>`<button class="b-c ${x.k==bk?'on':''}" data-k="${x.k}"><i>${x.e}</i><b>${x.n}</b><small>${x.s}</small></button>`).join('');
 $('#bt').querySelectorAll('.b-c').forEach(b=>b.onclick=()=>{bk=b.dataset.k;bTools()});
 const t=BT.find(x=>x.k==bk);$('#bpr').placeholder=t.ph;
 const y=$('#bty');y.style.display=bk=='game'?'flex':'none';y.innerHTML=['2D','3D'].map(d=>`<button class="${d==bdim?'on':''}" data-d="${d}">${d} গেম</button>`).join('')+`<button class="${bonl?'on':''}" data-o="1">🌐 Online</button>`;
 y.querySelectorAll('button').forEach(b=>b.onclick=()=>{if(b.dataset.o)bonl=!bonl;else bdim=b.dataset.d;bTools()})}
function bModels(){const ms=models(),sl=$('#bmd');let cur='';try{cur=localStorage.getItem('mayra_bm')||''}catch(e){}if(!ms.some(x=>x.id+'|'+x.m==cur))cur=sel;
 sl.innerHTML=ms.length?ms.map(x=>`<option value="${esc(x.id+'|'+x.m)}" ${x.id+'|'+x.m==cur?'selected':''}>${esc(P[x.id].n+' · '+x.m)}</option>`).join(''):'<option value="">Settings-এ API key + model দাও</option>';
 sl.onchange=()=>{try{localStorage.setItem('mayra_bm',sl.value)}catch(e){}}}
function bShow(code,h){bcode=code;bts=Date.now();berr=[];bdbg();$('#bout').style.display='block';$('#bco').textContent=code.length>150000?code.slice(0,6000)+'\n…(বড় ফাইল: পুরো কোড 💾 Save বা 🗜 ZIP-এ)':code;const H=h!==false;['#bt1','#bfs','#bpb','#bzp','#bdb','#bsv'].forEach(i=>$(i).style.display=H?'':'none');if(H){$('#bfr').srcdoc=pdoc(code,'tmp');bTab(1)}else bTab(2);bRmx();bCards()}
function bTab(v){$('#bfr').style.display=v==1?'block':'none';$('#bco').style.display=v==1?'none':'block';$('#bt1').classList.toggle('p',v==1);$('#bt2').classList.toggle('p',v!=1)}
async function bRun(upd,msg){if(bk=='edit'&&!upd)return edRun($('#bpr').value.trim());if(upd&&bcode&&bk!='dbg')return edRun(msg||$('#bed').value.trim(),1);if(bbusy)return;const mv=$('#bmd').value;if(!mv)return toast('আগে Settings-এ API key + model দাও');
 const [id,model]=mv.split('|'),t=BT.find(x=>x.k==bk);let ms;
 if(upd){const x=msg||$('#bed').value.trim();if(!x||!bcode)return;BH.push({role:'user',content:msg?msg:'Change request: '+x+'\nReturn the COMPLETE updated HTML file in one ```html block.'});ms=BH}
 else{const x=$('#bpr').value.trim();if(!x)return toast('কী বানাবে লেখো');bpub='';bsid='';bpn=x.split('\n')[0].slice(0,26);EP=null;EV=[];$('#bun').style.display='none';
  BH=[{role:'user',content:x+(bk=='game'?'\n\nGame type: '+bdim+(bdim=='3D'?' - use Three.js r128 from cdnjs.cloudflare.com (no ES modules, no OrbitControls, no CapsuleGeometry), 3D scene with lights, smooth on phones.':' - HTML5 canvas 2D.')+(bonl?ONL:''):''),att:bimg?[bimg]:[]}];ms=BH}
 bbusy=1;BLD=true;$('#bgo').disabled=$('#bup').disabled=true;$('#bgo').textContent='⏳ বানাচ্ছি…';bacc='';let last=0;
 $('#bout').style.display='block';$('#bco').textContent='';bTab(2);$('#bst').textContent='⏳ AI কোড লিখছে… (বড় প্রজেক্টে ১-২ মিনিট লাগতে পারে)';
 try{const a=await call(id,model,ms,t.sys,d=>{bacc+=d;const n=Date.now();if(n-last>400){last=n;const c=$('#bco');c.textContent=bacc.slice(-6000);c.scrollTop=1e9;$('#bst').textContent='⏳ লিখছি… '+Math.round(bacc.length/100)/10+'k অক্ষর'}});
  const code=bk=='dbg'&&!upd?bAny(a):bGet(a);if(!code||code.length<20)throw new Error('কোড পাওয়া যায়নি। আবার চেষ্টা করো বা অন্য মডেল বেছে নাও।');
  const isH=bk!='dbg'||/<html|<!doctype/i.test(code);BH.push({role:'assistant',content:'```'+(isH?'html':'')+'\n'+code+'\n```'});bShow(code,isH);bsave();
  $('#bst').textContent='✅ তৈরি! '+(/```/.test(a.slice(-40))?'':'(কোড কেটে গিয়ে থাকলে Update-এ "বাকিটা শেষ করো" লেখো) ')+'Preview দেখো।';if(bk=='dbg')bEx(a);if(upd)$('#bed').value=''}
 catch(e){if(upd)BH.pop();$('#bst').textContent='❌ '+e.message}
 BLD=false;bbusy=0;$('#bgo').disabled=$('#bup').disabled=false;$('#bgo').textContent='⚡ Build করো'}
$('#bgo').onclick=()=>bRun(0);$('#bup').onclick=()=>bRun(1);
$('#bed').onkeydown=e=>{if(e.key=='Enter'){e.preventDefault();bRun(1)}};
$('#bt1').onclick=()=>bTab(1);$('#bt2').onclick=()=>bTab(2);
$('#bat').onclick=()=>$('#bfi').click();
$('#bfi').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;try{const[d,m]=await shrink(f);bimg={name:f.name,kind:'img',mime:m,data:d};$('#bpv').textContent='📎 '+f.name+' যুক্ত হয়েছে (ট্যাপ করে সরাও)';$('#bpv').onclick=()=>{bimg=null;$('#bpv').textContent=''}}catch(x){toast('ছবি নেওয়া যায়নি')}};
$('#bcp').onclick=()=>{if(!bcode)return;try{navigator.clipboard.writeText(bcode).then(()=>toast('কোড কপি হয়েছে ✓'))}catch(e){toast('কপি করা যায়নি')}};
$('#bdl').onclick=async()=>{if(!bcode)return;const f=new File([bcode],'mayra-'+bk+'.html',{type:'text/html'});
 try{if(navigator.canShare&&navigator.canShare({files:[f]})){await navigator.share({files:[f]});return}}catch(e){}
 const a=document.createElement('a');a.href=URL.createObjectURL(f);a.download=f.name;document.body.appendChild(a);a.click();a.remove();toast('Save হচ্ছে… না হলে 📋 Copy করে ব্যবহার করো')};
$('#bfs').onclick=()=>{if(!bcode)return;const d=document.createElement('div');d.style.cssText='position:fixed;inset:0;z-index:99999;background:#000';d.innerHTML='<button style="position:absolute;top:calc(10px + env(safe-area-inset-top,0px));right:10px;z-index:2;background:#000a;color:#fff;border:1.5px solid #fff8;border-radius:12px;padding:8px 14px;font:inherit">✕ বন্ধ</button><iframe allow="microphone;camera;fullscreen" sandbox="allow-scripts allow-forms allow-modals allow-pointer-lock" style="width:100%;height:100%;border:0;background:#fff"></iframe>';d.querySelector('iframe').srcdoc=pdoc(bcode,'tmp');d.querySelector('button').onclick=()=>d.remove();document.body.appendChild(d)};
window.tsh=o=>{dr(0);$('#bp').classList.toggle('show',!!o);if(o){bModels();bTools();bMy();if(!bcode){try{const l=JSON.parse(localStorage.getItem('mayra_lastbuild')||'null');if(l&&l.code){bk=l.k||l.bk||bk;bpub=l.pub||'';bTools();bShow(l.code,bk!='dbg'||/<html|<!doctype/i.test(l.code));BH=[{role:'user',content:'Previous project'},{role:'assistant',content:'```html\n'+l.code+'\n```'}];$('#bst').textContent='শেষবারের বানানো প্রজেক্ট'}}catch(e){}}}};

