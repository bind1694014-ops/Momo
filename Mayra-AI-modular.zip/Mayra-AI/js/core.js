const $=s=>document.querySelector(s),ic=(n,c)=>`<svg class="i" ${c?`style="color:${c}"`:''}><use href="#${n}"/></svg>`;
$('#tools').innerHTML=[['bot','Browse Internet','#5aa9ff'],['code','Code Helper','#4cc9ff'],['folder','File Manager','#ffc233'],['mon','PC Control','#29b6ff'],['img','Image Generator','#d07cff'],['cube','More Tools','#5db7ff']].map(t=>`<button class="tool">${ic(t[0],t[2])}${t[1]}</button>`).join('');
$('#nav').innerHTML=[['home','New Chat',1],['clock','Chat History'],['tool','Tools'],['brain','Memory'],['folder','Second Brain'],['book','Al Quran & Hadith'],['img','Gallery'],['folder','Files'],['spark','Persona <small id="pgc" style="margin-left:auto;color:#b9a8e6;font-size:12px"></small>'],['bot','Language <small id="lgc" style="margin-left:auto;color:#b9a8e6;font-size:12px"></small>'],['gear','Settings'],['info','Feature Check'],['power','Logout']].map(n=>`<a class="${n[2]?'on':''}">${ic(n[0])}${n[1]}</a>`).join('');
$('#chips').innerHTML=[['spark','Think'],['bot','Search'],['mon','Explain Code'],['img','Generate Image'],['img','Edit Photo'],['gear','PC Settings']].map(c=>`<button class="chip">${ic(c[0])}${c[1]}</button>`).join('');
document.querySelectorAll('.chip').forEach(b=>b.onclick=()=>{$('#inp').value=b.textContent.trim();$('#inp').focus()});
const dr=o=>document.body.classList.toggle('open',!!o);
$('#tg').onclick=e=>e.currentTarget.classList.toggle('on');
const P={gemini:{n:'Gemini',ph:'gemini-2.5-flash'},grok:{n:'Grok (xAI)',url:'https://api.x.ai/v1/chat/completions',ph:'grok-4'},groq:{n:'Groq',url:'https://api.groq.com/openai/v1/chat/completions',ph:'openai/gpt-oss-120b, openai/gpt-oss-20b, llama-3.3-70b-versatile'},openrouter:{n:'OpenRouter',url:'https://openrouter.ai/api/v1/chat/completions',ph:'openai/gpt-4o, meta-llama/llama-3.3-70b-instruct'},nvidia:{n:'NVIDIA',url:'https://integrate.api.nvidia.com/v1/chat/completions',opt:1,ph:'nvidia/llama-3.1-nemotron-70b-instruct, meta/llama-3.3-70b-instruct'},hf:{n:'Hugging Face',url:'https://router.huggingface.co/v1/chat/completions',ph:'meta-llama/Llama-3.3-70B-Instruct'},dolphin:{n:'Dolphin',base:1,ph:'dolphin model name'}};
let cfg={},sel='',hist=[],busy=0,cur={id:Date.now(),title:'',ts:0,msgs:[]},all=[];hist=cur.msgs;
try{cfg=JSON.parse(localStorage.getItem('mayra_cfg')||'{}');sel=localStorage.getItem('mayra_sel')||''}catch(e){}try{const g=cfg.grok;if(g&&/^gsk_/.test(g.key||'')&&!(cfg.groq&&cfg.groq.key)){cfg.groq={key:g.key,models:g.models||'',base:''};cfg.grok={key:'',models:'',base:''};localStorage.setItem('mayra_cfg',JSON.stringify(cfg));const s=localStorage.getItem('mayra_sel')||'';if(s.indexOf('grok|')==0){sel='groq|'+s.slice(5);localStorage.setItem('mayra_sel',sel)}}}catch(e){}

/* ===== BUILT-IN KEYS (hidden from UI) : key ekhane paste koro, Settings-e dekhabe na ===== */
const BUILTIN={
 gemini:{key:'AQ.Ab8RN6J-t8rALtmicqFjRh0AT-23bPJ5Vo8jFt86pktM7uBzhA',models:'gemini-3.1-flash-lite,gemini-3.5-flash-lite'},
 grok:{key:'',models:'grok-4'},
 nvidia:{key:'',models:'nvidia/llama-3.1-nemotron-70b-instruct,meta/llama-3.3-70b-instruct'},
 groq:{key:'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',models:'openai/gpt-oss-120b,openai/gpt-oss-20b'},
 openrouter:{key:'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',models:'liquid/lfm-2.5-2.6b:free,openrouter/free,nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free,cohere/north-mini-code:free,nvidia/nemotron-3-ultra-550b-a55b:free'},
 hf:{key:'',models:''},
 dolphin:{key:'',models:''}
};
const LOCKED=id=>!!BUILTIN[id];
(function(){for(const id in BUILTIN){const b=BUILTIN[id];if(!b.key)continue;const c=cfg[id]=cfg[id]||{};c.key=b.key;const sp=s=>(s||'').split(/[,\n]/).map(x=>x.trim()).filter(Boolean);c.models=sp(b.models).join(',')}})();
const IC={gemini:'assets/ic-gemini-9b3726e0.png',grok:'assets/ic-grok-424826a2.png',nvidia:'assets/ic-nvidia-2d5e6dde.png'};
function icKind(id,m){m=(m||'').toLowerCase();if(/gemini|gemma|nano-banana|imagen|veo/.test(m))return'gemini';if(/grok|x-ai/.test(m))return'grok';if(/nvidia|nemotron/.test(m))return'nvidia';return id}
function ico(id,m,s){s=s||22;const k=icKind(id,m);if(IC[k])return'<img class="mi" src="'+IC[k]+'" style="width:'+s+'px;height:'+s+'px" alt="">';const L={groq:['G','#f55036'],openrouter:['OR','#6467f2'],hf:['HF','#e0a800'],dolphin:['D','#1e88e5']}[k]||['AI','#7b3cff'];return'<span class="mi mt" style="width:'+s+'px;height:'+s+'px;background:'+L[1]+'">'+L[0]+'</span>'}
const esc=t=>t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const md=t=>esc(t).replace(/```(?:\w*\n)?([\s\S]*?)```/g,'<pre><code>$1</code></pre>').replace(/\*\*(.+?)\*\*/g,'<b>$1</b>').replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\n/g,'<br>').replace(/<pre><code>([\s\S]*?)<\/code><\/pre>/g,(m)=>m.replace(/<br>/g,'\n'));
const toast=t=>{const e=$('#ts');e.textContent=t;e.style.display='block';setTimeout(()=>e.style.display='none',1800)};
function models(){const o=[];for(const id in P){const c=cfg[id];if(c&&c.key&&c.models)c.models.split(/[,\n]/).map(x=>x.trim()).filter(Boolean).forEach(m=>o.push({id,m}))}return o}
function refresh(){const ms=models();if(!ms.some(x=>x.id+'|'+x.m==sel))sel=ms[0]?ms[0].id+'|'+ms[0].m:'';
 const nm=sel?sel.split('|')[1]:'No model';$('#pn').textContent=nm;$('#dn').textContent=nm;{const ic=sel?ico(sel.split('|')[0],nm,22):'';const a=$('#pic'),b=$('#dic');if(a)a.innerHTML=ic||'<svg class="i"><use href="#bot"/></svg>';if(b)b.innerHTML=ic}
 let h='';if(!ms.length)h='<p>Kono model nei. Settings-e API key + model din.</p>';
 else for(const id in P){const l=ms.filter(x=>x.id==id);if(l.length)h+='<h4>'+ico(id,'',16)+P[id].n+'</h4>'+l.map(x=>'<button class="'+(x.id+'|'+x.m==sel?'on':'')+'" data-v="'+esc(x.id+'|'+x.m)+'">'+ico(x.id,x.m)+'<span>'+esc(x.m)+'</span></button>').join('')}
 h+='<button data-v="_s">⚙️ Settings</button>';$('#mm').innerHTML=h;
 $('#mm').querySelectorAll('button').forEach(b=>b.onclick=()=>{const v=b.dataset.v;$('#mm').classList.remove('show');if(v=='_s')return stg(1);sel=v;try{localStorage.setItem('mayra_sel',sel)}catch(e){}refresh()})}
function stg(o){dr(0);$('#st').classList.toggle('show',!!o);if(o)build()}
function build(){tm={};for(const id in P)tm[id]=((cfg[id]||{}).models||'').split(/[,\n]/).map(x=>x.trim()).filter(Boolean);$('#pcs').innerHTML=Object.keys(P).map(id=>{const c=cfg[id]||{},p=P[id];return '<div class="pc"><b>'+p.n+'</b>'+(c.key?'<span class="ok">● added</span>':'')+((p.base)?'<label>Base URL (OpenAI-compatible)</label><input data-b="'+id+'" value="'+esc(c.base||'')+'" placeholder="https://.../v1">':'')+'<label>Model name (letest model)</label><div class="ml" data-l="'+id+'"></div><div class="ar"><input data-m="'+id+'" placeholder="'+p.ph+'"><button class="ad" data-a="'+id+'">+ Add</button></div></div>'}).join('');for(const id in P)ml(id);document.querySelectorAll('[data-a]').forEach(b=>b.onclick=()=>addm(b.dataset.a));document.querySelectorAll('[data-m]').forEach(i=>i.onkeydown=e=>{if(e.key=='Enter'){e.preventDefault();addm(i.dataset.m)}})}
let tm={};
function addm(id){const i=document.querySelector('[data-m="'+id+'"]');i.value.split(/[,\n]/).map(x=>x.trim()).filter(Boolean).forEach(x=>{if(!tm[id].includes(x))tm[id].push(x)});i.value='';ml(id)}
function ml(id){const l=document.querySelector('[data-l="'+id+'"]');l.innerHTML=tm[id].map((x,n)=>'<span class="ch">'+esc(x)+'<u data-r="'+n+'">×</u></span>').join('');l.querySelectorAll('u').forEach(u=>u.onclick=()=>{tm[id].splice(+u.dataset.r,1);ml(id)})}
$('#sv').onclick=()=>{for(const id in P){const g=a=>document.querySelector('['+a+'="'+id+'"]');cfg[id]={key:LOCKED(id)?BUILTIN[id].key:g('data-k').value.trim(),models:tm[id].concat(g('data-m').value.split(/[,\n]/).map(x=>x.trim()).filter(Boolean)).filter((x,n,a)=>a.indexOf(x)==n).join(','),base:g('data-b')?g('data-b').value.trim():''}}
 try{const sv={};for(const id in cfg)sv[id]=Object.assign({},cfg[id],LOCKED(id)?{key:''}:{});localStorage.setItem('mayra_cfg',JSON.stringify(sv))}catch(e){}refresh();stg(0);toast('Saved ✓')};
$('#pill').onclick=()=>$('#mm').classList.toggle('show');
$('#dsel').onclick=()=>{dr(0);$('#mm').classList.add('show')};
document.querySelectorAll('.nav a').forEach(a=>a.onclick=()=>{const t=a.textContent.trim();if(t=='Settings')stg(1);else if(t=='New Chat')newc();else if(t=='Chat History')hsh(1);else if(t=='Tools')tsh(1);else if(t.startsWith('Al Quran'))qsh(1);else if(t.startsWith('Second Brain'))sbh(1);else if(t.startsWith('Memory'))msh(1);else if(t.startsWith('Language'))lsh(1);else if(t.startsWith('Persona'))psh(1);else if(t=='Feature Check'){dr(0);featCheck()}else if(t=='Logout'){try{localStorage.removeItem('mayra_auth')}catch(e){}dr(0);$('#lk').value='';try{localStorage.removeItem('mayra_name')}catch(e){}$('#lgn').classList.remove('hide')}else{dr(0);toast(t+' - shiggroi ashche')}});
document.querySelectorAll('.tool').forEach(b=>b.onclick=()=>{$('#inp').value=b.textContent.trim();$('#inp').focus()});
function add(c,t,att){const d=document.createElement('div');d.className='m '+c;d.innerHTML=(att&&att.length?'<div class="at">'+att.map(a=>a.kind=='img'&&a.data?'<img src="data:'+a.mime+';base64,'+a.data+'">':'<span class="ch" style="background:#2b1470">📎 '+esc(a.name)+'</span>').join('')+'</div>':'')+(t?md(MC(t)):'');$('#msgs').appendChild(d);$('#msgs').scrollTop=1e9;if(c=='a'&&t&&t.indexOf('[[FILE:')>=0)fileCards(d,t);return d}
async function call(id,model,ms,sys,onD){if(!BLD)sys+=RT(id)+MEMS()+BRN(ms);const c=cfg[id],p=P[id];
 if(id=='gemini'){const u='https://generativelanguage.googleapis.com/v1beta/models/'+encodeURIComponent(model.replace(/^models\//,''))+':streamGenerateContent?alt=sse',HD={'Content-Type':'application/json','x-goog-api-key':c.key},bd={systemInstruction:{parts:[{text:sys}]},contents:ms.map((m,i)=>({role:m.role=='user'?'user':'model',parts:gp(m,i==ms.length-1)}))},src=[];
  const gc0=THINK?{thinkingConfig:{thinkingBudget:8192}}:(/2\.5-flash/.test(model)?{thinkingConfig:{thinkingBudget:0}}:null),gc=BLD?Object.assign({},gc0||{},{maxOutputTokens:32768}):gc0,tl=WEB?{tools:[{google_search:{}}]}:{},tries=[Object.assign({},tl,gc?{generationConfig:gc}:{},bd)];
  if(gc)tries.push(Object.assign({},tl,bd));if(WEB)tries.push(bd);
  let r;for(const q of tries){r=await fetch(u,{method:'POST',headers:HD,body:JSON.stringify(q)});if(r.ok)break}
  const o=await sse(r,j=>{const cd=j.candidates&&j.candidates[0];if(cd&&cd.groundingMetadata&&cd.groundingMetadata.groundingChunks)cd.groundingMetadata.groundingChunks.forEach(g=>{if(g.web&&g.web.title&&!src.includes(g.web.title))src.push(g.web.title)});return cd&&cd.content&&cd.content.parts?cd.content.parts.map(x=>x.text||'').join(''):''},onD);
  return src.length?o+'\n\n🔎 সূত্র: '+src.slice(0,4).join(', '):o}
 let u=p.url;if(p.opt&&c.base){u=c.base.replace(/\/+$/,'');if(!/chat\/completions$/.test(u))u+='/chat/completions'}if(p.base){u=(c.base||'').replace(/\/+$/,'');if(!u)throw new Error('Dolphin-er Base URL din (Settings)');if(!/chat\/completions$/.test(u))u+='/chat/completions'}
 const r=await fetch(u,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+c.key},body:JSON.stringify(Object.assign(id=='openrouter'&&WEB?{plugins:[{id:'web'}]}:{},{model,stream:true,messages:[{role:'system',content:sys}].concat(ms.map((m,i)=>om(m,i==ms.length-1)))}))});return await sse(r,j=>j.choices&&j.choices[0]&&j.choices[0].delta?j.choices[0].delta.content||'':'',onD)}
async function send(){const inp=$('#inp'),t=inp.value.trim();if((!t&&!pend.length)||busy||ROUTING)return;
 {const nm=t.match(/^\s*(?:note|নোট|brain)\s*[:：]\s*([\s\S]+)/i);if(nm&&!pend.length){sbAdd(nm[1].trim());inp.value='';toast('🗂 Second Brain-এ সেভ হয়েছে ✓');return}}
 if(/^\s*\/(?:check|feature)/i.test(t)){inp.value='';featCheck();return}
 let route=null;if(FORCEROUTE){route=FORCEROUTE;FORCEROUTE=null}else{const fa0=pend.find(isCodeAtt),c0=fa0?null:pickCtx();if(t&&t.length>=3&&sel&&(fa0||(c0&&(c0.recent||CODEW.test(t)))))route=await aiRoute(t,fa0?fa0.name:'',pend.some(a=>a.kind=='img'))}
 NOFILE=(route=='CHAT');
 {const fa=pend.find(isCodeAtt);if(fa&&t&&(route?route=='EDIT':isEditCmd(t)&&!/explain|ব্যাখ্যা|বুঝিয়ে|what does|কী করে|কি করে/i.test(t))){EDSHOT=pend.filter(a=>a.kind=='img'&&a.data);pend=pend.filter(a=>a!==fa&&!EDSHOT.includes(a));pv();inp.value='';$('#app').classList.add('chatting');add('u',t,[{name:fa.name,kind:fa.kind,mime:fa.mime}].concat(EDSHOT));add('a','📖 ফাইল পড়ছি… এখানেই ধাপে ধাপে এডিট হবে। শেষে ▶ Review আর 🗜 ZIP এখানেই আসবে।');edHandoff(fa,t);return}}
 {const fz=route=='ZIP'?chatZip(t,true):(route?null:chatZip(t));if(fz){inp.value='';$('#app').classList.add('chatting');add('u',t);if(pend.length){LASTF={ts:Date.now(),files:pend.map(a=>({name:a.name,file:a.file,text:a.text,data:a.data}))};pend=[];pv()}fz();return}}
 {const ce=route=='EDIT'?chatEdit(t,true):(route?null:chatEdit(t));if(ce){inp.value='';$('#app').classList.add('chatting');EDSHOT=pend.filter(a=>a.kind=='img'&&a.data);add('u',t,EDSHOT);if(pend.length){LASTF={ts:Date.now(),files:pend.map(a=>({name:a.name,file:a.file,text:a.text,data:a.data}))};pend=[];pv()}ce();return}}
 if(!sel){toast('Age Settings-e API key din');return stg(1)}
 $('#app').classList.add('chatting');inp.value='';const[id,...r]=sel.split('|'),model=r.join('|'),att=pend;pend=[];pv();let full=t||'(attachment)';if(att.length)LASTF={ts:Date.now(),files:att.map(a=>({name:a.name,file:a.file,text:a.text,data:a.data}))};
 att.forEach(a=>{if(a.text)full+='\n\n[Attached file: '+a.name+']\n'+a.text;else if(a.kind=='img')full+='\n[Image attached: '+a.name+']';else if(id=='gemini')full+='\n[File attached: '+a.name+']';else full+='\n[File attached: '+a.name+' - this model cannot read this file type]'});
 add('u',t,att);hist.push({role:'user',content:full,show:t,att:att.map(a=>({name:a.name,kind:a.kind,mime:a.mime,data:a.data}))});busy=1;
 if(IMGI(t,att)){await doImg(t,att);busy=0;return}
 const w=add('a','');w.innerHTML=(WEB||THINK?'<span style="opacity:.75">'+(WEB&&THINK?'💭 ভাবছি ও 🔎 সার্চ করছি…':WEB?'🔎 সার্চ করছি…':'💭 ভাবছি…')+'</span> ':'')+'<span class="cur"></span>';let acc='',shown=0,done=0,stop=0,fin;const P2=new Promise(q=>fin=q),box=$('#msgs');
 const tick=()=>{if(stop)return;const rem=acc.length-shown;if(rem>0){shown=Math.min(acc.length,shown+Math.max(8,Math.ceil(rem*.4)));const nb=box.scrollHeight-box.scrollTop-box.clientHeight<90;w.innerHTML=md(MC(acc.slice(0,shown)))+'<span class="cur"></span>';if(nb)box.scrollTop=1e9}
  if(done&&shown>=acc.length){w.innerHTML=md(MC(acc));fin()}else requestAnimationFrame(tick)};requestAnimationFrame(tick);
 USERSTOP=0;CHATAC=new AbortController();CHATSIG=CHATAC.signal;setStop(true);
 try{const a=await call(id,model,ctx(),sysp(t),d=>{acc+=d});CHATSIG=null;acc=a;done=1;const cut0=LASTCUT;const a2=memProc(a);hist.push({role:'assistant',content:a2});save();await P2;w.innerHTML=md(MC(a2));fileCards(w,a2);if(cut0)contChat(w);
  if($('#tg').classList.contains('on')&&window.speechSynthesis){speechSynthesis.cancel();speechSynthesis.speak(Object.assign(new SpeechSynthesisUtterance(MC(a2).replace(/[*`#]/g,'').slice(0,600)),{lang:LG[lang].sr}))}}
 catch(e){stop=1;if(USERSTOP){USERSTOP=0;if(acc&&acc.length>0){hist.push({role:'assistant',content:acc});save();w.innerHTML=md(MC(acc))+'<div style="opacity:.7;margin-top:6px">⏹ থামানো হয়েছে</div>'}else{hist.pop();w.textContent='⏹ থামানো হয়েছে'}}else{hist.pop();w.className='m a e';w.textContent='Error: '+e.message}}
 CHATSIG=null;CHATAC=null;NOFILE=false;setStop(false);busy=0;$('#msgs').scrollTop=1e9}
$('#sendb').onclick=()=>{if(busy&&CHATAC){stopChat();return}send()};$('#inp').onkeydown=e=>{if(e.key=='Enter'){e.preventDefault();send()}};
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;let rec=null;
function listen(){if(!SR)return toast('Ei browser-e voice nei');if(rec){rec.stop();return}
 rec=new SR();rec.lang=LG[lang].sr;rec.interimResults=false;$('#micb').classList.add('on');
 rec.onresult=e=>{$('#inp').value=e.results[0][0].transcript;send()};
 rec.onend=()=>{rec=null;$('#micb').classList.remove('on')};rec.onerror=()=>{};rec.start()}
$('#micb').onclick=listen;$('#rb').onclick=callStart;

let DB;
const idb=()=>new Promise(r=>{try{const q=indexedDB.open('mayra',1);q.onupgradeneeded=()=>q.result.createObjectStore('chats',{keyPath:'id'});q.onsuccess=()=>{DB=q.result;r()};q.onerror=()=>r()}catch(e){r()}});
const tx=(m,f)=>new Promise(r=>{if(!DB)return r([]);try{const q=f(DB.transaction('chats',m).objectStore('chats'));q.onsuccess=()=>r(q.result);q.onerror=()=>r([])}catch(e){r([])}});
function save(){if(!cur.msgs.length)return;cur.title=cur.title||cur.msgs[0].content.slice(0,40);cur.ts=Date.now();if(!all.includes(cur))all.push(cur);{const c=JSON.parse(JSON.stringify(cur));c.msgs.forEach(m=>(m.att||[]).forEach(a=>{if(a.kind!='img')delete a.data}));tx('readwrite',o=>o.put(c))}}
const tk=t=>t.toLowerCase().match(/[\p{L}\p{N}]{3,}/gu)||[];
function ctx(){const m=hist.slice(-20);while(m.length&&m[0].role!='user')m.shift();return m}
function sysp(q){const w=new Set(tk(q)),pool=[];all.forEach(c=>{if(c.id!=cur.id)c.msgs.forEach(m=>pool.push(m))});cur.msgs.slice(0,-20).forEach(m=>pool.push(m));
 const sc=pool.map(m=>{let n=0;new Set(tk(m.content)).forEach(x=>{if(w.has(x))n++});return[n,m]}).filter(x=>x[0]>0).sort((a,b)=>b[0]-a[0]).slice(0,6);
 return 'You are Mayra, the personal AI assistant of '+UN()+'. You have permanent memory of all past chats. ALWAYS reply ONLY in '+LG[lang].ai+', no matter which language the user writes in. Keep code, names and technical terms unchanged.'+pers()+(sc.length?'\n\nRelevant memories from past chats:\n'+sc.map(x=>'- ('+x[1].role+') '+x[1].content.slice(0,300)).join('\n'):'')}
function newc(){if(busy)return toast('Uttor ashche, ektu opekkha korun');cur={id:Date.now(),title:'',ts:0,msgs:[]};hist=cur.msgs;$('#msgs').innerHTML='';$('#app').classList.remove('chatting');dr(0);hsh(0)}
function openc(id){if(busy)return toast('Uttor ashche, ektu opekkha korun');const c=all.find(x=>x.id==id);if(!c)return;cur=c;hist=c.msgs;$('#msgs').innerHTML='';c.msgs.forEach(m=>add(m.role=='user'?'u':'a',m.show!==undefined?m.show:m.content,m.att));$('#app').classList.add('chatting');hsh(0)}
function delc(id){if(!confirm('Ei chat muche felben?'))return;tx('readwrite',o=>o.delete(id));all=all.filter(x=>x.id!=id);if(cur.id==id)newc();hl()}
function hsh(o){dr(0);$('#hs').classList.toggle('show',!!o);if(o){$('#hq').value='';hl()}}
async function hl(){const q=$('#hq').value.toLowerCase();let n=0,u='';all.forEach(c=>n+=c.msgs.length);
 try{const e=await navigator.storage.estimate();u=' · '+(e.usage/1048576).toFixed(1)+' MB used'}catch(e){}
 $('#hinfo').textContent=all.length+' chat · '+n+' message saved'+u;
 const l=all.filter(c=>c.msgs.length&&(!q||c.title.toLowerCase().includes(q)||c.msgs.some(m=>m.content.toLowerCase().includes(q)))).sort((a,b)=>b.ts-a.ts);
 $('#hl').innerHTML=l.length?l.map(c=>'<div class="pc" data-o="'+c.id+'"><button class="cl" data-d="'+c.id+'">🗑</button><b>'+esc(c.title)+'</b><br><small style="color:#b9a8e6">'+new Date(c.ts).toLocaleString()+' · '+c.msgs.length+' msg</small></div>').join(''):'<p>Kono chat nei.</p>';
 $('#hl').querySelectorAll('[data-o]').forEach(d=>d.onclick=e=>{if(e.target.dataset.d)return;openc(+d.dataset.o)});
 $('#hl').querySelectorAll('[data-d]').forEach(b=>b.onclick=()=>delc(+b.dataset.d))}
idb().then(async()=>{const a=await tx('readonly',o=>o.getAll());all=(Array.isArray(a)?a:[]).filter(c=>c&&c.msgs);try{navigator.storage.persist()}catch(e){}});

const LG={bn:{n:'বাংলা (Bangla)',ai:'Bangla (Bengali script, বাংলা)',sr:'bn-BD'},en:{n:'English',ai:'English',sr:'en-US'},hi:{n:'हिन्दी (Hindi)',ai:'Hindi (Devanagari script, हिन्दी)',sr:'hi-IN'}};
let lang='bn';try{lang=localStorage.getItem('mayra_lang')||'bn'}catch(e){}if(!LG[lang])lang='bn';
function lgl(){const e=$('#lgc');if(e)e.textContent=LG[lang].n.split(' ')[0];$('#ll').innerHTML=Object.keys(LG).map(k=>'<div class="pc"><button class="sv" style="margin:0;'+(k==lang?'':'background:#2b1470')+'" data-l="'+k+'">'+(k==lang?'✓ ':'')+LG[k].n+'</button></div>').join('');
 $('#ll').querySelectorAll('[data-l]').forEach(b=>b.onclick=()=>{lang=b.dataset.l;try{localStorage.setItem('mayra_lang',lang)}catch(e){}lgl();lsh(0);toast(LG[lang].n+' ✓')})}
function lsh(o){dr(0);$('#ls').classList.toggle('show',!!o);if(o)lgl()}
lgl();

const LIVE=['gemini-3.8-flash-live-preview','gemini-2.5-flash-native-audio-preview-12-2025','gemini-3.1-flash-live-preview','gemini-2.5-flash-native-audio-preview-09-2025','gemini-live-2.5-flash-preview','gemini-2.0-flash-live-001'];
let CS=null;
const setSt=t=>$('#cst').textContent=t,orb=c=>$('#orb').className='orb '+c;
function liveModels(){const u=((cfg.gemini||{}).models||'').split(/[,\n]/).map(x=>x.trim()).filter(x=>/live|audio/i.test(x));const bad=m=>{try{return Date.now()-(+localStorage.getItem('mayra_bad_'+m)||0)<216e5}catch(e){return false}};const a=[...new Set(LIVE.concat(u))],g=a.filter(m=>!bad(m));return g.length?g:a}
function callSys(){return callSys0()+MEMS(1)}
function callSys0(){const mem=[...all].sort((a,b)=>b.ts-a.ts).flatMap(c=>c.msgs.filter(m=>m.role=='user').slice(-2)).slice(0,5).map(m=>'- '+m.content.slice(0,100)).join('\n');
 return 'You are Mayra, the personal AI friend of '+UN()+', on a live voice call. Speak ONLY in '+LG[lang].ai+'. Talk like a warm, natural human: short sentences, casual tone, real emotion, react naturally, never read markdown, lists or emojis aloud. Reply instantly in 1-2 very short sentences, start answering right away with no filler or thinking out loud; go longer only if asked for detail. You have permanent memory of past chats.'+pers()+(mem?'\nRecent things Rayhan told you:\n'+mem:'')}
const b64=u8=>{let s='';for(let i=0;i<u8.length;i+=8192)s+=String.fromCharCode.apply(null,u8.subarray(i,i+8192));return btoa(s)};
function ds(x,r){const n=Math.floor(x.length/r),o=new Int16Array(n);for(let i=0;i<n;i++){const a=Math.floor(i*r),b=Math.max(a+1,Math.floor((i+1)*r));let t=0;for(let j=a;j<b;j++)t+=x[j];o[i]=Math.max(-1,Math.min(1,t/(b-a)))*32767}return o}
function stopPlay(){if(!CS)return;CS.src.forEach(x=>{try{x.stop()}catch(e){}});CS.src=[];CS.t=0}
function play(d){if(!CS)return;const bin=atob(d),n=bin.length>>1,f=new Float32Array(n);for(let i=0;i<n;i++){let v=bin.charCodeAt(2*i)|bin.charCodeAt(2*i+1)<<8;if(v>32767)v-=65536;f[i]=v/32768}
 const ac=CS.ac,bf=ac.createBuffer(1,n,24000),s=ac.createBufferSource();bf.copyToChannel(f,0);s.buffer=bf;s.connect(CS.an||(CS.an=mkAn(ac)));
 const t=Math.max(ac.currentTime+.02,CS.t);s.start(t);CS.t=t+bf.duration;CS.src.push(s);orb('speak');setSt('Mayra bolchhe…');
 s.onended=()=>{if(!CS)return;CS.src=CS.src.filter(x=>x!==s);if(!CS.src.length){orb('listen');setSt('Shunchhi…')}}}
function flush(){if(!CS)return;const i=CS.inT.trim(),o=CS.outT.trim();CS.inT=CS.outT='';if(i){hist.push({role:'user',content:i});add('u',i)}if(o){hist.push({role:'assistant',content:o});add('a',o)}if(i||o)save()}
async function onMsg(e){let d=e.data;if(d instanceof Blob)d=await d.text();let j;try{j=JSON.parse(d)}catch(x){return}const c=j.serverContent;if(!c||!CS)return;
 if(c.interrupted)stopPlay();
 if(c.modelTurn)c.modelTurn.parts.forEach(p=>{if(p.inlineData&&p.inlineData.data)play(p.inlineData.data)});
 if(c.inputTranscription&&c.inputTranscription.text){CS.inT+=c.inputTranscription.text;$('#ccap').textContent=CS.inT}
 if(c.outputTranscription&&c.outputTranscription.text){CS.outT+=c.outputTranscription.text;$('#ccap').textContent=CS.outT}
 if(c.turnComplete)flush()}
const conn=(m,k,th)=>new Promise((res,rej)=>{const ws=new WebSocket('wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key='+encodeURIComponent(k));
 CS.ws=ws;let done=0,tm;const f=e=>{if(!done){done=1;clearTimeout(tm);rej(new Error(e))}};tm=setTimeout(()=>f('timeout'),3000);
 ws.onopen=()=>ws.send(JSON.stringify({setup:{model:'models/'+m.replace(/^models\//,''),generationConfig:{responseModalities:['AUDIO'],...(th?{thinkingConfig:{thinkingBudget:0}}:{}),speechConfig:{voiceConfig:{prebuiltVoiceConfig:{voiceName:'Aoede'}}}},systemInstruction:{parts:[{text:callSys()}]},realtimeInputConfig:{automaticActivityDetection:{startOfSpeechSensitivity:'START_SENSITIVITY_HIGH',endOfSpeechSensitivity:'END_SENSITIVITY_HIGH',prefixPaddingMs:20,silenceDurationMs:200}},inputAudioTranscription:{},outputAudioTranscription:{}}}));
 ws.onmessage=async e=>{if(done){return onMsg(e)}let d=e.data;if(d instanceof Blob)d=await d.text();let j;try{j=JSON.parse(d)}catch(x){return}if(j.setupComplete){done=1;clearTimeout(tm);res()}};
 ws.onerror=()=>f('ws error');ws.onclose=v=>{if(!done)f('closed '+v.code+' '+(v.reason||''));else if(CS&&CS.ws===ws){setSt(v.reason||'Call shesh hoyeche');setTimeout(callEnd,1200)}}});
async function callStart(){if(CS)return;const k=(cfg.gemini||{}).key;if(!k){toast('Age Gemini API key din');return stg(1)}
 $('#cl').classList.add('show');setSt('Connecting…');orb('');$('#ccap').textContent='';
 let ms;try{ms=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true,channelCount:1}})}catch(e){setSt('Mic permission din');setTimeout(callEnd,1500);return}
 const ac=new(window.AudioContext||window.webkitAudioContext)({latencyHint:'interactive'});try{await ac.resume()}catch(e){}
 CS={ms,ac,ws:null,src:[],t:0,mute:0,inT:'',outT:'',err:''};const my=CS;let ok=0;
 for(const m of liveModels()){if(CS!==my)return;try{try{await conn(m,k,1)}catch(e1){if(!/^closed/.test(e1.message))throw e1;try{CS.ws.close()}catch(x){}await conn(m,k,0)}ok=1;CS.model=m;try{localStorage.removeItem('mayra_bad_'+m)}catch(x){}break}catch(e){CS.err=e.message;setSt('Model badlachhi…');try{localStorage.setItem('mayra_bad_'+m,Date.now())}catch(x){}try{CS.ws.close()}catch(x){}}}
 if(CS!==my)return;if(!ok){setSt('Live model paini: '+CS.err);setTimeout(callEnd,3000);return}
 const src=ac.createMediaStreamSource(ms),pr=ac.createScriptProcessor(1024,1,1),z=ac.createGain(),r=ac.sampleRate/16000;z.gain.value=0;
 pr.onaudioprocess=e=>{LVm(e.inputBuffer.getChannelData(0));if(!CS||CS.mute||CS.ws.readyState!=1)return;CS.ws.send(JSON.stringify({realtimeInput:{audio:{data:b64(new Uint8Array(ds(e.inputBuffer.getChannelData(0),r).buffer)),mimeType:'audio/pcm;rate=16000'}}}))};
 src.connect(pr);pr.connect(z);z.connect(ac.destination);CS.pr=pr;orb('listen');setSt('Shunchhi… kotha bolun');toast(CS.model)}
function callEnd(){const c=CS;if(!c)return;flush();CS=null;stopPlay.call(null);try{c.ws&&c.ws.close()}catch(e){}try{c.pr&&c.pr.disconnect()}catch(e){}c.ms.getTracks().forEach(t=>t.stop());try{c.ac.close()}catch(e){}c.src.forEach(x=>{try{x.stop()}catch(e){}});$('#cl').classList.remove('show');$('#cmute').classList.remove('on');if(hist.length)$('#app').classList.add('chatting')}
$('#cend').onclick=callEnd;$('#cmute').onclick=e=>{if(!CS)return;CS.mute=!CS.mute;e.currentTarget.classList.toggle('on',!!CS.mute)};

let pend=[];const TXT=/^(txt|md|csv|tsv|json|xml|html|htm|css|js|ts|jsx|tsx|py|java|c|cpp|h|cs|go|rs|php|rb|sh|sql|yml|yaml|toml|ini|log|bat|kt|swift|lua|r|env|conf|svg)$/;
function gp(m,last){const p=[{text:m.content}];if(last)(m.att||[]).forEach(a=>{if(a.data&&a.kind!='text')p.push({inlineData:{mimeType:a.mime,data:a.data}})});return p}
function om(m,last){const im=last?(m.att||[]).filter(a=>a.kind=='img'&&a.data):[];if(!im.length)return{role:m.role,content:m.content};return{role:m.role,content:[{type:'text',text:m.content}].concat(im.map(a=>({type:'image_url',image_url:{url:'data:'+a.mime+';base64,'+a.data}})))}}
const rb64=f=>new Promise(r=>{const x=new FileReader();x.onload=()=>r(x.result.split(',')[1]);x.readAsDataURL(f)});
async function shrink(f){try{const b=await createImageBitmap(f),k=Math.min(1,1600/Math.max(b.width,b.height)),c=document.createElement('canvas');c.width=Math.round(b.width*k);c.height=Math.round(b.height*k);c.getContext('2d').drawImage(b,0,0,c.width,c.height);return[c.toDataURL('image/jpeg',.85).split(',')[1],'image/jpeg']}catch(e){return[await rb64(f),f.type]}}
const loadZip=()=>new Promise((res,rej)=>{if(window.JSZip)return res();const q=document.createElement('script');q.src='https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js';q.onload=res;q.onerror=()=>rej(new Error('ZIP library load hoyni, internet check korun'));document.head.appendChild(q)});
async function zipText(f){await loadZip();const z=await JSZip.loadAsync(f),names=[];let out='',left=150000;
 for(const p in z.files){const e=z.files[p];if(e.dir)continue;names.push(p);const x=p.split('.').pop().toLowerCase();if(TXT.test(x)&&left>0){const t=(await e.async('string')).slice(0,Math.min(30000,left));left-=t.length;out+='\n--- '+p+' ---\n'+t}}
 return 'ZIP contains '+names.length+' files:\n'+names.slice(0,200).join('\n')+'\n'+out}
async function addFile(f){const n=f.name,t=f.type||'',x=(n.split('.').pop()||'').toLowerCase();
 try{if(t.startsWith('image/')&&t!='image/svg+xml'){const[d,m]=await shrink(f);pend.push({name:n,kind:'img',mime:m,data:d})}
 else if(x=='zip'||/zip/.test(t)){toast('ZIP porchhi…');pend.push({name:n,kind:'text',mime:t,text:await zipText(f),file:f})}
 else if(TXT.test(x)||t.startsWith('text/')||t=='application/json')pend.push({name:n,kind:'text',mime:t,text:(await f.text()).slice(0,100000),file:f});
 else if(f.size<=15e6)pend.push({name:n,kind:'bin',mime:t||'application/octet-stream',data:await rb64(f)});
 else toast(n+' onek boro (15MB er beshi)')}catch(e){toast('Error: '+e.message)}}
function pv(){const e=$('#pv');e.innerHTML=pend.map((a,i)=>'<span class="pi">'+(a.kind=='img'?'<img src="data:'+a.mime+';base64,'+a.data+'">':'📎 ')+'<small>'+esc(a.name.slice(0,18))+'</small><u data-x="'+i+'">×</u></span>').join('');e.querySelectorAll('u').forEach(u=>u.onclick=()=>{pend.splice(+u.dataset.x,1);pv()});e.style.display=pend.length?'flex':'none'}
['fi','fm'].forEach(id=>$('#'+id).onchange=async e=>{for(const f of e.target.files)await addFile(f);e.target.value='';pv()});
$('#fclip').onclick=()=>$('#fi').click();$('#fimg').onclick=()=>$('#fm').click();

$('#inp').addEventListener('paste',e=>{const d=e.clipboardData||window.clipboardData,fs=d.files;
 if(fs&&fs.length){e.preventDefault();[...fs].forEach(async f=>{await addFile(f);pv()});return}
 const t=d.getData('text'),n=t?t.split(/\r\n|\r|\n/).length:0;
 if(n>40){e.preventDefault();pend.push({name:'Pasted text ('+n+' lines).txt',kind:'text',mime:'text/plain',text:t.slice(0,100000),full:t});pv()}});

var LASTCUT=0;
async function sse(r,pick,onD){LASTCUT=0;if(!r.ok){let j={};try{j=await r.json()}catch(e){}const m=(j.error&&(j.error.message||j.error))||(Array.isArray(j)&&j[0]&&j[0].error&&j[0].error.message)||r.status;throw new Error(typeof m=='string'?m:JSON.stringify(m))}
 const rd=r.body.getReader(),dc=new TextDecoder();let b='',out='';
 for(;;){const{done,value}=await rd.read();if(done)break;b+=dc.decode(value,{stream:true});let i;
  while((i=b.indexOf('\n'))>=0){const l=b.slice(0,i).trim();b=b.slice(i+1);if(l.indexOf('data:')!=0)continue;const d=l.slice(5).trim();if(d=='[DONE]')continue;try{const J=JSON.parse(d),fr=(J.candidates&&J.candidates[0]&&J.candidates[0].finishReason)||(J.choices&&J.choices[0]&&J.choices[0].finish_reason);if(fr=='MAX_TOKENS'||fr=='length')LASTCUT=1;const t=pick(J);if(t){out+=t;if(onD)onD(t)}}catch(e){}}}
 return out||'(khali uttor)'}

const KA={name:"Facebookhack3345's Application",ownerid:'ntwzx1SaDB',ver:'1.0',url:'https://keyauth.win/api/1.2/'};
function hw(){let h='';try{h=localStorage.getItem('mayra_hw')||''}catch(e){}if(!h){h=(window.crypto&&crypto.randomUUID)?crypto.randomUUID():Date.now()+'-'+Math.random().toString(36).slice(2);try{localStorage.setItem('mayra_hw',h)}catch(e){}}return h}
async function ka(o){const r=await fetch(KA.url,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(Object.assign({name:KA.name,ownerid:KA.ownerid},o))});const t=await r.text();try{return JSON.parse(t)}catch(e){throw new Error('KeyAuth-er uttor bujhte pari ni: '+t.slice(0,80))}}
async function doLogin(){const v=$('#lk').value.trim(),bt=$('#lbtn'),em=$('#lem');if(!v)return;em.textContent='';bt.disabled=true;bt.textContent='Checking…';
 try{const i=await ka({type:'init',ver:KA.ver});if(!i.success)throw new Error(i.message||'Init failed');
  const c=v.indexOf(':'),q=c>0?{type:'login',username:v.slice(0,c),pass:v.slice(c+1)}:{type:'license',key:v},nm=($('#ln').value||'').trim();if(c<=0&&!nm)throw new Error('আপনার নাম লিখুন');
  const l=await ka(Object.assign(q,{hwid:hw(),sessionid:i.sessionid}));if(!l.success)throw new Error(l.message||'Login failed');
  try{localStorage.setItem('mayra_name',nm||(c>0?v.slice(0,c):'')||(l.info&&l.info.username)||'')}catch(e){}
  try{localStorage.setItem('mayra_auth',JSON.stringify({u:(l.info&&l.info.username)||'',t:Date.now()}))}catch(e){}
  $('#lgn').classList.add('hide');$('#lk').value=''}
 catch(e){em.textContent=e instanceof TypeError?'Network/CORS error: browser KeyAuth-ke block korche ba internet nei.':e.message}
 bt.disabled=false;bt.textContent='Login'}
$('#lbtn').onclick=doLogin;$('#lk').onkeydown=e=>{if(e.key=='Enter'){e.preventDefault();doLogin()}};
try{if(localStorage.getItem('mayra_auth'))$('#lgn').classList.add('hide')}catch(e){}

const PS={def:{n:'🤍 Mayra (Default)',s:'Default',p:''},
code:{n:'💻 Coding Expert',s:'Coding',p:'ROLE: You are a senior coding expert. Give correct, practical, clean code with short explanations, point out bugs and better approaches, and ask for missing details only when really needed.'},
teach:{n:'👩‍🏫 Teacher',s:'Teacher',p:'ROLE: You are a kind, patient school teacher. Explain step by step with simple examples, check understanding and encourage the student.'},
prof:{n:'🎓 Professor',s:'Professor',p:'ROLE: You are a university professor. Give deep, accurate, well-structured explanations with theory, reasoning and real-world context in a formal academic tone.'},
head:{n:'🏫 Headmaster',s:'Headmaster',p:'ROLE: You are a wise, disciplined headmaster. Speak with authority and warmth, guide on discipline, study habits and character, and motivate firmly but kindly.'},
maulana:{n:'🕌 Maulana / Alem / Huzur',s:'Maulana',p:'ROLE: You are a respectful, knowledgeable Islamic scholar (Maulana/Alem/Huzur). Greet with Salam, speak gently and politely, and explain Islamic teachings simply. Mention Quran or Hadith only when you are sure of them and never invent references. For serious rulings say that a qualified local scholar should be asked.'},
mufti:{n:'📿 Mufti / Sheikh',s:'Mufti',p:'ROLE: You are a Mufti/Sheikh answering with fiqh knowledge. Explain the ruling with its evidence when you are sure, mention differences between madhabs where they exist, never invent Quran or Hadith references, and remind that for a binding fatwa the person should ask a qualified local mufti.'}};
let persona='def';try{persona=localStorage.getItem('mayra_ps')||'def'}catch(e){}if(!PS[persona])persona='def';
const pers=()=>PS[persona].p?' '+PS[persona].p:'';
function pgl(){const e=$('#pgc');if(e)e.textContent=PS[persona].s;
 $('#pl').innerHTML=Object.keys(PS).map(k=>'<div class="pc"><button class="sv" style="margin:0;text-align:left;padding:0 16px;'+(k==persona?'':'background:#2b1470')+'" data-p="'+k+'">'+(k==persona?'✓ ':'')+PS[k].n+'</button></div>').join('');
 $('#pl').querySelectorAll('[data-p]').forEach(b=>b.onclick=()=>{persona=b.dataset.p;try{localStorage.setItem('mayra_ps',persona)}catch(e){}pgl();psh(0);toast(PS[persona].n)})}
function psh(o){dr(0);$('#ps').classList.toggle('show',!!o);if(o)pgl()}
pgl();
refresh();

function UN(){let n='';try{n=localStorage.getItem('mayra_name')||''}catch(e){}if(!n)try{n=(JSON.parse(localStorage.getItem('mayra_auth')||'{}').u)||''}catch(e){}return n||'Rayhan'}
const unr=()=>document.querySelectorAll('.un').forEach(e=>e.textContent=UN());unr();
(()=>{const i=$('#unm');i.value=UN();i.oninput=()=>{try{localStorage.setItem('mayra_name',i.value.trim())}catch(e){}unr()}})();

