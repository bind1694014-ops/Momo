/* ===== Mayra Skill Loader (auto: মেসেজ মিললে নিজেই সঠিক skill AI-কে দেয়) ===== */
(()=>{
let SK=null,LD=0,DF={},N=0,lastToast='';
const SWD=new Set('the and for with are you your this that use when how what from into can will not any all one has have its but also then than they them their there here been being was were get set make run using used'.split(' '));
const tk=s=>(String(s).toLowerCase().match(/[a-z0-9][a-z0-9_.+]*/g)||[]).filter(w=>w.length>2&&!SWD.has(w));
function init(a){a.forEach(s=>{s.ns=new Set(tk(s.n.replace(/[-_]/g,' ')));s.ds=new Set(tk(s.d));new Set([...s.ns,...s.ds]).forEach(w=>DF[w]=(DF[w]||0)+1)});
 N=a.length;SK=a;try{toast('🧩 '+N+' skill ready ✓')}catch(e){}}
function fail(){LD=0;if(!window.__skErr){window.__skErr=1;try{toast('❌ Skill data লোড হয়নি')}catch(e){}}}
function load(){if(SK||LD)return;LD=1;
 try{}catch(e){}
 fetch('data/skills.json').then(r=>r.json()).then(init).catch(fail)}
setTimeout(load,2500);
function lastUser(){try{for(let i=hist.length-1;i>=0;i--)if(hist[i].role=='user')return String(hist[i].show!==undefined?hist[i].show:hist[i].content).slice(0,800)}catch(e){}return''}
function find(q){if(!SK)return[];const l=q.toLowerCase(),u=new Set(tk(q));if(!u.size)return[];
 const idf=w=>Math.log((N+1)/((DF[w]||0)+1));
 const r=SK.map(s=>{let sc=0,nh=0;
  if(l.includes(s.n.toLowerCase()))sc+=30;
  s.q.forEach(p=>{if(l.includes(p))sc+=14});
  u.forEach(w=>{if(s.ns.has(w)){sc+=idf(w)*2.2;nh++}else if(s.ds.has(w))sc+=idf(w)*.6});
  return{s,sc,nh}}).filter(x=>x.sc>=11&&(x.nh>=1||x.sc>=14)).sort((a,b)=>b.sc-a.sc);
 return r.length?r.filter((x,i)=>i<2&&x.sc>=r[0].sc*.7):[]}
let STK={f:[],left:0},lastKey=-1;
let bt=0,bk='';
function badge(f){let b=document.getElementById('skb');
 if(!f.length){if(b)b.style.display='none';bk='';return}
 const k=f.map(x=>x.s.n).join(',');if(k===bk)return;bk=k;
 if(!b){b=document.createElement('div');b.id='skb';b.style.cssText='position:fixed;left:50%;transform:translateX(-50%);bottom:150px;z-index:60;max-width:80%;padding:4px 11px;border-radius:99px;background:rgba(124,58,237,.75);color:#fff;font-size:11.5px;pointer-events:none;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;transition:opacity .4s';document.body.appendChild(b)}
 b.textContent='🧩 '+f.map(x=>x.s.n).join(', ');b.style.display='block';b.style.opacity='1';
 clearTimeout(bt);bt=setTimeout(()=>{b.style.opacity='0';setTimeout(()=>{if(b.style.opacity=='0')b.style.display='none'},450)},2500)}
const prev=window.MEMS;
window.MEMS=function(v){let r=prev(v);if(v)return r;
 try{load();const key=hist.length;let f=find(lastUser());
  if(f.length){STK={f,left:4};lastKey=key}
  else if(STK.left>0){if(key!==lastKey){STK.left--;lastKey=key}f=STK.f}
  if(!STK.left&&!f.length)STK.f=[];
  badge(f);
  if(f.length){
  r+='\n\n[SKILLS — auto-selected expert guides active for this conversation. Follow them as reference knowledge. If the user asks which skill you are following, answer with the exact skill names below. You are running inside a phone app and cannot execute commands, so explain steps, give the commands/code for the user to run elsewhere, and never claim to have run anything.]\n'+f.map(x=>'### SKILL: '+x.s.n+'\n'+x.s.b).join('\n\n')}}catch(e){}
 return r};
window.__skTest={find:q=>(load(),find(q)),ready:()=>!!SK};
})();
