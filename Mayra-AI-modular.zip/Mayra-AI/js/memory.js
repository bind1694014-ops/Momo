/* ---------- Memory ---------- */
const MK='mayra_mem';
function memGet(){try{const a=JSON.parse(localStorage.getItem(MK)||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
function memSet(a){try{localStorage.setItem(MK,JSON.stringify(a.slice(-80)))}catch(e){}}
function MEMS(v){const m=memGet();
 let r='\n\n[MEMORY — permanent facts about the user. Always remember them and use them naturally; never say you looked them up]\n'+(m.length?m.map(x=>'- '+x.t).join('\n'):'(empty)');
 if(!v)r+='\n\nMEMORY RULES: If the user shares lasting personal info (their name, family members\' names, birthday, location, job, preferences, important dates) or asks you to remember/save something, reply normally and add at the very END, on new lines, one tag per fact: [[MEM: short complete fact about the user]]. If they ask you to forget something add [[FORGET: keyword]]. Do not tag casual or temporary info. Never mention, explain or show these tags in your normal text.\n\nFILE RULES: You CAN deliver files and ZIPs - the app turns them into download cards. Never say you cannot create or send a file or zip. When the user asks for a file, app, website, script or any code longer than about 40 lines, do NOT paste it in the chat. Write one or two short Bangla sentences about what you made, and put each file in its own block exactly like: [[FILE: index.html]] then a new line, the COMPLETE file content, a new line, then [[ENDFILE]]. Use a proper filename for every file and never leave a file partial. For short snippets (under about 40 lines) use a normal code block instead. When asked to edit code or files the user gave earlier, never print the whole edited code in chat.';
 return r}
const MCm=x=>x.replace(/\[\[\s*(MEM|FORGET)\s*:[\s\S]*?\]\]/g,'').replace(/\[(?:\[(?:M(?:E(?:M[^\]]*)?)?|F(?:O(?:R(?:G(?:E(?:T[^\]]*)?)?)?)?)?)?)?$/,'').replace(/\n{3,}/g,'\n\n').trim();
const MC=x=>MCm(x.replace(/\[\[FILE:\s*([^\]\n]+?)\s*\]\][\s\S]*?\[\[ENDFILE\]\]/g,'').replace(/\[\[FILE:\s*([^\]\n]+?)\s*\]\][\s\S]*$/,'\n⏳ ফাইল লিখছি…').replace(/\[\[FILE:?[^\]\n]*$/,''));
function memProc(a){let m=memGet(),ch=0,add_=[];
 a.replace(/\[\[\s*MEM\s*:\s*([\s\S]*?)\]\]/g,(_,t)=>{t=t.trim().slice(0,200);if(t&&!m.some(x=>x.t.toLowerCase()==t.toLowerCase())){m.push({t,ts:Date.now()});add_.push(t);ch=1}return ''});
 a.replace(/\[\[\s*FORGET\s*:\s*([\s\S]*?)\]\]/g,(_,k)=>{k=k.trim().toLowerCase();if(k){const n=m.length;m=m.filter(x=>!x.t.toLowerCase().includes(k));if(m.length!=n)ch=1}return ''});
 if(ch){memSet(m);try{mdraw()}catch(e){}toast(add_.length?'🧠 মনে রাখলাম ✓':'🧠 Memory আপডেট ✓')}
 return MCm(a)}
function mdraw(){const m=memGet(),L=$('#ml');if(!L)return;
 L.innerHTML=m.length?m.map((x,i)=>`<div class="q-y" style="display:flex;gap:10px;align-items:center;padding:10px 12px"><div style="flex:1;font-size:14px;line-height:1.6">${esc(x.t)}</div><button class="q-t" data-d="${i}">🗑</button></div>`).join('')+'<button class="q-b" id="mclr" style="margin-top:6px">সব মুছুন</button>':'<div class="q-ld">এখনো কিছু সেভ নেই।<br>চ্যাটে বলো: “আমার মায়ের নাম … মনে রাখো”</div>';
 L.querySelectorAll('[data-d]').forEach(b=>b.onclick=()=>{const a=memGet();a.splice(+b.dataset.d,1);memSet(a);mdraw()});
 const c=$('#mclr');if(c)c.onclick=()=>{if(confirm('সব Memory মুছে ফেলবে?')){memSet([]);mdraw()}}}
$('#ma').onclick=()=>{const i=$('#mi'),t=i.value.trim().slice(0,200);if(!t)return;const m=memGet();m.push({t,ts:Date.now()});memSet(m);i.value='';mdraw()};
$('#mi').onkeydown=e=>{if(e.key=='Enter'){e.preventDefault();$('#ma').click()}};
window.msh=o=>{dr(0);$('#ms').classList.toggle('show',!!o);if(o)mdraw()};

