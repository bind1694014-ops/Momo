/* ---------- chat -> step-by-step editor routing ---------- */
const CODEW=/code|কোড|file|ফাইল|html|index|css|\bjs\b|app|অ্যাপ|সাইট|site|website|button|বাটন|menu|মেনু|theme|থিম|function|feature|ফিচার|page|পেজ|option|অপশন|screen|\bui\b/i;
const CODEF=f=>/\.(html?|css|js|jsx|json|zip|txt)$/i.test(f.name||'')&&(((f.code||f.text||'').length>1500)||(f.file&&f.file.size>1500));
function pickCtx(){const cand=[];if(bcode)cand.push({ts:bts,ep:true});if(LASTF&&LASTF.files.some(CODEF))cand.push({ts:LASTF.ts,items:LASTF.files});
 cand.sort((a,b)=>b.ts-a.ts);if(cand.length){const c=cand[0];c.recent=Date.now()-c.ts<20*60*1000;return c}
 const h=histFiles();return h.length&&h.some(CODEF)?{items:h,recent:false}:null}
async function edFromItems(items){const files={};let zn;
 for(const it of items){let nm=safeName(it.name||'file.txt');
  if(/\.zip$/i.test(nm)&&it.file){const z=await unzipAll(await it.file.arrayBuffer());Object.keys(z).filter(k=>!/(^|\/)(__MACOSX|\.)/.test(k)).forEach(k=>{files[k]=TXTX.test(k)?{text:new TextDecoder().decode(z[k])}:{bytes:z[k]}});zn=nm;continue}
  let tx=it.code!=null?it.code:(it.file&&TXTX.test(nm)?await it.file.text():it.text);
  if(tx!=null&&(TXTX.test(nm)||/<html|<!doctype/i.test(tx))){if(/^Pasted text/.test(nm)&&/<html|<!doctype/i.test(tx))nm='index.html';files[nm]={text:tx}}
  else if(it.data){const b=atob(it.data),u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);files[nm]={bytes:u}}}
 edLoadFiles(files,zn)}
var EDSHOT=null,FORCEROUTE=null;
var NOISE=/Script error|ResizeObserver|NetworkError|Failed to fetch|Load failed|net::|fetch|CORS|quota|API key|permission|denied|NotAllowed|AbortError|getUserMedia|AudioContext|autoplay|serviceWorker/i;
var SHRINKOK=/remove|delete|মুছ|ছোট|কমা|shrink|minif|clean|muche|muchh|komao|chhoto|choto|সরাও|sorao|soraw|reduce/i;
function codeMap(c){const L=c.split('\n'),fn=[],ids=new Set();
 const t=(c.match(/<title[^>]*>([^<]{0,60})/i)||[])[1]||'';
 L.forEach((l,i)=>{const m=l.match(/(?:async\s+)?function\s+[A-Za-z_$][\w$]*/g);
  if(m)m.forEach(x=>{if(fn.length<150)fn.push(x.replace(/^(?:async\s+)?function\s+/,'')+'@'+(i+1))});
  else{const m2=l.match(/^\s*(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:function\b|\([^)]*\)\s*=>|[A-Za-z_$][\w$]*\s*=>)/);if(m2&&fn.length<150)fn.push(m2[1]+'@'+(i+1))}
  (l.match(/\bid\s*=\s*["']([\w-]+)["']/g)||[]).forEach(x=>{if(ids.size<120)ids.add(x.replace(/^[^"']*["']|["']$/g,''))})});
 const css=(c.match(/<style[\s\S]*?<\/style>/gi)||[]).reduce((a,x)=>a+x.length,0),js=(c.match(/<script(?![^>]*src)[\s\S]*?<\/script>/gi)||[]).reduce((a,x)=>a+x.length,0);
 return{nf:fn.length,ni:ids.size,text:'CODE MAP (auto-generated outline, line numbers approximate after earlier steps)\nTitle: '+t+'\nLines: '+L.length+', CSS chars: '+css+', JS chars: '+js+'\nFunctions (name@line): '+fn.join(', ')+'\nElement ids: '+[...ids].join(', ')}}
function runCheck(code){return new Promise(res=>{const errs=[],f=document.createElement('iframe');f.style.cssText='position:fixed;left:-9999px;top:0;width:390px;height:700px;border:0;visibility:hidden';f.setAttribute('sandbox','allow-scripts allow-forms allow-modals');
 const h=e=>{if(e.source===f.contentWindow&&e.data&&e.data.mayraErr&&errs.length<6)errs.push(String(e.data.mayraErr).slice(0,200))};
 addEventListener('message',h);
 setTimeout(()=>{removeEventListener('message',h);try{f.remove()}catch(x){}res(errs)},3000);
 try{f.srcdoc=pdoc(code,'chk');document.body.appendChild(f)}catch(x){res(errs)}})}
function planConfirm(plan,stopP){return new Promise(res=>{const w=document.createElement('div');w.style.cssText='margin:8px 0;padding:10px;border:1.5px solid rgba(150,110,255,.5);border-radius:14px;background:rgba(20,10,55,.92);color:#fff';
 w.innerHTML='<div style="font-weight:600;margin-bottom:6px">🧭 পরিকল্পনা — যে ধাপ চাও না তা আনটিক করো</div>'+plan.map((p,i)=>'<label style="display:flex;gap:8px;align-items:flex-start;margin:6px 0;font-size:14px"><input type="checkbox" checked data-i="'+i+'" style="margin-top:3px"><span>'+esc(p)+'</span></label>').join('')+'<button style="margin-top:8px;width:100%;padding:10px;border-radius:12px;border:0;background:#8a4dff;color:#fff;font:inherit;font-weight:600">▶ শুরু করো (<b>12</b>)</button>';
 let n=12,done=0,tm=0;const btn=w.querySelector('button'),fin=()=>{if(done)return;done=1;clearInterval(tm);const k=[...w.querySelectorAll('input')].filter(x=>x.checked).map(x=>plan[+x.dataset.i]);w.querySelectorAll('input,button').forEach(x=>x.disabled=true);btn.textContent=k.length?'✅ শুরু হয়েছে':'⏹ বাতিল';res(k)};
 tm=setInterval(()=>{n--;if(n<=0)fin();else btn.querySelector('b').textContent=n},1000);
 btn.onclick=fin;w.addEventListener('change',()=>{n=12;btn.querySelector('b').textContent=n});
 stopP.then(()=>{if(!done){done=1;clearInterval(tm);w.querySelectorAll('input,button').forEach(x=>x.disabled=true);res([])}});
 const host=add('a','');host.appendChild(w);try{$('#msgs').scrollTop=1e9}catch(e){}})}
var EDCH=[['✨ আরও সুন্দর','aro sundor ar animation kore dao'],['📱 মোবাইল ফ্রেন্ডলি','mobile e perfect fit hoy emon responsive kore dao'],['🌙 Dark mode','dark mode add kore dao'],['🐞 Bug fix','sob bug fix kore dao'],['⚡ দ্রুত করো','app ta aro fast kore dao']];
function editChips(inChat){const w=document.createElement('div');w.style.cssText='display:flex;flex-wrap:wrap;gap:8px;margin:8px 0';
 EDCH.forEach(c=>{const b=document.createElement('button');b.textContent=c[0];b.style.cssText='padding:8px 12px;border-radius:999px;border:1.5px solid rgba(150,110,255,.6);background:rgba(40,20,100,.7);color:#fff;font:inherit;font-size:13.5px';
  b.onclick=()=>{if(inChat){FORCEROUTE='EDIT';$('#inp').value=c[1];send()}else{if(!bcode)return toast('আগে 📎 দিয়ে কোড/ZIP নাও');$('#bpr').value=c[1];bRun(0)}};w.appendChild(b)});if(inChat){const u=document.createElement('button');u.textContent='↩ Undo';u.style.cssText='padding:8px 12px;border-radius:999px;border:1.5px solid rgba(255,150,150,.6);background:rgba(60,20,40,.7);color:#fff;font:inherit;font-size:13.5px';u.onclick=undoChat;w.appendChild(u)}return w}
function pickAlt(id,model){const ms=models();return ms.find(x=>x.id!=id&&x.id!='dolphin')||ms.find(x=>x.id==id&&x.m!=model)||null}
function cheapModel(){const ms=models(),a=sel.split('|'),sid=a[0],sm=a.slice(1).join('|');
 const c=ms.find(x=>x.id==sid&&/(^|[-\/ _])(lite|mini|small|haiku|8b)([-\/ _:.]|$)/i.test(x.m))||ms.find(x=>/flash-lite|lite/i.test(x.m))||ms.find(x=>x.id==sid&&/flash/i.test(x.m)&&!/pro/i.test(x.m));
 return c?{id:c.id,m:c.m}:{id:sid,m:sm}}
var AUTOSW=false;
const _call0=call;
call=async function(id,model,ms,sys,onD){let got=0;const od=onD?function(d){got=1;return onD(d)}:onD;
 try{return await _call0(id,model,ms,sys,od)}
 catch(e){const msg=String(e&&e.message||e);if(got||USERSTOP||/STOP|abort/i.test(msg)||!/429|quota|rate|limit|exhaust|overload|unavailable|\b5\d\d\b|fetch|network|failed|timeout|busy|capacity/i.test(msg))throw e;
  if(!AUTOSW)throw e;const alt=pickAlt(id,model);if(!alt)throw e;
  try{toast('⚠️ '+P[id].n+' ব্যর্থ — '+P[alt.id].n+'-এ চেষ্টা করছি');return await _call0(alt.id,alt.m,ms,sys,od)}catch(e2){throw e}}};
var APPVER='v10 · 9 Nov 2026',CHATAC=null,CHATSIG=null,USERSTOP=0,SENDHTML=null;
(function(){const f=window.fetch;if(!f||f.__m)return;const w=function(u,o){try{if(CHATSIG&&!(o&&o.signal)&&/generativelanguage|openrouter\.ai|api\.x\.ai|huggingface|chat\/completions|workers\.dev|groq|mistral|cohere|nvidia|sambanova|z\.ai|llm7/i.test(String(u)))o=Object.assign({},o||{},{signal:CHATSIG})}catch(e){}return f.call(window,u,o)};w.__m=1;window.fetch=w})();
function setStop(on){const b=$('#sendb');if(!b)return;if(SENDHTML===null)SENDHTML=b.innerHTML;b.innerHTML=on?'<span style="font-size:20px;line-height:1">⏹</span>':SENDHTML;b.title=on?'Stop':''}
function stopChat(){if(!CHATAC)return false;USERSTOP=1;try{CHATAC.abort()}catch(e){}return true}
async function featCheck(){$('#app').classList.add('chatting');const w=add('a','🔍 ফিচার চেক চলছে… ('+APPVER+')');const rows=['📦 ভার্সন: '+APPVER+' (এটা দেখা গেলে নতুন ফাইলই চলছে)'];
 const ok=(n,b,note)=>rows.push((b?'✅ ':'⚠️ ')+n+(note?' — '+note:'')),src=f=>{try{return f.toString()}catch(e){return ''}};
 try{ok('১. ছোট ফাইল আটকানো',SHRINKOK.test('remove')&&!SHRINKOK.test('sundor kore dao')&&src(edRun).includes('SHRINKOK'),'ফাইল ৭০%-এর কম হলে বদল বাতিল')}catch(e){ok('১. ছোট ফাইল আটকানো',false)}
 try{let r=[];try{r=await runCheck('<!doctype html><html><head></head><body><script>throw new Error("selftest")<\/script></body></html>')}catch(e){}
  ok('২. অটো এরর-চেক',r.some(x=>/selftest/.test(x))&&src(edRun).includes('runCheck'),r.some(x=>/selftest/.test(x))?'আসল টেস্টে এরর ধরেছে':'এই ব্রাউজারে ধরা যায়নি')}catch(e){ok('২. অটো এরর-চেক',false)}
 try{ok('৩. প্ল্যান দেখে বাদ দেওয়া',typeof planConfirm=='function'&&src(edRun).includes('planConfirm'),'চ্যাটে এডিটের সময় আসে')}catch(e){ok('৩. প্ল্যান',false)}
 try{const m=codeMap('<title>x</title><div id="a"></div><script>function foo(){}\nconst bar=()=>1<\/script>');ok('৫. কোড ম্যাপ',m.nf==2&&m.ni==1&&src(edRun).includes('cm.text'),'ফাংশন ও id সূচি বানায়')}catch(e){ok('৫. কোড ম্যাপ',false)}
 try{const hasV=src(edRun).includes('EDSHOT')&&src(send).includes('EDSHOT');ok('৬. স্ক্রিনশট বোঝা',hasV,'ছবি বোঝে এমন মডেল (Gemini) লাগবে')}catch(e){ok('৬. স্ক্রিনশট',false)}
 try{ok('৭. কুইক চিপ',editChips(true).children.length>=5,'এডিট শেষে ও Code Editor-এ আসে')}catch(e){ok('৭. কুইক চিপ',false)}
 try{const alt=pickAlt(...sel.split('|').slice(0,1).concat(sel.split('|').slice(1).join('|')));ok('৮. মডেল ব্যর্থ হলে ব্যাকআপ',src(call).includes('pickAlt'),alt?('ব্যাকআপ: '+P[alt.id].n+' · '+alt.m):'ব্যাকআপ মডেল নেই — Settings-এ আরেকটা মডেল/কী দিলে চালু হবে');const cm=cheapModel();ok('   রাউটার মডেল (সস্তা)',true,cm.id+' · '+cm.m)}catch(e){ok('৮. ব্যাকআপ মডেল',false)}
 try{ok('৯. Stop বাটন',typeof AbortController=='function'&&src(window.fetch).includes('CHATSIG')&&src(edRun).includes('STOP')&&typeof stopChat=='function','চ্যাটের উত্তরের সময় সেন্ড বাটন ⏹ হয়, এডিটের সময় লাল ⏹ Stop আসে')}catch(e){ok('৯. Stop',false)}
 try{ok('এডিট/প্রশ্ন বোঝা (AI রাউটার)',typeof aiRoute=='function'&&isEditCmd('sundor kore dao')&&!isEditCmd('ki edite korla'),'কোড ফাইল থাকলে AI নিজে বুঝে ঠিক করে')}catch(e){ok('রাউটার',false)}
 try{ok('▶ Review বাটন',typeof revCard=='function'&&src(edRun).includes('revCard'),'এডিট শেষে সরাসরি অ্যাপে চলে')}catch(e){ok('Review',false)}
 try{ok('১০. সবকিছু চ্যাটেই (Review/ZIP/Undo/এডিট-লগ)',typeof undoChat=='function'&&typeof edLogAdd=='function'&&!src(edHandoff).includes('tsh(1)'),'Code Editor প্যানেল আর খোলে না; আসল এডিট-লগ থেকে উত্তর দেয়')}catch(e){ok('১০. চ্যাটেই সব',false)}
 w.innerHTML=rows.map(esc).join('<br>');$('#msgs').scrollTop=1e9}
var EDLOG=[],NOFILE=false;try{EDLOG=JSON.parse(localStorage.getItem('mayra_edlog')||'[]')}catch(e){}
function edLogAdd(req,steps,d,b0,b1){EDLOG.push({t:Date.now(),r:String(req).replace(/\s*SCREENSHOT NOTES[\s\S]*$/,'').slice(0,150),s:steps.map(x=>({s:String(x.s).slice(0,120),m:String(x.m||'').slice(0,140),ok:x.ok?1:0})),a:d.add,d:d.rem,b:b0,f:b1});if(EDLOG.length>10)EDLOG.shift();try{localStorage.setItem('mayra_edlog',JSON.stringify(EDLOG))}catch(e){}}
function edLogCtx(){if(!EDLOG.length)return '\n\nREAL EDIT LOG: the app editor has made no edits yet.';return '\n\nREAL EDIT LOG (the only true record of what the app editor changed, newest last; never invent changes):\n'+EDLOG.slice(-5).map(e=>'- '+new Date(e.t).toLocaleString()+' | request: '+e.r+' | +'+e.a+'/-'+e.d+' lines, '+Math.round(e.b/1024)+'KB->'+Math.round(e.f/1024)+'KB | steps: '+e.s.map(x=>(x.ok?'DONE ':'FAILED ')+x.s+(x.m?' ('+x.m+')':'')).join('; ')).join('\n')}
const _sysp=sysp;
sysp=function(q){let r=_sysp(q);r+='\n\nAPP RULES: You are the chat brain of the Mayra app. The app has its own edit engine: when the user attaches a code file or ZIP (or refers to the project just edited) and gives a command, the app edits it step by step by itself. Never claim that you added or changed anything unless it appears in the REAL EDIT LOG below. Never output a replacement or "updated" full file for an existing project the user gave you or the app edited (unless the user clearly asks for a brand-new file from scratch). Never tell the user they misunderstood. If the user wants a change to their project, say in one short line to just tell what to change. Answer questions about what was changed ONLY from the REAL EDIT LOG.'+edLogCtx();if(NOFILE)r+='\n\nFor this message: answer in words only. Do not output any [[FILE:]] block or any code block longer than 15 lines.';return r};
function undoChat(){if(!EV.length)return toast('ফেরার মতো আগের ভার্সন নেই');try{$('#bun').onclick()}catch(e){return toast('Undo হয়নি')}const m=add('a','↩ আগের ভার্সনে ফিরেছি।');if(/<html|<!doctype/i.test(bcode))m.appendChild(revCard());m.appendChild(mkCards())}
var ROUTING=false;
const RT_SYS='You are an intent router inside a coding chat app. The user has code or a project file available. Decide what the user\'s LATEST message wants. Reply with exactly ONE word. EDIT = the user asks you to change, improve, add, fix, remove or redesign the code/file. ZIP = the user only wants the file or project packaged or downloaded. CHAT = anything else: a question, asking what was changed or why, comparing file size or line counts, asking for an explanation, discussion, complaint, or a statement about what the user did. Messages are often Bangla written in English letters (Banglish) or Bangla script, with typos. Past tense or a question, like "ki edite korla", is CHAT. "sundor kore dao" is EDIT. If unsure, answer CHAT.';
async function aiRoute(t,fname,hasImg){
 if(!sel||ROUTING)return null;ROUTING=true;const b0=BLD,w0=WEB,t0=THINK;
 try{const cm=cheapModel(),id=cm.id,model=cm.m;
  const h=(hist||[]).slice(-2).map(m=>(m.role=='user'?'USER: ':'ASSISTANT: ')+String(m.show||m.content||'').slice(0,300)).join('\n');
  BLD=true;WEB=false;THINK=false;
  const out=await Promise.race([call(id,model,[{role:'user',content:'FILE: '+(fname||'code')+'\n\nRECENT CHAT:\n'+h+'\n\nLATEST USER MESSAGE:\n'+t+(hasImg?'\n(The user also attached a screenshot of the app.)':'')+'\n\nAnswer EDIT, ZIP or CHAT.'}],RT_SYS,()=>{}),new Promise(rs=>setTimeout(()=>rs(null),9000))]);
  const m=String(out||'').match(/\b(EDIT|ZIP|CHAT)\b/i);return m?m[1].toUpperCase():null}
 catch(e){return null}
 finally{BLD=b0;WEB=w0;THINK=t0;ROUTING=false}}
function chatEdit(t,force){if(!force&&(t.length<4||!isEditCmd(t)||/explain|ব্যাখ্যা|বুঝিয়ে|what does|কী করে|কি করে/i.test(t)))return null;
 const c=pickCtx();if(!c||!(force||CODEW.test(t)||c.recent))return null;
 return async()=>{try{bModels();if(!c.ep)await edFromItems(c.items);EDCHAT=true;edRun(t)}catch(e){EDCHAT=false;add('a','❌ '+e.message)}}}

let WEB=false,THINK=false;try{WEB=localStorage.getItem('mayra_web2')=='1';THINK=localStorage.getItem('mayra_think')!='0'}catch(e){}
function RT(id){let d='';try{d=new Date().toLocaleString('bn-BD',{timeZone:'Asia/Dhaka',dateStyle:'full',timeStyle:'short'})}catch(e){d=new Date().toString()}
 let r='\n\n[REAL-TIME] এখন ঢাকার সময়: '+d+'.';if(WEB&&(id=='gemini'||id=='openrouter'))r+=' খবর, আবহাওয়া, নামাজের সময়, খেলার স্কোর, দাম/ডলার রেট, ঘটনা—বাংলাদেশ ও বিশ্বের যেকোনো সাম্প্রতিক তথ্যের জন্য ওয়েব সার্চ ব্যবহার করে সর্বশেষ সঠিক তথ্য দাও। উত্তর সরাসরি ও সংক্ষিপ্ত রাখো।';r+=THINK?' উত্তর দেওয়ার আগে ধাপে ধাপে যুক্তি করে ভেবে নিয়ে গভীর ও সঠিক উত্তর দাও।':' দ্রুত, সরাসরি ও সংক্ষিপ্ত উত্তর দাও।';return r}
const GEN=/^\s*(generate image|image generate|create image|draw)\b|ছবি\s*(আঁক|বানা|তৈরি)|(generate|create|make|draw)\s+(an?\s+)?(image|picture|photo)\b/i;
const EDT=/^\s*edit\b|এডিট|\b(remove|erase|replace|enhance|retouch|colorize|brighten|blur|crop)\b|মুছে|বদলে|ব্যাকগ্রাউন্ড/i;
const lastImg=()=>{for(let i=hist.length-1;i>=0;i--){const a=(hist[i].att||[]).filter(x=>x.kind=='img'&&x.data);if(a.length)return a[a.length-1]}return null};
const IMGI=(t,att)=>GEN.test(t)||/^\s*edit\b/i.test(t)||(att.some(a=>a.kind=='img')&&EDT.test(t));
async function doImg(t,att){const k=(cfg.gemini||{}).key;
 if(!k){hist.pop();const e=add('a','ছবির জন্য Gemini API key লাগবে (Settings)।');e.className='m a e';return}
 const w=add('a','🎨 ছবি তৈরি হচ্ছে…');
 try{let im=att.filter(a=>a.kind=='img'&&a.data);if(!im.length){const l=lastImg();if(l&&!GEN.test(t))im=[l]}
  const pr=t.replace(/^\s*(edit|generate image)\s*[:\-]?\s*/i,'')||'Improve this image';
  const parts=[{text:pr}].concat(im.map(a=>({inlineData:{mimeType:a.mime,data:a.data}})));
  const mods=((cfg.gemini.models||'').split(/[,\n]/).map(x=>x.trim()).filter(x=>/image/i.test(x))).concat(['gemini-2.5-flash-image']);let err='',out=null;
  for(const m of mods){try{const r=await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+encodeURIComponent(m)+':generateContent',{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':k},body:JSON.stringify({contents:[{role:'user',parts}],generationConfig:{responseModalities:['TEXT','IMAGE']}})});const j=await r.json();if(!r.ok){err=(j.error&&j.error.message)||r.status;continue}
   const ps=(j.candidates&&j.candidates[0]&&j.candidates[0].content&&j.candidates[0].content.parts)||[],g=ps.find(x=>x.inlineData||x.inline_data);
   if(g){const d=g.inlineData||g.inline_data;out={mime:d.mimeType||d.mime_type||'image/png',data:d.data,text:ps.filter(x=>x.text).map(x=>x.text).join(' ')};break}err=ps.filter(x=>x.text).map(x=>x.text).join(' ')||'ছবি পাওয়া যায়নি'}catch(e){err=e.message}}
  if(!out)throw new Error(err||'ছবি তৈরি হয়নি');
  const a={name:'mayra.png',kind:'img',mime:out.mime,data:out.data},src='data:'+out.mime+';base64,'+out.data;
  w.innerHTML='<div class="at"><img src="'+src+'"></div>'+(out.text?esc(out.text):'')+'<br><a class="q-b" download="mayra.png" href="'+src+'" style="display:inline-block;margin-top:6px;text-decoration:none">⬇ Save</a>';
  hist.push({role:'assistant',content:out.text||'[ছবি তৈরি হয়েছে]',att:[a]});save()}
 catch(e){hist.pop();w.className='m a e';w.textContent='Error: '+e.message}}
(()=>{const cs=document.querySelectorAll('.chip');
 const mk=(c,k,f,g,on,off)=>{c.classList.add('tgl');const u=()=>c.classList.toggle('on',g());u();c.onclick=()=>{f(!g());try{localStorage.setItem(k,g()?'1':'0')}catch(e){}u();toast(g()?on:off)}};
 mk(cs[0],'mayra_think',v=>THINK=v,()=>THINK,'💭 Think চালু — ভেবে গভীর উত্তর দেবে (একটু দেরি হবে)','Think বন্ধ — দ্রুত উত্তর');
 mk(cs[1],'mayra_web2',v=>WEB=v,()=>WEB,'🔎 Search চালু — লাইভ তথ্য খুঁজবে (একটু দেরি হবে)','Search বন্ধ — দ্রুত উত্তর');
 cs[4].onclick=()=>{$('#inp').value='Edit: ';$('#fm').click()};
 addEventListener('offline',()=>toast('ইন্টারনেট নেই'));addEventListener('online',()=>toast('ইন্টারনেট ফিরেছে ✓'))})();
(()=>{
const A='https://api.alquran.cloud/v1/',H='https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/';
const R=$('#qs'),B=$('#qb'),PL=$('#qpl'),TB=$('#qtabs');
const E=s=>esc(String(s==null?'':s));
const memo={};
async function jg(u){if(memo[u])return memo[u];const r=await fetch(u);if(!r.ok)throw new Error(r.status);return memo[u]=await r.json()}
const ld=m=>'<div class="q-ld">'+(m||'লোড হচ্ছে…')+'</div>';
const er=()=>'<div class="q-ld">লোড করা যায়নি। ইন্টারনেট দেখুন।<br><button class="q-b" id="qre">আবার চেষ্টা</button></div>';
const bk=()=>'<button class="q-b" id="qbk">‹ ফিরে যান</button>';
const top=()=>{try{R.scrollTo(0,0)}catch(e){}};
const bd=n=>String(n).replace(/\d/g,d=>'٠١٢٣٤٥٦٧٨٩'[d]);
const au=new Audio();au.preload='none';
let Q={list:[],idx:-1,n:0,name:''},shown=0;
/* ---------- voice (TTS) ---------- */
function say0(){try{speechSynthesis.cancel()}catch(e){}document.querySelectorAll('#qs .q-t.on').forEach(b=>b.classList.remove('on'))}
function say(text,lang,btn){const ss=window.speechSynthesis;if(!ss||!window.SpeechSynthesisUtterance)return toast('এই ডিভাইসে ভয়েস সাপোর্ট নেই');
 if(btn.classList.contains('on')){say0();return}
 say0();if(Q.idx>=0)au.pause();
 const vs=ss.getVoices(),L=lang.toLowerCase(),nv=v=>v.lang.toLowerCase().replace('_','-');
 const v=vs.find(x=>nv(x)==L)||vs.find(x=>nv(x).startsWith(L.slice(0,2)));
 if(vs.length&&!v)toast('ডিভাইসে এই ভাষার ভয়েস ইনস্টল নেই (সেটিংস › ভাষা/টেক্সট-টু-স্পিচ)');
 const t=text.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim(),parts=[];let c='';
 (t.match(/[^.!?؟۔।]+[.!?؟۔।]?/g)||[t]).forEach(s=>{if((c+s).length>180&&c){parts.push(c);c=s}else c+=s});if(c)parts.push(c);
 btn.classList.add('on');
 parts.forEach((p,i)=>{const u=new SpeechSynthesisUtterance(p);u.lang=lang;u.rate=.9;if(v)u.voice=v;if(i==parts.length-1)u.onend=u.onerror=()=>btn.classList.remove('on');ss.speak(u)})}
/* ---------- quran audio ---------- */
function stopA(){au.pause();au.removeAttribute('src');try{au.load()}catch(e){}Q.idx=-1;PL.style.display='none';document.querySelectorAll('#qs .q-y.on').forEach(e=>e.classList.remove('on'));document.querySelectorAll('#qs .q-p.on').forEach(e=>{e.classList.remove('on');e.textContent=e.dataset.l})}
function ui(){document.querySelectorAll('#qs .q-p').forEach(b=>{const on=+b.dataset.i==Q.idx&&!au.paused;b.classList.toggle('on',on);b.textContent=on?'⏸ থামান':b.dataset.l});
 document.querySelectorAll('#qs .q-y[id^=qy]').forEach(e=>e.classList.toggle('on',e.id=='qy'+Q.idx));
 const p=$('#qpp');if(p)p.textContent=au.paused?'▶':'⏸'}
function playAyah(i){if(i<0||i>=Q.list.length)return stopA();while(shown<=i&&shown<Q.list.length)more();
 say0();Q.idx=i;au.src=Q.list[i].au;au.play().catch(()=>toast('অডিও চালানো যায়নি (ইন্টারনেট দেখুন)'));
 PL.style.display='flex';$('#qpt').textContent=Q.name+' · আয়াত '+Q.list[i].n;ui();
 const e=$('#qy'+i);if(e)e.scrollIntoView({block:'center',behavior:'smooth'})}
au.onended=()=>playAyah(Q.idx+1);au.onplay=au.onpause=ui;au.onerror=()=>{if(au.getAttribute('src'))toast('অডিও লোড হয়নি')};
function tap(i){if(Q.idx==i){au.paused?au.play():au.pause()}else playAyah(i)}
$('#qpv').onclick=()=>playAyah(Q.idx-1);$('#qpn').onclick=()=>playAyah(Q.idx+1);
$('#qpp').onclick=()=>{au.paused?au.play():au.pause()};$('#qpx').onclick=stopA;
/* ---------- quran views ---------- */
async function vSurahs(){stopA();say0();top();B.innerHTML=ld();
 try{const L=(await jg(A+'surah')).data;
  B.innerHTML='<input class="q-s" id="qsr" placeholder="সূরা খুঁজুন (নাম বা নম্বর)"><div id="qsl"></div>';
  const draw=f=>{f=f.toLowerCase().trim();$('#qsl').innerHTML=L.filter(s=>!f||(s.englishName+' '+s.englishNameTranslation+' '+s.number+' '+s.name).toLowerCase().includes(f)).map(s=>`<div class="q-i" data-n="${s.number}"><span class="q-n">${s.number}</span><div class="q-m"><b>${E(s.englishName)}</b><small>${E(s.englishNameTranslation)} · ${s.numberOfAyahs} আয়াত · ${s.revelationType=='Meccan'?'মাক্কী':'মাদানী'}</small></div><span class="q-a">${E(s.name.replace('سُورَةُ ',''))}</span></div>`).join('');
   $('#qsl').querySelectorAll('.q-i').forEach(e=>e.onclick=()=>vSurah(+e.dataset.n))};
  draw('');$('#qsr').oninput=e=>draw(e.target.value)}catch(e){B.innerHTML=er();$('#qre').onclick=vSurahs}}
function more(){const c=$('#qal');if(!c)return;const e=Math.min(shown+30,Q.list.length);let h='';
 for(let i=shown;i<e;i++){const a=Q.list[i],l='▶ আয়াত '+a.n+' শুনুন';h+=`<div class="q-y" id="qy${i}"><div class="q-ar">${E(a.ar)} <span class="q-no">﴿${bd(a.n)}﴾</span></div><div class="q-bn">${E(a.bn)}</div><div class="q-au"><button class="q-p" data-i="${i}" data-l="${l}">${l}</button></div></div>`}
 c.insertAdjacentHTML('beforeend',h);shown=e;const m=$('#qmo');if(m)m.style.display=shown<Q.list.length?'block':'none';ui()}
async function vSurah(n){stopA();say0();top();B.innerHTML=ld();
 try{const d=(await jg(A+'surah/'+n+'/editions/quran-uthmani,bn.bengali,ar.alafasy')).data,f=id=>d.find(x=>x.edition.identifier==id),ar=f('quran-uthmani'),bn=f('bn.bengali'),ad=f('ar.alafasy');
  Q={list:ar.ayahs.map((a,i)=>{let t=a.text;if(n!=1&&n!=9&&i==0&&t.startsWith('بِسْمِ'))t=t.split(' ').slice(4).join(' ');return{n:a.numberInSurah,ar:t,bn:bn&&bn.ayahs[i]?bn.ayahs[i].text:'',au:ad&&ad.ayahs[i]?ad.ayahs[i].audio:''}}),idx:-1,n,name:ar.englishName};shown=0;
  B.innerHTML=bk()+`<div class="q-h"><b>${n}. ${E(ar.englishName)}</b><span class="q-a">${E(ar.name.replace('سُورَةُ ',''))}</span></div><p class="q-cap">${E(ar.englishNameTranslation)} · ${ar.numberOfAyahs} আয়াত · অনুবাদ: মুহিউদ্দীন খান · তিলাওয়াত: মিশারি আলাফাসি</p><button class="q-b p" id="qall">▶ সম্পূর্ণ সূরা শুনুন</button>${n!=1&&n!=9?'<div class="q-bsm">بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ</div>':''}<div id="qal"></div><button class="q-b" id="qmo" style="width:100%">আরও আয়াত দেখুন</button><div style="display:flex;gap:8px;margin-top:6px">${n>1?'<button class="q-b" id="qpr">‹ আগের সূরা</button>':''}${n<114?'<button class="q-b" id="qnx">পরের সূরা ›</button>':''}</div>`;
  $('#qbk').onclick=vSurahs;$('#qall').onclick=()=>playAyah(0);$('#qmo').onclick=more;
  $('#qal').onclick=e=>{const b=e.target.closest('.q-p');if(b)tap(+b.dataset.i)};
  if($('#qpr'))$('#qpr').onclick=()=>vSurah(n-1);if($('#qnx'))$('#qnx').onclick=()=>vSurah(n+1);more()}catch(e){B.innerHTML=er();$('#qre').onclick=()=>vSurah(n)}}
/* ---------- hadith ---------- */
const HC=[['bukhari','সহীহ বুখারী','صحيح البخاري',97],['muslim','সহীহ মুসলিম','صحيح مسلم',56],['tirmidhi','জামে আত-তিরমিযী','جامع الترمذي',49],['abudawud','সুনানে আবু দাউদ','سنن أبي داود',43],['nasai','সুনানে নাসাঈ','سنن النسائي',51],['ibnmajah','সুনানে ইবনে মাজাহ','سنن ابن ماجه',37]];
function vHC(){stopA();say0();top();
 B.innerHTML='<p class="q-cap">কিতাব বেছে নিন → অধ্যায় বেছে নিন। প্রতিটি হাদিস আরবি + বাংলা, সাথে 🔊 অডিও।</p>'+HC.map((c,i)=>`<div class="q-i" data-c="${i}"><span class="q-n">${i+1}</span><div class="q-m"><b>${c[1]}</b><small>${c[3]}টি অধ্যায়</small></div><span class="q-a">${c[2]}</span></div>`).join('');
 B.querySelectorAll('.q-i').forEach(e=>e.onclick=()=>vBooks(+e.dataset.c))}
function vBooks(ci){say0();top();const c=HC[ci];let h=bk()+`<div class="q-h" style="margin-bottom:10px"><b>${c[1]}</b><span class="q-a">${c[2]}</span></div><p class="q-cap">অধ্যায় নম্বর বেছে নিন</p><div class="q-g">`;
 for(let i=1;i<=c[3];i++)h+=`<button data-n="${i}">${i}</button>`;B.innerHTML=h+'</div>';$('#qbk').onclick=vHC;
 B.querySelectorAll('.q-g button').forEach(b=>b.onclick=()=>vBook(ci,+b.dataset.n))}
let HI=[];
function hmore(){const c=$('#qhl');if(!c)return;const s=c.children.length,e=Math.min(s+25,HI.length);let h='';
 for(let i=s;i<e;i++){const x=HI[i];h+=`<div class="q-y"><div class="q-h"><b>হাদিস নং ${E(x.no)}</b>${x.g?`<span class="q-gr">${E(x.g)}</span>`:''}</div>${x.ar?`<div class="q-ar h">${E(x.ar)}</div>`:''}${x.bn?`<div class="q-bn">${E(x.bn).replace(/\n/g,'<br>')}</div>`:''}<div class="q-au">${x.ar?`<button class="q-t" data-k="a${i}">🔊 আরবি</button>`:''}${x.bn?`<button class="q-t" data-k="b${i}">🔊 বাংলা</button>`:''}</div></div>`}
 c.insertAdjacentHTML('beforeend',h);const m=$('#qhm');if(m){m.style.display=e<HI.length?'block':'none';m.textContent='আরও হাদিস দেখুন ('+(HI.length-e)+'টি বাকি)'}}
async function vBook(ci,n){say0();top();B.innerHTML=ld();const c=HC[ci];
 const rs=await Promise.allSettled([jg(H+'ara-'+c[0]+'/sections/'+n+'.json'),jg(H+'ben-'+c[0]+'/sections/'+n+'.json')]);
 const a=rs[0].value,b=rs[1].value;
 if(!a&&!b){B.innerHTML=bk()+er();$('#qbk').onclick=()=>vBooks(ci);$('#qre').onclick=()=>vBook(ci,n);return}
 const bm={};if(b)b.hadiths.forEach(h=>bm[h.hadithnumber]=h);
 HI=(a||b).hadiths.map(h=>({no:h.hadithnumber,ar:a?h.text:'',bn:a?(bm[h.hadithnumber]?bm[h.hadithnumber].text:''):h.text,g:h.grades&&h.grades[0]?h.grades[0].grade:''})).filter(x=>x.ar||x.bn);
 const tl=m=>m&&m.metadata&&m.metadata.section?m.metadata.section[n]||'':'';
 B.innerHTML=bk()+`<div class="q-h" style="margin-bottom:4px"><b>${c[1]} · অধ্যায় ${n}</b></div><p class="q-cap">${E(tl(b)||tl(a))}${tl(b)&&tl(a)?' · '+E(tl(a)):''} · ${HI.length}টি হাদিস</p><div id="qhl"></div><button class="q-b" id="qhm" style="width:100%"></button><div style="display:flex;gap:8px;margin-top:6px">${n>1?'<button class="q-b" id="qpr">‹ আগের অধ্যায়</button>':''}${n<c[3]?'<button class="q-b" id="qnx">পরের অধ্যায় ›</button>':''}</div>`;
 $('#qbk').onclick=()=>vBooks(ci);$('#qhm').onclick=hmore;
 $('#qhl').onclick=e=>{const t=e.target.closest('.q-t');if(!t)return;const k=t.dataset.k,x=HI[+k.slice(1)];k[0]=='a'?say(x.ar,'ar-SA',t):say(x.bn,'bn-BD',t)};
 if($('#qpr'))$('#qpr').onclick=()=>vBook(ci,n-1);if($('#qnx'))$('#qnx').onclick=()=>vBook(ci,n+1);hmore()}
/* ---------- dua ---------- */
const D=[
["ঘুম ও জাগরণ",[
["ঘুমানোর দুআ","بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا","হে আল্লাহ! আপনার নামেই আমি মরি (ঘুমাই) এবং বাঁচি (জাগি)।","সহীহ বুখারী ৬৩২৪"],
["ঘুম থেকে উঠার দুআ","الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ","সকল প্রশংসা আল্লাহর, যিনি আমাদের মৃত্যুর (ঘুমের) পর জীবিত করলেন; আর তাঁর কাছেই ফিরে যেতে হবে।","সহীহ বুখারী ৬৩১২"],
["ঘুমের আগে আযাব থেকে আশ্রয়","اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ","হে আল্লাহ! যেদিন আপনি আপনার বান্দাদের পুনরুত্থিত করবেন, সেদিনের আযাব থেকে আমাকে রক্ষা করুন।","আবু দাউদ ৫০৪৫"]]],
["সকাল-সন্ধ্যা ও যিকির",[
["সাইয়িদুল ইস্তিগফার","اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ خَلَقْتَنِي وَأَنَا عَبْدُكَ وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ","হে আল্লাহ! আপনি আমার রব, আপনি ছাড়া কোনো ইলাহ নেই। আপনি আমাকে সৃষ্টি করেছেন, আমি আপনার বান্দা। যথাসাধ্য আপনার অঙ্গীকার ও প্রতিশ্রুতির ওপর আছি। আমি যা করেছি তার অনিষ্ট থেকে আপনার আশ্রয় চাই। আমার ওপর আপনার নিয়ামত স্বীকার করছি এবং আমার গুনাহও স্বীকার করছি। অতএব আমাকে ক্ষমা করুন, কারণ আপনি ছাড়া গুনাহ ক্ষমা করার কেউ নেই।","সহীহ বুখারী ৬৩০৬"],
["সব ক্ষতি থেকে রক্ষা (৩ বার)","بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ","আল্লাহর নামে, যাঁর নামের সাথে আসমান ও জমিনের কোনো কিছুই ক্ষতি করতে পারে না; তিনি সর্বশ্রোতা, সর্বজ্ঞ।","আবু দাউদ ৫০৮৮, তিরমিযী ৩৩৮৮"],
["সুবহানাল্লাহি ওয়া বিহামদিহি","سُبْحَانَ اللَّهِ وَبِحَمْدِهِ سُبْحَانَ اللَّهِ الْعَظِيمِ","আল্লাহ পবিত্র, তাঁর প্রশংসাসহ; মহান আল্লাহ পবিত্র। (এ দুটি বাক্য দয়াময়ের কাছে প্রিয় ও মিযানে ভারী।)","সহীহ বুখারী ৬৪০৬"],
["সৃষ্টির অনিষ্ট থেকে আশ্রয়","أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ","আমি আল্লাহর পরিপূর্ণ বাণীসমূহের মাধ্যমে তাঁর সৃষ্ট সবকিছুর অনিষ্ট থেকে আশ্রয় চাই।","সহীহ মুসলিম ২৭০৮"]]],
["নামায",[
["দুআ মাসুরা","اللَّهُمَّ إِنِّي ظَلَمْتُ نَفْسِي ظُلْمًا كَثِيرًا وَلَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ فَاغْفِرْ لِي مَغْفِرَةً مِنْ عِنْدِكَ وَارْحَمْنِي إِنَّكَ أَنْتَ الْغَفُورُ الرَّحِيمُ","হে আল্লাহ! আমি নিজের ওপর অনেক যুলুম করেছি, আপনি ছাড়া গুনাহ ক্ষমা করার কেউ নেই। তাই আপনার পক্ষ থেকে আমাকে ক্ষমা করুন ও আমার প্রতি দয়া করুন; নিশ্চয় আপনি ক্ষমাশীল, পরম দয়ালু।","বুখারী ৮৩৪, মুসলিম ২৭০৫"],
["দরূদে ইবরাহীম","اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ كَمَا صَلَّيْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ اللَّهُمَّ بَارِكْ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ كَمَا بَارَكْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ","হে আল্লাহ! মুহাম্মাদ ﷺ ও তাঁর পরিবারের ওপর রহমত বর্ষণ করুন, যেভাবে ইবরাহীম (আ.) ও তাঁর পরিবারের ওপর করেছেন; নিশ্চয় আপনি প্রশংসিত, মহিমান্বিত। হে আল্লাহ! মুহাম্মাদ ﷺ ও তাঁর পরিবারের ওপর বরকত দিন, যেভাবে ইবরাহীম (আ.) ও তাঁর পরিবারকে দিয়েছেন; নিশ্চয় আপনি প্রশংসিত, মহিমান্বিত।","সহীহ বুখারী ৩৩৭০"]]],
["খাবার",[
["খাওয়ার আগে","بِسْمِ اللَّهِ","আল্লাহর নামে (শুরু করছি)। শুরুতে ভুলে গেলে মনে পড়লে বলুন: بِسْمِ اللَّهِ أَوَّلَهُ وَآخِرَهُ","আবু দাউদ ৩৭৬৭"],
["খাওয়ার পরে","الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنِي هَذَا وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ","সকল প্রশংসা আল্লাহর, যিনি আমাকে এটি খাওয়ালেন ও রিযিক দিলেন, আমার কোনো শক্তি-সামর্থ্য ছাড়াই।","আবু দাউদ ৪০২৩, তিরমিযী ৩৪৫৮"],
["মেজবানের জন্য দুআ","اللَّهُمَّ بَارِكْ لَهُمْ فِيمَا رَزَقْتَهُمْ وَاغْفِرْ لَهُمْ وَارْحَمْهُمْ","হে আল্লাহ! আপনি তাদের যে রিযিক দিয়েছেন তাতে বরকত দিন, তাদের ক্ষমা করুন ও দয়া করুন।","সহীহ মুসলিম ২০৪২"]]],
["পবিত্রতা",[
["টয়লেটে ঢোকার দুআ","اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبُثِ وَالْخَبَائِثِ","হে আল্লাহ! আমি আপনার কাছে নর ও নারী শয়তান থেকে আশ্রয় চাই। (আগে বিসমিল্লাহ বলুন)","বুখারী ১৪২, মুসলিম ৩৭৫"],
["টয়লেট থেকে বের হওয়ার দুআ","غُفْرَانَكَ","আমি আপনার ক্ষমা প্রার্থনা করছি।","আবু দাউদ ৩০, তিরমিযী ৭"],
["ওযুর পরের দুআ","أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ","আমি সাক্ষ্য দিচ্ছি আল্লাহ ছাড়া কোনো ইলাহ নেই, তিনি একক, তাঁর কোনো শরীক নেই; আর সাক্ষ্য দিচ্ছি মুহাম্মাদ ﷺ তাঁর বান্দা ও রাসূল।","সহীহ মুসলিম ২৩৪"],
["ওযুর পর (তওবাকারী হওয়ার)","اللَّهُمَّ اجْعَلْنِي مِنَ التَّوَّابِينَ وَاجْعَلْنِي مِنَ الْمُتَطَهِّرِينَ","হে আল্লাহ! আমাকে তওবাকারী ও পবিত্রতা অর্জনকারীদের অন্তর্ভুক্ত করুন।","তিরমিযী ৫৫"]]],
["ঘর, মসজিদ ও সফর",[
["ঘর থেকে বের হওয়ার দুআ","بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ","আল্লাহর নামে, আল্লাহর ওপর ভরসা করলাম; আল্লাহর সাহায্য ছাড়া কোনো উপায় ও শক্তি নেই।","আবু দাউদ ৫০৯৫, তিরমিযী ৩৪২৬"],
["ঘরে প্রবেশের দুআ","بِسْمِ اللَّهِ وَلَجْنَا وَبِسْمِ اللَّهِ خَرَجْنَا وَعَلَى رَبِّنَا تَوَكَّلْنَا","আল্লাহর নামে প্রবেশ করলাম, আল্লাহর নামে বের হলাম এবং আমাদের রবের ওপর ভরসা করলাম। (এরপর পরিবারকে সালাম দিন)","আবু দাউদ ৫০৯৬"],
["মসজিদে প্রবেশের দুআ","اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ","হে আল্লাহ! আমার জন্য আপনার রহমতের দরজাগুলো খুলে দিন।","সহীহ মুসলিম ৭১৩"],
["মসজিদ থেকে বের হওয়ার দুআ","اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ","হে আল্লাহ! আমি আপনার অনুগ্রহ প্রার্থনা করছি।","সহীহ মুসলিম ৭১৩"],
["বাহনে ওঠার দুআ","سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ","পবিত্র তিনি, যিনি এটিকে আমাদের অনুগত করে দিয়েছেন, অথচ আমরা এটিকে বশে আনতে সক্ষম ছিলাম না; আর আমরা অবশ্যই আমাদের রবের কাছে ফিরে যাব।","সূরা যুখরুফ ৪৩:১৩-১৪, মুসলিম ১৩৪২"]]],
["বিপদ ও দুশ্চিন্তা",[
["দুশ্চিন্তা ও ঋণ থেকে আশ্রয়","اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ وَالْعَجْزِ وَالْكَسَلِ وَالْبُخْلِ وَالْجُبْنِ وَضَلَعِ الدَّيْنِ وَغَلَبَةِ الرِّجَالِ","হে আল্লাহ! আমি দুশ্চিন্তা, দুঃখ, অক্ষমতা, অলসতা, কৃপণতা, ভীরুতা, ঋণের বোঝা ও মানুষের দমন-পীড়ন থেকে আপনার আশ্রয় চাই।","সহীহ বুখারী ৬৩৬৯"],
["ইউনুস (আ.)-এর দুআ","لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ","আপনি ছাড়া কোনো ইলাহ নেই, আপনি পবিত্র; নিশ্চয় আমি যালিমদের অন্তর্ভুক্ত ছিলাম।","সূরা আম্বিয়া ২১:৮৭, তিরমিযী ৩৫০৫"],
["হাসবুনাল্লাহ","حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ","আল্লাহই আমাদের জন্য যথেষ্ট এবং তিনিই উত্তম কর্মবিধায়ক।","সূরা আলে ইমরান ৩:১৭৩, বুখারী ৪৫৬৩"],
["নিজের ওপর ছেড়ে না দেওয়ার দুআ","اللَّهُمَّ رَحْمَتَكَ أَرْجُو فَلَا تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ وَأَصْلِحْ لِي شَأْنِي كُلَّهُ لَا إِلَهَ إِلَّا أَنْتَ","হে আল্লাহ! আমি আপনার রহমতের আশা করি; তাই এক পলকের জন্যও আমাকে আমার নিজের ওপর ছেড়ে দেবেন না। আমার সব কাজ ঠিক করে দিন। আপনি ছাড়া কোনো ইলাহ নেই।","আবু দাউদ ৫০৯০"],
["বিপদে সাহায্য প্রার্থনা","يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ","হে চিরঞ্জীব, হে সবকিছুর ধারক! আপনার রহমতের উসিলায় আমি সাহায্য চাই।","তিরমিযী ৩৫২৪"],
["হালাল রিযিক ও অমুখাপেক্ষিতা","اللَّهُمَّ اكْفِنِي بِحَلَالِكَ عَنْ حَرَامِكَ وَأَغْنِنِي بِفَضْلِكَ عَمَّنْ سِوَاكَ","হে আল্লাহ! আপনার হালাল দিয়ে আমাকে হারাম থেকে যথেষ্ট করুন এবং আপনার অনুগ্রহে আপনি ছাড়া অন্য সবার থেকে অমুখাপেক্ষী করুন।","তিরমিযী ৩৫৬৩"]]],
["ক্ষমা ও তওবা",[
["আদম (আ.)-এর দুআ","رَبَّنَا ظَلَمْنَا أَنْفُسَنَا وَإِنْ لَمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ","হে আমাদের রব! আমরা নিজেদের ওপর যুলুম করেছি। আপনি যদি ক্ষমা না করেন ও দয়া না করেন, তবে অবশ্যই আমরা ক্ষতিগ্রস্তদের অন্তর্ভুক্ত হব।","সূরা আ'রাফ ৭:২৩"],
["তওবার দুআ","رَبِّ اغْفِرْ لِي وَتُبْ عَلَيَّ إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيمُ","হে আমার রব! আমাকে ক্ষমা করুন ও আমার তওবা কবুল করুন; নিশ্চয় আপনি তওবা কবুলকারী, পরম দয়ালু।","আবু দাউদ ১৫১৬, তিরমিযী ৩৪৩৪"],
["ক্ষমা চাওয়ার দুআ (লাইলাতুল কদরে)","اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي","হে আল্লাহ! আপনি ক্ষমাশীল, ক্ষমা করতে ভালোবাসেন; তাই আমাকে ক্ষমা করুন।","তিরমিযী ৩৫১৩"]]],
["কুরআনের দুআ",[
["দুনিয়া ও আখিরাতের কল্যাণ","رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ","হে আমাদের রব! আমাদের দুনিয়াতে কল্যাণ দিন, আখিরাতেও কল্যাণ দিন এবং জাহান্নামের আযাব থেকে রক্ষা করুন।","সূরা বাকারা ২:২০১"],
["ইলম বৃদ্ধির দুআ","رَبِّ زِدْنِي عِلْمًا","হে আমার রব! আমার জ্ঞান বৃদ্ধি করে দিন।","সূরা ত্বহা ২০:১১৪"],
["মনের প্রশস্ততা ও কাজের সহজতা","رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي","হে আমার রব! আমার বক্ষ প্রশস্ত করে দিন এবং আমার কাজ সহজ করে দিন।","সূরা ত্বহা ২০:২৫-২৬"],
["ভুল-ত্রুটি ক্ষমার দুআ","رَبَّنَا لَا تُؤَاخِذْنَا إِنْ نَسِينَا أَوْ أَخْطَأْنَا","হে আমাদের রব! আমরা যদি ভুলে যাই বা ভুল করি, তবে আমাদের পাকড়াও করবেন না।","সূরা বাকারা ২:২৮৬"],
["হিদায়াতের ওপর অটল থাকার দুআ","رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِنْ لَدُنْكَ رَحْمَةً إِنَّكَ أَنْتَ الْوَهَّابُ","হে আমাদের রব! হিদায়াত দেওয়ার পর আমাদের অন্তরকে বক্র করবেন না এবং আপনার পক্ষ থেকে আমাদের রহমত দান করুন; নিশ্চয় আপনিই মহাদাতা।","সূরা আলে ইমরান ৩:৮"],
["নামায কায়েম ও দুআ কবুল","رَبِّ اجْعَلْنِي مُقِيمَ الصَّلَاةِ وَمِنْ ذُرِّيَّتِي رَبَّنَا وَتَقَبَّلْ دُعَاءِ","হে আমার রব! আমাকে নামায কায়েমকারী বানান এবং আমার বংশধরদেরও; হে আমাদের রব! আমার দুআ কবুল করুন।","সূরা ইবরাহীম ১৪:৪০"]]],
["পরিবার",[
["মাতা-পিতার জন্য দুআ","رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا","হে আমার রব! তাঁদের উভয়ের প্রতি দয়া করুন, যেমন তাঁরা শৈশবে আমাকে লালন-পালন করেছেন।","সূরা ইসরা ১৭:২৪"],
["নিজের, মাতা-পিতা ও মুমিনদের ক্ষমা","رَبَّنَا اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ يَوْمَ يَقُومُ الْحِسَابُ","হে আমাদের রব! হিসাবের দিন আমাকে, আমার পিতা-মাতাকে এবং সকল মুমিনকে ক্ষমা করুন।","সূরা ইবরাহীম ১৪:৪১"],
["স্ত্রী-সন্তানের জন্য দুআ","رَبَّنَا هَبْ لَنَا مِنْ أَزْوَاجِنَا وَذُرِّيَّاتِنَا قُرَّةَ أَعْيُنٍ وَاجْعَلْنَا لِلْمُتَّقِينَ إِمَامًا","হে আমাদের রব! আমাদের স্ত্রী ও সন্তানদের থেকে আমাদের চোখের শীতলতা দান করুন এবং আমাদের মুত্তাকীদের নেতা বানান।","সূরা ফুরকান ২৫:৭৪"],
["নবদম্পতিকে দুআ","بَارَكَ اللَّهُ لَكَ وَبَارَكَ عَلَيْكَ وَجَمَعَ بَيْنَكُمَا فِي خَيْرٍ","আল্লাহ আপনাকে বরকত দিন, আপনার ওপর বরকত বর্ষণ করুন এবং কল্যাণের মধ্যে আপনাদের দু'জনকে একত্র রাখুন।","আবু দাউদ ২১৩০, তিরমিযী ১০৯১"]]],
["রোগ ও শিফা",[
["রোগীর আরোগ্যের দুআ","أَذْهِبِ الْبَأْسَ رَبَّ النَّاسِ وَاشْفِ أَنْتَ الشَّافِي لَا شِفَاءَ إِلَّا شِفَاؤُكَ شِفَاءً لَا يُغَادِرُ سَقَمًا","হে মানুষের রব! কষ্ট দূর করুন, আরোগ্য দিন; আপনিই আরোগ্যদানকারী, আপনার আরোগ্য ছাড়া কোনো আরোগ্য নেই; এমন আরোগ্য দিন যা কোনো রোগ বাকি রাখে না।","বুখারী ৫৬৭৫, মুসলিম ২১৯১"],
["ব্যথার স্থানে হাত রেখে","أَعُوذُ بِاللَّهِ وَقُدْرَتِهِ مِنْ شَرِّ مَا أَجِدُ وَأُحَاذِرُ","ব্যথার জায়গায় হাত রেখে ৩ বার বিসমিল্লাহ বলে ৭ বার বলুন: আমি আল্লাহর ও তাঁর শক্তির আশ্রয় চাই, আমি যে কষ্ট অনুভব করছি ও যার আশঙ্কা করছি তার অনিষ্ট থেকে।","সহীহ মুসলিম ২২০২"]]],
["অন্যান্য",[
["বৃষ্টির দুআ","اللَّهُمَّ صَيِّبًا نَافِعًا","হে আল্লাহ! উপকারী বৃষ্টি দিন।","সহীহ বুখারী ১০৩২"],
["ঝড়ো হাওয়ার দুআ","اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَهَا وَخَيْرَ مَا فِيهَا وَخَيْرَ مَا أُرْسِلَتْ بِهِ وَأَعُوذُ بِكَ مِنْ شَرِّهَا وَشَرِّ مَا فِيهَا وَشَرِّ مَا أُرْسِلَتْ بِهِ","হে আল্লাহ! আমি এর কল্যাণ, এর ভেতরের কল্যাণ ও যে কল্যাণ নিয়ে এটি প্রেরিত হয়েছে তা চাই; আর এর অনিষ্ট, এর ভেতরের অনিষ্ট ও যে অনিষ্ট নিয়ে এটি প্রেরিত হয়েছে তা থেকে আপনার আশ্রয় চাই।","সহীহ মুসলিম ৮৯৯"],
["হাঁচি দিলে","الْحَمْدُ لِلَّهِ ← يَرْحَمُكَ اللَّهُ ← يَهْدِيكُمُ اللَّهُ وَيُصْلِحُ بَالَكُمْ","হাঁচিদাতা বলবেন 'আলহামদুলিল্লাহ'; শ্রোতা বলবেন 'ইয়ারহামুকাল্লাহ'; তখন হাঁচিদাতা বলবেন 'ইয়াহদীকুমুল্লাহু ওয়া ইউসলিহু বালাকুম' (আল্লাহ আপনাদের হিদায়াত দিন ও অবস্থা সংশোধন করুন)।","সহীহ বুখারী ৬২২৪"]]]
];
function vDua(){stopA();say0();top();let cat=-1,L=[];
 B.innerHTML='<input class="q-s" id="qdq" placeholder="দুআ খুঁজুন…"><div class="q-cat" id="qdc"></div><div id="qdl"></div>';
 const cats=['সব'].concat(D.map(x=>x[0])),flat=[];D.forEach((c,ci)=>c[1].forEach(d=>flat.push({ci,d})));
 const draw=()=>{const f=$('#qdq').value.trim().toLowerCase();
  L=flat.filter(x=>(cat<0||x.ci==cat)&&(!f||(x.d[0]+x.d[2]+x.d[3]).toLowerCase().includes(f)));
  $('#qdc').innerHTML=cats.map((c,i)=>`<button class="${i-1==cat?'on':''}" data-c="${i-1}">${c}</button>`).join('');
  $('#qdl').innerHTML=L.length?L.map((x,i)=>`<div class="q-y"><b style="font-size:14px">${E(x.d[0])}</b><div class="q-ar h">${E(x.d[1])}</div><div class="q-bn">${E(x.d[2])}</div><div class="q-ref">📚 ${E(x.d[3])}</div><div class="q-au"><button class="q-t" data-k="${i}">🔊 শুনুন</button><button class="q-t" data-cp="${i}">📋 কপি</button></div></div>`).join(''):ld('কিছু পাওয়া যায়নি')};
 draw();$('#qdq').oninput=draw;
 $('#qdc').onclick=e=>{const b=e.target.closest('button');if(!b)return;cat=+b.dataset.c;draw()};
 $('#qdl').onclick=e=>{const t=e.target.closest('.q-t');if(!t)return;
  if(t.dataset.cp!=null){const x=L[+t.dataset.cp].d,s=x[1]+'\n'+x[2]+'\n('+x[3]+')';try{navigator.clipboard.writeText(s).then(()=>toast('কপি হয়েছে ✓'))}catch(_){toast('কপি করা যায়নি')}}
  else say(L[+t.dataset.k].d[1].replace(/←/g,'،'),'ar-SA',t)}}
/* ---------- tabs & open/close ---------- */
function tab(t){TB.innerHTML=[['q','📖 কুরআন'],['h','📚 হাদিস'],['d','🤲 দুআ']].map(x=>`<button data-t="${x[0]}" class="${x[0]==t?'on':''}">${x[1]}</button>`).join('');
 TB.querySelectorAll('button').forEach(b=>b.onclick=()=>tab(b.dataset.t));({q:vSurahs,h:vHC,d:vDua})[t]()}
window.qsh=o=>{dr(0);R.classList.toggle('show',!!o);if(o){if(!B.innerHTML)tab('q')}else{stopA();say0()}};
})();

if('serviceWorker' in navigator)addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
