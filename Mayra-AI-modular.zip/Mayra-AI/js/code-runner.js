(function(){
'use strict';
//#PURE
function extOf(n){const m=/\.([A-Za-z0-9]+)$/.exec(n||'');return m?m[1].toLowerCase():''}
function cleanName(n){n=String(n||'').trim().split(/[\\/]/).pop();return /^[\w.\-]{1,40}$/.test(n)&&/\./.test(n)?n:''}
function stripFence(b){b=b.replace(/^\s*```[\w+#-]*\r?\n/,'');b=b.replace(/\r?\n```\s*$/,'');return b}
function parseBlocks(s){const r=[],re=/@@@(FILE|EDIT)[ \t]+([^\r\n]+?)[ \t]*\r?\n([\s\S]*?)(\r?\n@@@END|$)/g;let m;
 while((m=re.exec(s))){if(m[0].length==0){re.lastIndex++;continue}r.push({k:m[1],n:cleanName(m[2]),b:m[3],done:!!m[4]})}return r}
function findLoose(lines,sl){for(let i=0;i+sl.length<=lines.length;i++){let ok=1;for(let j=0;j<sl.length;j++){if(lines[i+j].replace(/\s+$/,'')!==sl[j].replace(/\s+$/,'')){ok=0;break}}if(ok)return i}return -1}
function applyEdit(cur,body){const re=/<<<<<<< SEARCH\r?\n([\s\S]*?)\r?\n=======\r?\n([\s\S]*?)(?:\r?\n)?>>>>>>> REPLACE/g;let m,n=0,bad=0;
 while((m=re.exec(body))){const se=m[1],rp=m[2];let i=cur.indexOf(se);
  if(i>=0){cur=cur.slice(0,i)+rp+cur.slice(i+se.length);n++;continue}
  const L=cur.split('\n'),sl=se.split('\n'),k=findLoose(L,sl);
  if(k>=0){cur=L.slice(0,k).concat(rp.split('\n'),L.slice(k+sl.length)).join('\n');n++}else bad++}
 return{text:cur,ok:n,bad:bad+(n+bad==0?1:0)}}
function buildDoc(h,files,hook){let c=h.c;const get=u=>files.find(x=>x.n==String(u).replace(/^\.\//,''));
 c=c.replace(/<link[^>]+href=["']([^"']+)["'][^>]*>/gi,(m,u)=>{const f=get(u);return f&&/\.css$/i.test(f.n)?'<style>'+f.c+'</style>':m});
 c=c.replace(/<script([^>]*?)src=["']([^"']+)["']([^>]*)>\s*<\/script>/gi,(m,a,u,b)=>{const f=get(u);return f?'<script'+a+b+'>'+f.c.replace(/<\/script/gi,'<\\/script')+'</'+'script>':m});
 return /<head[^>]*>/i.test(c)?c.replace(/<head[^>]*>/i,m=>m+hook):hook+c}
//#ENDPURE
if(typeof document=='undefined'){return}
const $q=s=>document.querySelector(s),LS='mayra_cs_v1';
let S={files:[{n:'main.py',c:'print("Hello from Mayra Code Studio 👋")\nname = input("Tomar nam: ")\nprint("Hi,", name)\n'}],act:0,pane:1};
let E=null,building=0,running=0,aiBusy=0,aiCtl=null,undoSnap=null,pend=null,saveT=0,cmP=null,pyP=null;
try{const j=JSON.parse(localStorage.getItem(LS)||'null');if(j&&Array.isArray(j.files)&&j.files.length){S.files=j.files;S.act=Math.min(j.act||0,j.files.length-1)}}catch(e){}
const save=()=>{try{localStorage.setItem(LS,JSON.stringify({files:S.files,act:S.act}))}catch(e){}};
const saveSoon=()=>{clearTimeout(saveT);saveT=setTimeout(save,400)};
const cur=()=>S.files[S.act];
function css(h){const l=document.createElement('link');l.rel='stylesheet';l.href=h;document.head.appendChild(l)}
function js(src){return new Promise((ok,no)=>{const s=document.createElement('script');s.src=src;const t=setTimeout(()=>no(new Error('timeout: '+src)),25000);s.onload=()=>{clearTimeout(t);ok()};s.onerror=()=>{clearTimeout(t);no(new Error('load failed: '+src))};document.head.appendChild(s)})}
const st=document.createElement('style');st.textContent=`#ts{z-index:6000}#cs{position:fixed;inset:0;z-index:5000;display:none;flex-direction:column;background:#0d0b1f;color:#e9e2ff;font:14px Poppins,system-ui,sans-serif;height:100dvh}#cs.on{display:flex}#cs button{font:inherit;color:inherit;background:rgba(90,60,255,.18);border:1.5px solid #5a3cff;border-radius:10px;padding:6px 11px}#cs .sp{flex:1}.cs-top{display:flex;align-items:center;gap:8px;padding:8px 10px;border-bottom:1px solid #2a2060}#cs #cs-run{background:linear-gradient(90deg,#7b3cff,#a64dff);border:0;font-weight:700}.cs-tabs{display:flex;gap:6px;overflow-x:auto;padding:6px 8px;scrollbar-width:none;border-bottom:1px solid #2a2060}.cs-tabs button{flex:none;white-space:nowrap}#cs .cs-tabs button.on{background:#7b3cff}.cs-ed{flex:1;min-height:0;position:relative}.cs-ed .CodeMirror{height:100%;font:13px/1.5 ui-monospace,Menlo,Consolas,monospace;background:#0d0b1f}.cs-ed .CodeMirror-gutters{background:#120f2b;border-right:1px solid #2a2060}.cs-ta{width:100%;height:100%;box-sizing:border-box;background:#0d0b1f;color:#e9e2ff;border:0;padding:10px;font:13px/1.5 ui-monospace,monospace;resize:none;outline:0;white-space:pre;overflow:auto}.cs-out{display:flex;flex-direction:column;border-top:1.5px solid #5a3cff;background:#07061a;flex:none}.cs-out.p0{height:42px}.cs-out.p1{height:38%}.cs-out.p2{height:75%}.cs-oh{display:flex;align-items:center;gap:6px;padding:4px 8px;flex:none}#cs .cs-oh button.on{background:#7b3cff}#cs-if{flex:1;min-height:0;width:100%;border:0;background:#fff;display:none}#cs-cn{flex:1;min-height:0;margin:0;padding:8px 10px;overflow:auto;font:12.5px/1.45 ui-monospace,monospace;white-space:pre-wrap;word-break:break-word;display:none}.cs-out.pv:not(.p0) #cs-if{display:block}.cs-out.cn:not(.p0) #cs-cn{display:block}#cs .er{color:#ff8a8a}#cs .ok{color:#8dffc0}#cs .wn{color:#ffd35c}.cs-ai{padding:8px;border-top:1px solid #2a2060;flex:none}#cs-as{font-size:12.5px;color:#cbb8ff;padding:0 2px 6px;display:none;gap:8px;align-items:center;flex-wrap:wrap}.cs-ai .row{display:flex;gap:8px;align-items:flex-end}#cs-ai{flex:1;max-height:110px;background:#150f35;color:#fff;border:1.5px solid #5a3cff;border-radius:14px;padding:10px 12px;font:inherit;resize:none;outline:0}`;
document.head.appendChild(st);
const root=document.createElement('div');root.id='cs';
root.innerHTML=`<div class="cs-top"><button id="cs-x">✕</button><b>Code Studio</b><span class="sp"></span><button id="cs-u" title="AI-er bodol undo">↩</button><button id="cs-d" title="Download">⬇</button><button id="cs-run">▶ Run</button></div><div class="cs-tabs" id="cs-tabs"></div><div class="cs-ed" id="cs-ed"></div><div class="cs-out p1 pv" id="cs-out"><div class="cs-oh"><button data-t="pv" class="on">Preview</button><button data-t="cn">Console</button><span class="sp"></span><button id="cs-clr">🗑</button><button id="cs-sz">⤢</button></div><iframe id="cs-if" sandbox="allow-scripts allow-modals allow-forms allow-popups"></iframe><pre id="cs-cn"></pre></div><div class="cs-ai"><div id="cs-as"></div><div class="row"><textarea id="cs-ai" rows="1" placeholder="AI ke bolo… (jemon: Python e calculator banao)"></textarea><button id="cs-send">➤</button></div></div>`;
document.body.appendChild(root);
const out=$q('#cs-out'),cn=$q('#cs-cn'),ifr=$q('#cs-if'),as=$q('#cs-as');
function setTab(t){out.classList.remove('pv','cn');out.classList.add(t);out.querySelectorAll('.cs-oh button[data-t]').forEach(b=>b.classList.toggle('on',b.dataset.t==t));if(S.pane==0)setPane(1)}
function setPane(n){S.pane=n;out.classList.remove('p0','p1','p2');out.classList.add('p'+n)}
function con(s,c){const sp=document.createElement('span');if(c)sp.className=c;sp.textContent=String(s)+'\n';cn.appendChild(sp);cn.scrollTop=cn.scrollHeight}
function status(t,btns){as.innerHTML='';if(!t){as.style.display='none';return}as.style.display='flex';const s=document.createElement('span');s.textContent=t;as.appendChild(s);(btns||[]).forEach(b=>{const e=document.createElement('button');e.textContent=b[0];e.onclick=b[1];as.appendChild(e)})}
// ---- editor
function modeOf(n){const e=extOf(n);return{py:'python',js:'javascript',html:'htmlmixed',htm:'htmlmixed',css:'css',cs:'text/x-csharp',json:{name:'javascript',json:true}}[e]||null}
async function mkEd(){const host=$q('#cs-ed');host.innerHTML='';
 try{const B='https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/';if(!window.CodeMirror){if(!cmP){cmP=(async()=>{css(B+'codemirror.min.css');css(B+'theme/material-darker.min.css');for(const f of['codemirror.min.js','mode/xml/xml.min.js','mode/javascript/javascript.min.js','mode/css/css.min.js','mode/htmlmixed/htmlmixed.min.js','mode/python/python.min.js','mode/clike/clike.min.js','addon/edit/closebrackets.min.js','addon/edit/matchbrackets.min.js'])await js(B+f)})()}await cmP}
  const cm=CodeMirror(host,{value:'',theme:'material-darker',lineNumbers:true,indentUnit:4,tabSize:4,autoCloseBrackets:true,matchBrackets:true});
  cm.on('change',()=>{if(building)return;cur().c=cm.getValue();saveSoon()});
  E={get:()=>cm.getValue(),set:v=>cm.setValue(v),mode:m=>cm.setOption('mode',m),refresh:()=>cm.refresh()};
 }catch(e){cmP=null;const ta=document.createElement('textarea');ta.className='cs-ta';ta.spellcheck=false;host.appendChild(ta);
  ta.oninput=()=>{if(building)return;cur().c=ta.value;saveSoon()};
  ta.onkeydown=ev=>{if(ev.key=='Tab'){ev.preventDefault();const s=ta.selectionStart;ta.setRangeText('    ',s,ta.selectionEnd,'end');ta.oninput()}};
  E={get:()=>ta.value,set:v=>{ta.value=v},mode:()=>{},refresh:()=>{}};con('⚠️ Editor library load hoyni (offline?) — shadharon editor cholche.','wn')}}
function show(i){S.act=Math.max(0,Math.min(i,S.files.length-1));building=1;E.set(cur().c);E.mode(modeOf(cur().n));building=0;E.refresh();tabs();save()}
function tabs(){const t=$q('#cs-tabs');t.innerHTML='';S.files.forEach((f,i)=>{const b=document.createElement('button');b.textContent=f.n+(i==S.act?' ✎':'');if(i==S.act)b.classList.add('on');b.onclick=()=>{if(i!=S.act)show(i);else rename()};t.appendChild(b)});
 const p=document.createElement('button');p.textContent='＋';p.onclick=newFile;t.appendChild(p);if(S.files.length>1){const d=document.createElement('button');d.textContent='🗑 file';d.onclick=delFile;t.appendChild(d)}}
function newFile(){const n=cleanName(prompt('File er nam (jemon app.py, index.html, Program.cs):')||'');if(!n)return;const i=S.files.findIndex(f=>f.n==n);if(i>=0)return show(i);S.files.push({n,c:''});show(S.files.length-1)}
function rename(){const n=cleanName(prompt('File er notun nam:',cur().n)||'');if(!n||n==cur().n)return;if(S.files.some(f=>f.n==n)){tst('Ei nam already ase');return}cur().n=n;show(S.act)}
function delFile(){if(S.files.length<2||!confirm(cur().n+' delete korbe?'))return;S.files.splice(S.act,1);show(Math.max(0,S.act-1))}
function tst(t){try{toast(t)}catch(e){}}
// ---- run
const HOOK='<script>(function(){function s(t,a){try{parent.postMessage({mcs:1,t:t,m:[].map.call(a,function(x){try{return typeof x=="string"?x:JSON.stringify(x)}catch(e){return String(x)}}).join(" ")},"*")}catch(e){}}["log","info","warn","error"].forEach(function(k){var o=console[k];console[k]=function(){s(k,arguments);o.apply(console,arguments)}});window.addEventListener("error",function(e){s("error",[e.message+" (line "+e.lineno+")"])});window.addEventListener("unhandledrejection",function(e){s("error",["Promise: "+(e.reason&&e.reason.message||e.reason)])})})()</'+'script>';
window.addEventListener('message',e=>{const d=e.data;if(d&&d.mcs&&e.source===ifr.contentWindow)con(d.m,d.t=='error'?'er':d.t=='warn'?'wn':'')});
function setRun(){$q('#cs-run').textContent=running?'⏳':'▶ Run';$q('#cs-run').disabled=!!running}
function runHtml(h){ifr.srcdoc=buildDoc(h,S.files,HOOK);setTab('pv');con('▶ '+h.n+' preview ready','ok')}
function runJs(f){const d='<!doctype html><html><body><script>'+f.c.replace(/<\/script/gi,'<\\/script')+'</'+'script></body></html>';ifr.srcdoc=HOOK+d;setTab('cn');con('▶ '+f.n,'ok')}
function loadPy(){if(pyP)return pyP;pyP=(async()=>{con('⏳ Python engine load hocche (prothombar ~১০MB, ektu opekkha koro)…','wn');await js('https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js');const py=await loadPyodide({indexURL:'https://cdn.jsdelivr.net/pyodide/v0.26.4/full/'});py.setStdout({batched:s=>con(s)});py.setStderr({batched:s=>con(s,'er')});py.setStdin({stdin:()=>{const v=prompt('Python input():');return v==null?'':v}});con('✅ Python ready','ok');return py})();pyP.catch(()=>{pyP=null});return pyP}
async function runPy(f){setTab('cn');try{const py=await loadPy();S.files.forEach(x=>{try{py.FS.writeFile(x.n,x.c)}catch(e){}});
  try{await py.loadPackagesFromImports(f.c,{messageCallback:m=>con('📦 '+m),errorCallback:m=>con(m,'er')})}catch(e){}
  for(let k=0;k<4;k++){try{const g=py.globals.get('dict')();g.set('__name__','__main__');const r=await py.runPythonAsync(f.c,{globals:g});try{g.destroy()}catch(e){}if(r!==undefined&&r!==null)con(String(r));con('✔ shesh','ok');break}
   catch(e){const m=String(e&&e.message||e),mm=m.match(/ModuleNotFoundError: No module named '([\w.\-]+)'/);
    if(mm&&k<3){const pk=mm[1].split('.')[0];con('📦 pip install '+pk+' …','wn');try{await py.loadPackage('micropip');await py.pyimport('micropip').install(pk);continue}catch(e2){con('❌ '+pk+' install hoyni: '+String(e2&&e2.message||e2).slice(0,200),'er');break}}
    con(m.replace(/^PythonError: /,''),'er');break}}}catch(e){con('❌ '+String(e&&e.message||e),'er')}}
async function run(){if(running)return;const f=cur();f.c=E.get();save();const x=extOf(f.n);running=1;setRun();
 try{if(x=='py')await runPy(f);else if(x=='html'||x=='htm')runHtml(f);else if(x=='js')runJs(f);else if(x=='css'){const h=S.files.find(y=>/\.html?$/i.test(y.n));if(h)runHtml(h);else{setTab('cn');con('Preview er jonno ekta .html file lagbe.','wn')}}
 else if(x=='cs'){setTab('cn');con('ℹ️ C# browser/phone e chalano jay na. Code likhe/AI diye ready koro, PC te `dotnet run` e chalao.','wn')}
 else{setTab('cn');con('Run support nei: .'+x,'wn')}}finally{running=0;setRun()}}
// ---- AI
const SYS='You are a coding agent inside a phone code editor (Mayra Code Studio). You get the project files and a request. Do it by writing or changing files.\nOUTPUT FORMAT (strict):\n- One short sentence in the user\'s language first, then file blocks.\n- New or fully rewritten file:\n@@@FILE name.ext\n<entire file content>\n@@@END\n- Small change to an existing file (prefer this for big files):\n@@@EDIT name.ext\n<<<<<<< SEARCH\nexact existing lines\n=======\nnew lines\n>>>>>>> REPLACE\n@@@END\nRules: flat file names only (letters, digits, dot, dash, underscore; no folders). No markdown fences inside blocks. Nothing after the last @@@END. Python runs in the browser (Pyodide): only pure-Python or Pyodide-supported packages, no GUI windows, no sockets; use print()/input(). Web apps: plain HTML/CSS/JS, mobile-friendly, no external network calls unless asked. C# cannot be run here, but write correct code when asked. Keep code complete and working. Do not change anything the user did not ask to change.';
function ctxMsg(t){let s='PROJECT FILES:\n';S.files.forEach(f=>{s+='### '+f.n+'\n'+f.c.slice(0,60000)+'\n\n'});return s+'ACTIVE FILE: '+cur().n+'\nREQUEST: '+t}
function apply(txt,cut){const bl=parseBlocks(txt);let todo=bl.filter(b=>b.n&&(b.done||!cut));if(!todo.length){status('⚠️ AI kono file block dey nai.',[['OK',()=>status('')]]);con('AI reply (file block nei):\n'+txt.slice(0,1500),'wn');return}
 undoSnap=JSON.stringify(S.files);let ch=[],bad=0;
 todo.forEach(b=>{let f=S.files.find(x=>x.n==b.n);if(b.k=='FILE'){const c=stripFence(b.b);if(f)f.c=c;else S.files.push({n:b.n,c});ch.push(b.n)}
  else{if(!f){bad++;con('❌ EDIT: '+b.n+' file nei','er');return}const r=applyEdit(f.c,b.b);if(r.ok){f.c=r.text;ch.push(b.n)}if(r.bad){bad+=r.bad;con('❌ '+b.n+': '+r.bad+'ta edit mele nai (SEARCH text milche na)','er')}}});
 const first=ch.length?S.files.findIndex(x=>x.n==ch[0]):S.act;show(first<0?S.act:first);
 status((ch.length?'✅ '+[...new Set(ch)].join(', ')+' update hoyeche. ':'')+(bad?'⚠️ '+bad+'ta edit lagani. ':''),[['▶ Run',run],['↩ Undo',undo]])}
function undo(){if(!undoSnap){tst('Undo kora kichu nei');return}try{S.files=JSON.parse(undoSnap);undoSnap=null;show(Math.min(S.act,S.files.length-1));status('↩ AI er bodol ferot newa hoyeche.')}catch(e){}}
async function callAI(ms){const a=String(typeof sel=='string'?sel:'').split('|'),id=a[0],model=a.slice(1).join('|');if(!id||!model){tst('Age Settings e model din');return null}
 const b0=BLD,w0=WEB,t0=THINK;aiCtl=new AbortController();let n=0,o='';
 try{BLD=true;WEB=false;THINK=false;CHATSIG=aiCtl.signal;let fst=1;o=await call(id,model,ms,SYS,d=>{n+=d.length;if(fst){fst=0;status('✍️ AI likhche… '+n+' char',[['■ Stop',()=>aiCtl&&aiCtl.abort()]])}else if(as.firstChild)as.firstChild.textContent='✍️ AI likhche… '+n+' char'});return{o,cut:!!LASTCUT}}
 catch(e){const m=String(e&&e.message||e);status(/abort|STOP/i.test(m)?'⏹ Thamano hoyeche.':'❌ '+m.slice(0,200));return null}
 finally{BLD=b0;WEB=w0;THINK=t0;CHATSIG=null;aiCtl=null}}
async function ai(){if(aiBusy)return;const ta=$q('#cs-ai'),t=ta.value.trim();if(!t)return;cur().c=E.get();save();aiBusy=1;ta.value='';
 try{const m=[{role:'user',content:ctxMsg(t)}],r=await callAI(m);if(!r)return;
  if(r.cut){pend={m,o:r.o};status('✂️ AI er uttor majhpothe kete geche.',[['▶ Continue',cont],['Ekhon obdhi apply',()=>{apply(pend.o,true);pend=null}]])}
  else apply(r.o,false)}finally{aiBusy=0}}
async function cont(){if(aiBusy||!pend)return;aiBusy=1;try{const p=pend,m=p.m.concat([{role:'assistant',content:p.o},{role:'user',content:'Continue exactly where you stopped. Output only the remaining text, without repeating anything already written.'}]);const r=await callAI(m);if(!r)return;const full=p.o+r.o;
  if(r.cut){pend={m:p.m,o:full};status('✂️ Abar kete geche.',[['▶ Continue',cont],['Ekhon obdhi apply',()=>{apply(pend.o,true);pend=null}]])}else{pend=null;apply(full,false)}}finally{aiBusy=0}}
// ---- download
async function dl(){cur().c=E.get();const all=S.files.length>1&&confirm('OK = shob file ZIP, Cancel = shudhu ei file');
 const sv=(blob,n)=>{const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=n;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},1500)};
 if(!all)return sv(new Blob([cur().c],{type:'text/plain'}),cur().n);
 try{if(!window.JSZip)await js('https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js');const z=new JSZip();S.files.forEach(f=>z.file(f.n,f.c));sv(await z.generateAsync({type:'blob'}),'project.zip')}catch(e){tst('ZIP hoyni: '+(e.message||e))}}
// ---- wire
$q('#cs-x').onclick=()=>{try{cur().c=E.get()}catch(e){}save();root.classList.remove('on')};
$q('#cs-run').onclick=run;$q('#cs-u').onclick=undo;$q('#cs-d').onclick=dl;$q('#cs-send').onclick=ai;
$q('#cs-clr').onclick=()=>{cn.textContent=''};$q('#cs-sz').onclick=()=>setPane(S.pane==2?1:S.pane==1?2:1);
out.querySelectorAll('.cs-oh button[data-t]').forEach(b=>b.onclick=()=>{if(S.pane==0)setPane(1);setTab(b.dataset.t)});
$q('#cs-ai').addEventListener('input',function(){this.style.height='auto';this.style.height=Math.min(this.scrollHeight,110)+'px'});
async function open(){root.classList.add('on');if(!E){await mkEd();show(S.act)}else E.refresh()}
const nav=$q('#nav');if(nav){const a=document.createElement('a');a.innerHTML=(typeof ic=='function'?ic('code'):'💻')+'Code Studio';a.onclick=()=>{try{dr(0)}catch(e){}open()};const ts=[...nav.children].find(x=>x.textContent.trim()=='Tools');ts?ts.after(a):nav.appendChild(a)}
window.__csOpen=open;
})();

