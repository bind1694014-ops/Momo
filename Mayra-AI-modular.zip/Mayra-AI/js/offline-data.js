/* Offline Quran / Hadith downloader — pairs with sw.js cache 'mayra-data-v1' */
(()=>{
const A='https://api.alquran.cloud/v1/',H='https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/';
const CACHE='mayra-data-v1',KEY='mayra_q_off';
const hv=n=>A+'surah/'+n+'/editions/quran-uthmani,bn.bengali,ar.alafasy';
const HB=[['bukhari',97],['muslim',56],['tirmidhi',49],['abudawud',43],['nasai',51],['ibnmajah',37]];
const done=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){return{}}};
const mark=o=>{try{localStorage.setItem(KEY,JSON.stringify(o))}catch(e){}};
async function run(urls,label,btn,flag){
  if(!('caches' in window))return alert('এই ব্রাউজারে অফলাইন সেভ সাপোর্ট নেই');
  const c=await caches.open(CACHE);let n=0,bad=0;btn.disabled=true;
  for(const u of urls){
    try{if(!(await c.match(u))){const r=await fetch(u);if(!r.ok)throw 0;await c.put(u,r)}}catch(e){bad++}
    btn.textContent=label+' '+(++n)+'/'+urls.length+'…';
  }
  btn.disabled=false;
  if(!bad){const d=done();d[flag]=1;mark(d)}
  btn.textContent=bad?('⚠️ '+bad+'টি বাকি — আবার চাপুন'):'✅ অফলাইনে সেভ হয়েছে';
}
function mk(text,fn){const b=document.createElement('button');b.className='q-b';b.style.cssText='width:100%;margin:8px 0';b.textContent=text;b.onclick=()=>fn(b);return b}
new MutationObserver(()=>{
  const B=document.getElementById('qb');if(!B)return;
  const sr=document.getElementById('qsr');                       // সূরার তালিকা
  if(sr&&!document.getElementById('qoff')){
    const b=mk(done().q?'✅ কুরআন অফলাইনে আছে (আবার চেক)':'📥 পুরো কুরআন অফলাইনে সেভ করুন (১১৪ সূরা, অডিও বাদে)',
      b=>run([A+'surah',...Array.from({length:114},(_,i)=>hv(i+1))],'📥 কুরআন',b,'q'));
    b.id='qoff';sr.parentNode.insertBefore(b,sr);
  }
  const g=B.querySelector('.q-g');                                // হাদিস বইয়ের সেকশন তালিকা
  if(g&&!document.getElementById('hoff')){
    const bk=HB.find(x=>g.children.length==x[1]);if(!bk)return;
    const urls=[];for(let i=1;i<=bk[1];i++)urls.push(H+'ara-'+bk[0]+'/sections/'+i+'.json',H+'ben-'+bk[0]+'/sections/'+i+'.json');
    const b=mk(done()['h_'+bk[0]]?'✅ এই বই অফলাইনে আছে':'📥 এই বই অফলাইনে সেভ করুন',b=>run(urls,'📥 হাদিস',b,'h_'+bk[0]));
    b.id='hoff';g.parentNode.insertBefore(b,g);
  }
}).observe(document.body,{childList:true,subtree:true});
})();
